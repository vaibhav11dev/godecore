<div class="ved_metabox">
    <?php
    sidebar_generator::edit_form();
    ?>
</div>