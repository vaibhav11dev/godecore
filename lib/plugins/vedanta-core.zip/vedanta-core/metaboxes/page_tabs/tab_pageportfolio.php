<!--rename this file page_options.php to tab_page_portfolio.php-->
<!--this is actual page portfolio file-->
<div class="ved_metabox">
    <p><b><?php esc_html_e('Note: Portfolio options override all Layout options and work for only portfolio template','vedanta-core'); ?></b></p>
    <?php
    $types = get_terms('portfolio_category', 'hide_empty=0');
    $types_array[0] = 'All categories';
    if ($types) {
        foreach ($types as $type) {
            $types_array[$type->term_id] = $type->name;
        }
        $this->vedanta_multiple('portfolio_category', esc_html__('Portfolio Type', 'vedanta-core'), $types_array, esc_html__('Choose what portfolio category you want to display on this page.', 'vedanta-core')
        );
    }

    $this->vedanta_select('portfolio_filters', esc_html__('Show Portfolio Filters', 'vedanta-core'), array(
        'yes' => esc_html__('Show', 'vedanta-core'),
        'no' => esc_html__('Hide', 'vedanta-core')
            ), ''
    );
    ?>
</div>