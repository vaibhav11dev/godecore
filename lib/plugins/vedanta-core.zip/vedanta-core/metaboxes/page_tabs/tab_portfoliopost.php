<div class='ved_metabox'>
    <?php
    $this->vedanta_select( 'po_featured_image', esc_html__( 'Show Featured Image', 'vedanta-core' ), array( 'default' => 'Default', 'yes' => 'Show', 'no' => 'Hide' ), ''
    );

    $this->vedanta_select( 'po_author', esc_html__( 'Show Author', 'vedanta-core' ), array( 'default' => 'Default', 'yes' => 'Show', 'no' => 'Hide' ), ''
    );

    $this->vedanta_select( 'po_sharing', esc_html__( 'Show Sharing Box', 'vedanta-core' ), array( 'default' => 'Default', 'yes' => 'Show', 'no' => 'Hide' ), ''
    );

    $this->vedanta_select( 'po_related_posts', esc_html__( 'Show Related Posts', 'vedanta-core' ), array( 'default' => 'Default', 'yes' => 'Show', 'no' => 'Hide' ), ''
    );

    $this->vedanta_text( 'project_url', esc_html__( 'Project URL', 'vedanta-core' ), ''
    );

    $this->vedanta_text( 'project_url_text', esc_html__( 'Project URL Text', 'vedanta-core' ), ''
    );

    $this->vedanta_text( 'link_icon_url', 'Portfolio Link URL', 'Leave blank as post URL'
    );

    $this->vedanta_select( 'link_icon_target', 'Open Link URL In New Window', array( 'no' => 'No', 'yes' => 'Yes' ), ''
    );
    ?>    
</div>