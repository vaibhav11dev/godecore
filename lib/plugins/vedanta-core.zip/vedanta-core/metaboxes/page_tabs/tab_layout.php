<div class='ved_metabox'>
	<?php
	$this->vedanta_image_radio_button(
	'sidebar_position', esc_html__( 'Sidebar Position', 'vedanta-core' ), array(
		'default'	 => VEDANTA_CORE_URL . 'assets/images/none.jpg',
		'1c'		 => VEDANTA_CORE_URL . 'assets/images/1c.png',
		'2cl'		 => VEDANTA_CORE_URL . 'assets/images/2cl.png',
		'2cr'		 => VEDANTA_CORE_URL . 'assets/images/2cr.png',
		'3cm'		 => VEDANTA_CORE_URL . 'assets/images/3cm.png',
		'3cr'		 => VEDANTA_CORE_URL . 'assets/images/3cr.png',
		'3cl'		 => VEDANTA_CORE_URL . 'assets/images/3cl.png'
	), '', 'default'
	);

	$this->vedanta_text( 'content_top_bottom_padding', esc_html__( 'Content Top & Bottom Padding', 'vedanta-core' ), esc_html__( 'Enter the page content top & bottom padding. In pixels ex: 20px. Leave empty for default value.', 'vedanta-core' )
	);

	$this->vedanta_text( 'hundredp_padding', esc_html__( 'Fullwidth - Fluid Template Left/Right Padding', 'vedanta-core' ), esc_html__( 'In pixels ex: 20px. Leave empty for default value.', 'vedanta-core' )
	);
	?>
</div>