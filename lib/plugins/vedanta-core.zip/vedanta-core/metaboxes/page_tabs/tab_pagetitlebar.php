<div class="ved_metabox">
    <?php
   $this->vedanta_select( 'enable_page_title', esc_html__( 'Enable Page Title Bar', 'vedanta-core' ), array(
	'default'		 => esc_html__( 'Default', 'vedanta-core' ),
	'on'	 => esc_html__( 'On', 'vedanta-core' ),
	'off'		 => esc_html__( 'Off', 'vedanta-core' ),
    ), ''
    );
    
    $this->vedanta_select( 'display_page_title', esc_html__( 'Page Title Bar', 'vedanta-core' ), array(
	'default'		 => esc_html__( 'Default', 'vedanta-core' ),
	'titlebar_breadcrumb'	 => esc_html__( 'Title + Breadcrumb', 'vedanta-core' ),
	'titlebar'		 => esc_html__( 'Only Title', 'vedanta-core' ),
	'breadcrumb'		 => esc_html__( 'Only Breadcrumb', 'vedanta-core' ),
    ), ''
    );

    $this->vedanta_text( 'page_title_bar_bg_color', esc_html__( 'Page Title Bar Background Color (Hex Code)', 'vedanta-core' ), '' );

    $this->vedanta_upload( 'page_title_bar_bg', esc_html__( 'Page Title Bar Background', 'vedanta-core' ) );

    $this->vedanta_select( 'page_title_bar_height', esc_html__( 'Page Title Bar Height', 'vedanta-core' ), array(
	'default'	 => esc_html__( 'Default', 'vedanta-core' ),
	'medium'	 => esc_html__( 'Medium', 'vedanta-core' ),
	'small'		 => esc_html__( 'Small', 'vedanta-core' ),
	'large'		 => esc_html__( 'Large', 'vedanta-core' ),
	'custom'	 => esc_html__( 'Custom', 'vedanta-core' ),
    ), ''
    );

    $this->vedanta_text( 'page_title_bar_height_custom', 'Custom Height', "All Height in vh and don't add suffix vh. ex: 70"
    );

    $this->vedanta_select( 'page_title_bar_parallax_bg', esc_html__( 'Parallax Background Image', 'vedanta-core' ), array(
	'default'	 => esc_html__( 'Default', 'vedanta-core' ),
	'yes'		 => esc_html__( 'Show', 'vedanta-core' ),
	'no'		 => esc_html__( 'Hide', 'vedanta-core' ),
    ), ''
    );
    ?>
</div>
