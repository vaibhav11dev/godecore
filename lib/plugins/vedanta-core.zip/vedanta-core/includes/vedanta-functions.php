<?php
/**
 * Share link socials
 *
 * @since  1.0
 */
if ( !function_exists( 'vedanta_share_link_socials' ) ) :

	function vedanta_share_link_socials( $tooltip_position, $title, $link, $media ) {
		$ved_sharing_twitter = vedanta_get_option( 'ved_sharing_twitter', '0' );
		$ved_sharing_facebook = vedanta_get_option( 'ved_sharing_facebook', '0' );
		$ved_sharing_google = vedanta_get_option( 'ved_sharing_google', '0' );
		$ved_sharing_pinterest = vedanta_get_option( 'ved_sharing_pinterest', '0' );
		$ved_sharing_linkedin = vedanta_get_option( 'ved_sharing_linkedin', '0' );
		$ved_sharing_email = vedanta_get_option( 'ved_sharing_email', '0' );
		$ved_sharing_more_options = vedanta_get_option( 'ved_sharing_more_options', '0' );

		$socials_html		 = '';
		if ( $ved_sharing_twitter ) {
			$socials_html .= sprintf(
			'<a class="ved-twitter" data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="http://twitter.com/share?text=%s&url=%s" target="_blank"><i class="fa fa-twitter"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'Share on Twitter', 'vedanta-core' ), urlencode( $title ), urlencode( $link )
			);
		}

		if ( $ved_sharing_facebook ) {
			$socials_html .= sprintf(
			'<a class="ved-facebook" data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="http://www.facebook.com/sharer.php?u=%s&t=%s" target="_blank"><i class="fa fa-facebook"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'Share on Facebook', 'vedanta-core' ), urlencode( $link ), urlencode( $title )
			);
		}

		if ( $ved_sharing_google ) {
			$socials_html .= sprintf(
			'<a class="ved-google" data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="https://plus.google.com/share?url=%s&text=%s" target="_blank"><i class="fa fa-google-plus"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'Share on Google Plus', 'vedanta-core' ), urlencode( $link ), \ urlencode( $title )
			);
		}

		if ( $ved_sharing_pinterest ) {
			$socials_html .= sprintf(
			'<a class="ved-pinterest" data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="http://pinterest.com/pin/create/button?media=%s&url=%s&description=%s" target="_blank"><i class="fa fa-pinterest"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'Share on Pinterest', 'vedanta-core' ), urlencode( $media ), urlencode( $link ), urlencode( $title )
			);
		}

		if ( $ved_sharing_linkedin ) {
			$socials_html .= sprintf(
			'<a class="ved-linkedin" data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="http://www.linkedin.com/shareArticle?url=%s&title=%s" target="_blank"><i class="fa fa-linkedin-square"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'Share on Linkedin', 'vedanta-core' ), urlencode( $link ), urlencode( $title )
			);
		}

		if ( $ved_sharing_email ) {
			$socials_html .= sprintf(
			'<a class="ved-email" data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="http://www.addtoany.com/email?linkurl=%s&linkname=%s" target="_blank"><i class="fa fa-envelope-o"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'Share on Email', 'vedanta-core' ), urlencode( $link ), urlencode( $title )
			);
		}

		if ( $ved_sharing_more_options ) {
			$socials_html .= sprintf(
			'<a class="ved-more" data-toggle="tooltip" data-placement="%s" data-original-title="%s" href="http://www.addtoany.com/share_save#url=%s&linkname=%s" target="_blank"><i class="icon-action-redo icons ti-plus"></i></a>', esc_attr( $tooltip_position ), esc_html__( 'More options', 'vedanta-core' ), urlencode( $link ), urlencode( $title )
			);
		}
		
		if ( $socials_html ) {
			printf( '<div class="share-this"><span class="tit">Share</span>%s</div>', $socials_html );
		}
	}

endif;

function version_check( $version = '3.2' ) {
	if ( class_exists( 'WooCommerce' ) ) {
		global $woocommerce;
		if ( version_compare( $woocommerce->version, $version, ">=" ) ) {
			return true;
		}
	}
	return false;
}