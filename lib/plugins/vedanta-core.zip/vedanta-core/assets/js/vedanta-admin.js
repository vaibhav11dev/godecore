jQuery(document).ready(function () {
	jQuery("#new_label_date_field").datepicker({
		minDate: 0, dateFormat: 'yy-mm-dd'
	}
	);

	/* Js - For Hero Header Type Page Metadata Options */
	var theme_prefix = 'vedanta_';
	var type = jQuery('#' + theme_prefix + 'hero_header_type').val();
	var container = jQuery('#' + theme_prefix + 'hero_header_type').parents('#' + theme_prefix + 'vedanta_page_options');

	jQuery(container).find('.slider_note, .parallax_settings, .youtube_settings, .vimeo_settings, .self_video_settings, .herocontent_settings').hide();

	if (type == 'hero_parallax') {
		jQuery(container).find('.parallax_settings, .herocontent_settings').show();
		jQuery(container).find('.slider_note, .youtube_settings, .vimeo_settings, .self_video_settings').hide();
	} else if (type == 'hero_youtube') {
		jQuery(container).find('.youtube_settings, .herocontent_settings').show();
		jQuery(container).find('.slider_note, .parallax_settings, .vimeo_settings, .self_video_settings').hide();
	} else if (type == 'hero_vimeo') {
		jQuery(container).find('.vimeo_settings, .herocontent_settings').show();
		jQuery(container).find('.slider_note, .youtube_settings, .parallax_settings, .self_video_settings').hide();
	} else if (type == 'hero_self_hosted_video') {
		jQuery(container).find('.self_video_settings, .herocontent_settings').show();
		jQuery(container).find('.slider_note, .youtube_settings, .vimeo_settings, .parallax_settings').hide();
	} else if (type == 'hero_slider') {
		jQuery(container).find('.slider_note').show();
		jQuery(container).find('.parallax_settings, .youtube_settings, .vimeo_settings, .self_video_settings, .herocontent_settings').hide();
	}

	jQuery('#' + theme_prefix + 'hero_header_type').change(function () {
		var type = jQuery(this).val();
		var container = jQuery(this).parents('#' + theme_prefix + 'vedanta_page_options');
		jQuery(container).find('.slide1r_note, .parallax_settings, .youtube_settings, .vimeo_settings, .self_video_settings, .herocontent_settings').hide();

		if (type == 'hero_parallax') {
			jQuery(container).find('.parallax_settings, .herocontent_settings').show();
			jQuery(container).find('.slider_note, .youtube_settings, .vimeo_settings, .self_video_settings').hide();
		} else if (type == 'hero_youtube') {
			jQuery(container).find('.youtube_settings, .herocontent_settings').show();
			jQuery(container).find('.slider_note, .parallax_settings, .vimeo_settings, .self_video_settings').hide();
		} else if (type == 'hero_vimeo') {
			jQuery(container).find('.vimeo_settings, .herocontent_settings').show();
			jQuery(container).find('.slider_note, .youtube_settings, .parallax_settings, .self_video_settings').hide();
		} else if (type == 'hero_self_hosted_video') {
			jQuery(container).find('.self_video_settings, .herocontent_settings').show();
			jQuery(container).find('.slider_note, .youtube_settings, .vimeo_settings, .parallax_settings').hide();
		} else if (type == 'hero_slider') {
			jQuery(container).find('.slider_note').show();
			jQuery(container).find('.parallax_settings, .youtube_settings, .vimeo_settings, .self_video_settings, .herocontent_settings').hide();
		}

	});

	/* Js - For Hero Header Height Page Metadata Options */
	var type = jQuery('#' + theme_prefix + 'hero_height').val();
	var container = jQuery('#' + theme_prefix + 'hero_height').parents('#' + theme_prefix + 'vedanta_page_options');

	jQuery(container).find('#' + theme_prefix + 'hero_height_custom').parents('.ved_metabox_field').hide();

	if (type == 'custom') {
		jQuery(container).find('#' + theme_prefix + 'hero_height_custom').parents('.ved_metabox_field').show();
	}

	jQuery('#' + theme_prefix + 'hero_height').change(function () {
		var type = jQuery(this).val();
		var container = jQuery(this).parents('#' + theme_prefix + 'vedanta_page_options');
		jQuery(container).find('#' + theme_prefix + 'hero_height_custom').parents('.ved_metabox_field').hide();

		if (type == 'custom') {
			jQuery(container).find('#' + theme_prefix + 'hero_height_custom').parents('.ved_metabox_field').show();
		}
	});

	/* Js - For Page/Post Title Bar Height Page/Post Metadata Options */
        var post_type = '';
        if ( jQuery('body').hasClass('post-type-post') ) {
            post_type = 'vedanta_post_options';
        } else {
            post_type = 'vedanta_page_options';
        }
	var type = jQuery('#' + theme_prefix + 'page_title_bar_height').val();
	var container = jQuery('#' + theme_prefix + 'page_title_bar_height').parents('#' + theme_prefix + post_type);

	jQuery(container).find('#' + theme_prefix + 'page_title_bar_height_custom').parents('.ved_metabox_field').hide();

	if (type == 'custom') {
		jQuery(container).find('#' + theme_prefix + 'page_title_bar_height_custom').parents('.ved_metabox_field').show();
	}

	jQuery('#' + theme_prefix + 'page_title_bar_height').change(function () {
		var type = jQuery(this).val();
		var container = jQuery(this).parents('#' + theme_prefix + post_type);
		jQuery(container).find('#' + theme_prefix + 'page_title_bar_height_custom').parents('.ved_metabox_field').hide();

		if (type == 'custom') {
			jQuery(container).find('#' + theme_prefix + 'page_title_bar_height_custom').parents('.ved_metabox_field').show();
		}
	});

	//mobile sidebar
	if (jQuery(window).width() < 768) {
		setTimeout(function(){ 
	   		jQuery(".expand_options").trigger( "click" );
	   	}, 300);
	}
	
});