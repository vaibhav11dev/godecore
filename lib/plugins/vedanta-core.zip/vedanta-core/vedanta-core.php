<?php
/**
 *
 * Plugin Name: Vedanta Core
 * Plugin URI: http://webheaythemes.co.uk
 * Description: Core functionality of webheaythemes
 * Version: 1.0.0
 * Author: webheaythemes
 * Author URI: http://webheaythemes.co.uk
 *
 */
if ( ! defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly


// Define path to this plugin file
define( 'VEDANTA_CORE_URL', plugins_url( '/', __FILE__ ) );
define( 'VEDANTA_CORE_PATH', plugin_dir_path( __FILE__ ) );
define( 'VEDANTA_CORE_ROOT', __FILE__ );
define( 'VEDANTA_SAMPLE_DATA', 'http://webheaythemes.co.uk/yam5' );

require_once VEDANTA_CORE_PATH . 'templates/ved-templates.php';
require_once VEDANTA_CORE_PATH . 'includes/templates-functions.php';
require_once VEDANTA_CORE_PATH . 'includes/vedanta-functions.php';
require_once VEDANTA_CORE_PATH . 'includes/auto_install.php';

// Metaboxes
require_once( VEDANTA_CORE_PATH . 'metaboxes/metaboxes.php' );

/**
 * Initialize Theme Options
 */
require_once( VEDANTA_CORE_PATH . 'themeoptions/framework.php');
require_once( VEDANTA_CORE_PATH . 'themeoptions/options/vedanta_extension.php');


if ( ! class_exists( 'Vedanta_Core_Plugin' ) ) :

    /**
     *
     * Initialize Vedanta Core
     * @package Vedanta Core
     * @since    1.0.0
     *
     */
    class Vedanta_Core_Plugin {

        /**
         *
         * Unique identifier for your plugin.
         *
         *
         * The variable name is used as the text domain when internationalizing strings
         * of text. Its value should match the Text Domain file header in the main
         * plugin file.
         *
         * @since    1.0.0
         *
         * @var      string
         */
        protected $plugin_slug = 'vedanta-core';

        /**
         * Initialize the plugin by setting localization and loading public scripts
         * and styles.
         *
         * @since     1.0.0
         */
        public function __construct() {
            add_action( 'init', array( $this, 'init' ) );
            add_action( 'admin_enqueue_scripts', array( $this, 'vedanta_adminscripts' ) );
            add_action( 'after_setup_theme', array( $this, 'load_ved_core_text_domain' ) );
        }

        public static function init() {
            register_post_type(
            'vedanta_portfolio', array(
                'labels'      => array(
                    'name'          => 'Portfolio',
                    'singular_name' => 'Portfolio'
                ),
                'public'      => true,
                'has_archive' => false,
                'rewrite'     => array(
                    'slug' => 'portfolio-items'
                ),
                'supports'    => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', 'page-attributes' ),
                'can_export'  => true,
            )
            );

            register_taxonomy( 'portfolio_category', 'vedanta_portfolio', array( 'hierarchical' => true, 'label' => 'Categories', 'show_in_rest' => true, 'query_var' => true, 'rewrite' => true ) );

            register_taxonomy( 'portfolio_skills', 'vedanta_portfolio', array( 'hierarchical' => true, 'label' => 'Skills', 'show_in_rest' => true, 'query_var' => true, 'rewrite' => true ) );

            register_taxonomy( 'portfolio_tags', 'vedanta_portfolio', array( 'hierarchical' => false, 'label' => 'Tags', 'show_in_rest' => true, 'query_var' => true, 'rewrite' => true ) );
        }



        /**
         * Register the plugin text domain
         *
         * @return void
         */
        public static function load_ved_core_text_domain() {
            load_plugin_textdomain( 'vedanta-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
        }

        /**
         * Enqueue admin scripts and styles.
         */
        public static function vedanta_adminscripts( $hook ) {
            wp_enqueue_script( 'vedanta-admin', VEDANTA_CORE_URL . 'assets/js/vedanta-admin.js', array( 'jquery' ), '' );
            wp_enqueue_script( 'jquery-ui-datepicker', array( 'jquery' ) );
            wp_enqueue_style( 'jquery-ui-datepicker' );
            wp_enqueue_script( 'jquery-ui-dialog' );
        }


} // Close Vedanta_Core_Plugin()

$vedanta_core_plugin = new Vedanta_Core_Plugin();
endif;

/**
* Initialize theme admin dashboard
 */
function ved_manage_admin_bar() {
    // load Widget functions
    require_once( VEDANTA_CORE_PATH . 'widgets/125x125.php' );
    require_once( VEDANTA_CORE_PATH . 'widgets/contact_info.php' );
    require_once( VEDANTA_CORE_PATH . 'widgets/facebook-like-widget.php' );
    require_once( VEDANTA_CORE_PATH . 'widgets/flickr-widget.php' );
    require_once( VEDANTA_CORE_PATH . 'widgets/recent-posts-widget.php' );
    require_once( VEDANTA_CORE_PATH . 'widgets/recent-works-widget.php' );
    require_once( VEDANTA_CORE_PATH . 'widgets/social_links.php' );
    require_once( VEDANTA_CORE_PATH . 'widgets/vertical-menu-widget.php' );
    if ( function_exists( 'WC' ) ) {
        require_once( VEDANTA_CORE_PATH . 'widgets/product-carousel-widget.php' );
    }
}
add_action( 'plugins_loaded', 'ved_manage_admin_bar' );

/**
 * For auto install
 */
if ( is_admin() ) {
	require_once( VEDANTA_CORE_PATH . 'includes/sample_data.php' );
	add_action( 'wp_ajax_auto_install_layout', 'auto_install_layout' );
	add_action( 'wp_ajax_nopriv_auto_install_layout', 'auto_install_layout' );
	add_action( 'wp_ajax_remove_auto_update', 'remove_auto_update' );
	add_action( 'wp_ajax_nopriv_remove_auto_update', 'remove_auto_update' );
}