<?php
/**
 * Vedanta Elementor Page Template
 * 
 * @version	1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Ved_Templates' ) ) {

    class Ved_Templates {

        function __construct() {
            add_action( 'init', array( $this, 'init' ) );
            add_action( "add_meta_boxes", array( $this, 'ved_add_meta_box' ) );


            add_filter( 'manage_ved_templates_posts_columns', array( $this, 'ved_edit_templates_col' ) );
            add_action( 'manage_ved_templates_posts_custom_column', array( $this, 'ved_add_templates_col' ), 10, 2 );

            add_filter( 'widget_text', 'do_shortcode' );
        }

        function init() {

            register_post_type(
                'ved_templates', array(
                    'label'               => esc_html__( 'Post List', 'vedanta-core' ),
                    'supports'            => array( 'title', 'editor' ),
                    'public'              => true,
                    'rewrite'             => false,
                    'show_ui'             => true,
                    'show_in_menu'        => true,
                    'show_in_nav_menus'   => false,
                    'exclude_from_search' => true,
                    'capability_type'     => 'post',
                    'hierarchical'        => false,
                    'menu-icon'           => 'dashicon-move',
                    'labels'              => array(
                        'name'               => _x( 'Ved Templates', 'Post Type General Name', 'vedanta-core' ),
                        'singular_name'      => _x( 'Ved Template', 'Post Type Singular Name', 'vedanta-core' ),
                        'menu_name'          => esc_html__( 'Ved Templates', 'vedanta-core' ),
                        'name_admin_bar'     => esc_html__( 'Ved Templates', 'vedanta-core' ),
                        'archives'           => esc_html__( 'List Archives', 'vedanta-core' ),
                        'parent_item_colon'  => esc_html__( 'Parent List:', 'vedanta-core' ),
                        'all_items'          => esc_html__( 'All Ved Templates', 'vedanta-core' ),
                        'add_new_item'       => esc_html__( 'Add New Ved Template', 'vedanta-core' ),
                        'add_new'            => esc_html__( 'Add New', 'vedanta-core' ),
                        'new_item'           => esc_html__( 'New Ved Template', 'vedanta-core' ),
                        'edit_item'          => esc_html__( 'Edit Ved Template', 'vedanta-core' ),
                        'update_item'        => esc_html__( 'Update Ved Template', 'vedanta-core' ),
                        'view_item'          => esc_html__( 'View Ved Template', 'vedanta-core' ),
                        'search_items'       => esc_html__( 'Search Ved Template', 'vedanta-core' ),
                        'not_found'          => esc_html__( 'Not found', 'vedanta-core' ),
                        'not_found_in_trash' => esc_html__( 'Not found in Trash', 'vedanta-core' )
                    ),
                )
            );
        }

        function ved_edit_templates_col( $columns ) {
            $columns[ 'ved_shortcode_column' ] = esc_html__( 'Shortcode', 'vedanta-core' );
            return $columns;
        }

        function ved_add_templates_col( $column, $post_id ) {
            switch ( $column ) {
                case 'ved_shortcode_column' :
                    echo '<input type=\'text\' class=\'widefat\' value=\'[VED_TEMPLATE id="' . $post_id . '"]\' readonly="">';
                    break;
            }
        }

        function ved_add_meta_box() {
            add_meta_box( 'ved-shortcode-box', 'Template Usage', array( $this, 'ved_shortcode_box' ), 'ved_templates', 'side', 'high' );
        }

        function ved_shortcode_box( $post ) {
            ?>
            <h4 style="margin-bottom:5px;">Shortcode</h4>
            <input type='text' class='widefat' value='[VED_TEMPLATE id="<?php echo $post->ID; ?>"]' readonly="">

            <h4 style="margin-bottom:5px;">Php Code</h4>
            <input type='text' class='widefat' value="&lt;?php echo do_shortcode('[VED_TEMPLATE id=&quot;<?php echo $post->ID; ?>&quot;]'); ?&gt;" readonly="">
            <?php
        }

    }

    $ved_templates = new Ved_Templates();
}