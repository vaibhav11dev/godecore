<?php
    /**
     * The template for the panel header area.
     * Override this template by specifying the path where it is stored (templates_path) in your Redux config.
     *
     * @author      Redux Framework
     * @package     ReduxFramework/Templates
     * @version:    3.5.4.18
     */

?>
<div id="redux-header" class="about-wrap wrap">

 <?php   global $submenu;

if (isset($submenu['godecore-menu'])) {
    $menu_items = $submenu['godecore-menu'];
}

if (is_array($menu_items)) {
    settings_errors();
    ?>
    
    <div class="def-bg">
      <div class="container head-contain">        
        <div class="theme_content">
			<?php $vedanta_theme = wp_get_theme(); ?>
			<h1><?php printf(esc_html__('Welcome to %s Theme', 'vedanta-core'), $vedanta_theme); ?></h1>
            <p><?php printf(esc_html__('Version %s', 'vedanta-core'), $vedanta_theme->get('Version')); ?></p>
        </div>
        <div class="nav-tab-wrapper">
            <?php
            foreach ($menu_items as $menu_item) {
                ?>
                <a href="?page=<?php echo esc_attr($menu_item[2]) ?>" class="nav-tab <?php
                   if (isset($_GET['page']) and $_GET['page'] == $menu_item[2]) {
                       echo 'nav-tab-active';
                   }
                   ?>"><?php echo esc_attr($menu_item[0]) ?></a>
                   <?php
               }
               ?>
            <span class="clear"></span>
        </div>
      </div></div>
        <?php
    }

        if ( ! empty( $this->parent->args['display_name'] ) ) { ?>
        
    <?php } ?>

    <div class="clear"></div>
</div>