jQuery(document).ready(function () {
	/* script for auto install */
	jQuery('#auto-install').on('click', function () {
		jQuery('.auto-install-loader').show();
		var demo = jQuery('#auto-install').attr('data-href');
		var auto_update = 'auto_install_layout1';
		auto_update = demo;
		jQuery.ajax({
			type: 'POST',
			url: js_strings.ajaxurl,
			data: {
				layout: auto_update,
				action: 'auto_install_layout'
			}
			,
			success: function (data, textStatus, XMLHttpRequest) {
				jQuery('.auto-install-loader').hide();
				location.reload();
			}
			,
			error: function (XMLHttpRequest, textStatus, errorThrown) {
				jQuery('.auto-install-loader').hide();
				location.reload();
			}
		}
		);
	}
	);
	jQuery('#remove-auto-install').on('click', function () {
		if (confirm("Do you want to remove sample data?") == true) {
			jQuery('.auto-install-loader').show();
			jQuery.ajax({
				type: 'POST',
				url: js_strings.ajaxurl,
				data: {
					action: 'remove_auto_update'
				}
				,
				success: function (data, textStatus, XMLHttpRequest) {
					jQuery('.auto-install-loader').hide();
					location.reload();
				}
				,
				error: function (XMLHttpRequest, textStatus, errorThrown) {
					jQuery('.auto-install-loader').hide();
					location.reload();
				}
			}
			);
			return true;
		} else {
			return false;
		}
	}
	);

	/* jquery auto-install section */
	jQuery('.demo_layout_wrap.select_demo div.bgframe.demo').live('click', function () {
		var tlayout = jQuery(this);
		jQuery('.demo_layout_wrap div.bgframe.demo').each(function () {
			jQuery(this).find('.scroll_image.demo').removeClass('selected');
			jQuery(this).removeClass('selected');
		}
		);
		tlayout.find('.scroll_image').addClass('selected');
		tlayout.addClass('selected');
		var install_path = tlayout.find('.scroll_image').attr('demo-attr');
		jQuery('.demo_install_button').find('a.install_demo').removeClass('disabled');
		jQuery('.demo_install_button').find('.select_demo_msg').remove();
		jQuery('.demo_install_button').find('a.install_demo').attr('data-href', install_path);
	}
	);
	if (jQuery('.demo_layout_wrap a.bgframe.demo').hasClass('selected')) {
		jQuery('.demo_install_button').find('a.install_demo').removeClass('disabled');
	} else {
		jQuery('.demo_install_button').find('a.install_demo').addClass('disabled');
		jQuery('.demo_install_button').find('.start_install').append('<span class="select_demo_msg"> ' + js_strings.select_demo_notice + '</span>');
	}
	jQuery(window).load(function () {
		jQuery('.end_install').find('.select_demo_msg').remove();
	}
	);
});