<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

function godecore_admin_menu() {
	add_menu_page( esc_html__( 'About Theme', 'godecore-data' ), esc_html__( 'GoDecore', 'godecore-data' ), 'manage_options', 'godecore-menu', 'godecore_welcome', GODECORE_DATA_URL . '/admin/assets/images/admin-icon.png', 2 );
}

add_action( 'admin_menu', 'godecore_admin_menu' );

function godecore_admin_submenu() {
	if ( class_exists( 'Vedanta_Core_Plugin' ) ) {
		add_submenu_page( 'godecore-menu', esc_html__( 'Install Demos', 'godecore-data' ), esc_html__( 'Install Demos', 'godecore-data' ), 'manage_options', 'godecore_demos', 'godecore_demo' );
		add_submenu_page( 'godecore-menu', esc_html__( 'Theme Options', 'godecore-data' ), esc_html__( 'Theme Options', 'godecore-data' ), 'manage_options', 'godecore_options', 'godecore_option' );
		global $submenu;
		$submenu[ 'godecore-menu' ][ 0 ][ 0 ] = esc_html__( 'About Theme', 'godecore-data' );
	}
}

add_action( 'admin_menu', 'godecore_admin_submenu' );

function godecore_welcome() {
        include_once( GODECORE_DATA_PATH . 'admin/godecore_menu/godecore-welcome.php' );
}

function godecore_demo() {
        include_once( GODECORE_DATA_PATH . 'admin/godecore_menu/godecore-install_demo.php' );
}

function godecore_option() {
        include_once( GODECORE_DATA_PATH . 'admin/godecore_menu/godecore-options.php' );
}
