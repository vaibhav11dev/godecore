<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

include_once( GODECORE_DATA_PATH . 'admin/godecore_menu/godecore-menu_header.php' );
