<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
/* include file for auto install */
include_once( GODECORE_DATA_PATH . 'admin/godecore_menu/godecore-menu_header.php' );
?>
<div class="container">
    <div class="box">
        <p class="install_demo_title"><?php esc_html_e('Importing demo data (post, pages, images, theme settings, ...) is the easiest way to setup your theme. It will allow you to quickly edit everything instead of creating content from scratch. ', 'godecore-data'); ?></p>
        <?php
        $auto_install = get_option('listing_xml');
		$selected_layout = get_option('layout');
        if ($auto_install == 0) {
            $class = 'select_demo';
        } else {
            $class = '';
        }
        ?>

        <div class="demo_layout_wrap <?php echo esc_attr($class); ?>">
            <div class="row">
				<?php 
				for($i = 1; $i <= 15; $i++) { 
					$install_layout = 'auto_install_layout'.$i;
					$layout_img = 'demo'.$i;
					$layout_url = 'wp'.$i;
					$demo_title = 'Homepage '.$i;
					?>
					<!--Yamfive Demo-1-->
                <div class="demodiv">
						<div class="bgframe demo <?php if ($selected_layout == $install_layout) { echo 'selected'; } ?>"><span class="scroll_image <?php if ($selected_layout == $install_layout) { echo 'selected'; } ?>" demo-attr="<?php esc_attr_e($install_layout); ?>" style="background-image:url('<?php echo GODECORE_SAMPLE_DATA.'/wp-content/auto-install/' . $install_layout . '/' . $layout_img . '.jpg'; ?>');"></span>
							<div class="img_hover"><span><?php esc_html_e( $demo_title ); ?></span><a href="<?php echo esc_url(GODECORE_SAMPLE_DATA.'/'.$layout_url.'/'); ?>" target="_blank"><?php esc_html_e('Live Demo', 'godecore-data'); ?></a></div>
        		</div>
                </div>
				<?php } ?>
        	
        	   <!--Yamfive comingsoon-->
                <div class="demodiv">
					<div class="bgframe comingsoon <?php if ($selected_layout == 'auto_install_comingsoon') { echo 'selected'; } ?>"><span class="scroll_image <?php if ($selected_layout == 'auto_install_comingsoon') { echo 'selected'; } ?>" demo-attr="auto_install_comingsoon" style="background-image:url('<?php echo esc_url(GODECORE_SAMPLE_DATA); ?>/wp-content/auto-install/comingsoon.jpg');"></span>
						<div class="img_hover"></div>
        		</div>
                </div>
        		</div>
        	
            <div class="one-col demo_install_button">    
                <?php
                $auto_install = get_option('listing_xml');
                if ($auto_install == 0) {
                    ?>
                    <div class="start_install">
                        <a id="auto-install" class="install_demo" data-href=""><?php esc_html_e('Install Sample Data', 'godecore-data'); ?></a>
                    </div><?php
                }
                if ($auto_install == 1) {
                    ?>
                    <div class="start_install end_install">
                        <a id="remove-auto-install" class="uninstall_demo" data-href="" ><?php esc_html_e('Uninstall Sample Data', 'godecore-data'); ?></a>
                    </div><?php
                }
                ?>
            </div>

            <div class="auto_install_details">
                <?php
                if ($auto_install == 1) {
                    ?>
                    <p class="theme_export_note"> <?php esc_html_e("NOTE: Bofore click on Uninstall-Sample-Data button, you'll never restore your current store configuration and settings ", 'godecore-data'); ?></p>
                        <?php
                    }
                ?>
            </div>

            <div class="auto-install-loader">
                <p>
                    <?php
                    $auto_install = get_option('listing_xml');
                    if ($auto_install == 0) {
                        esc_html_e('This could take a moment. Please do not close this window until it completes.', 'godecore-data');
                    }
                    if ($auto_install == 1) {
                        esc_html_e('This could take a moment. Please do not close this window until it completes.', 'godecore-data');
                    }
                    ?>
                </p>
            </div>

        </div>
    </div>
</div>        