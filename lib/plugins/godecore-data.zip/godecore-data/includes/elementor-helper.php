<?php

namespace Elementor;

function ved_elementor_init() {
	Plugin::instance()->elements_manager->add_category(
	'godecore-addons', [
		'title'	 => 'Godecore Addons',
		'icon'	 => 'font'
	], 1
	);
}

add_action( 'elementor/init', 'Elementor\ved_elementor_init' );

function ved_enable_elementor() {
	add_post_type_support( 'ved_templates', 'elementor' );
}

add_action( 'elementor/init', 'Elementor\ved_enable_elementor' );

/**
 * Acivate or Deactivate Modules
 *
 * @since 1.0.0
 */
function add_ved_elements() {

	$is_component_active = ved_activated_modules();

//	Content Elements
	if ( $is_component_active[ 'adv-accordion' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/advance-accordion/advance-accordion.php';
	}
	if ( $is_component_active[ 'adv-progressbar' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/advance-progressbar/advance-progressbar.php';
	}
	if ( $is_component_active[ 'adv-tabs' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/advance-tabs/advance-tabs.php';
	}
	if ( $is_component_active[ 'piechart' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/piechart/piechart.php';
	}
	if ( $is_component_active[ 'team-members' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/team-members/team-members.php';
	}
	if ( $is_component_active[ 'testimonials' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/testimonials/testimonials.php';
	}
	if ( $is_component_active[ 'testimonial-slider' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/testimonial-slider/testimonial-slider.php';
	}
	if ( $is_component_active[ 'tooltip' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/tooltip/tooltip.php';
	}
//	Dynamic Content Elements
	if ( $is_component_active[ 'content-slider' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/content-slider/content-slider.php';
	}
	if ( $is_component_active[ 'data-table' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/data-table/data-table.php';
	}
	if ( $is_component_active[ 'post-block' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/post-block/post-block.php';
	}
	if ( $is_component_active[ 'recent-work' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/recent-work/recent-work.php';
	}

	//	Creative Elements
	if ( $is_component_active[ 'adv-gallery' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/advance-gallery/advance-gallery.php';
	}
	if ( $is_component_active[ 'image-slider' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/image-slider/image-slider.php';
	}
	if ( $is_component_active[ 'modalbox' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/modalbox/modalbox.php';
	}

//	Marketing Elements
	if ( $is_component_active[ 'price-list' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/pricing-list/pricing-list.php';
	}
	if ( $is_component_active[ 'price-table' ] ) {
		require_once GODECORE_DATA_PATH . 'elements/pricing-table/pricing-table.php';
	}

//	WooCommerce Elements
	if ( function_exists( 'WC' ) ) {
		if ( $is_component_active[ 'woo-cat-slider' ] ) {
			require_once GODECORE_DATA_PATH . 'elements/woo-cat-slider/woo-cat-slider.php';
		}
		if ( $is_component_active[ 'woo-cat-tab' ] ) {
			require_once GODECORE_DATA_PATH . 'elements/woo-cat-tab/woo-cat-tab.php';
		}
		if ( $is_component_active[ 'woo-product' ] ) {
			require_once GODECORE_DATA_PATH . 'elements/woo-product/woo-product.php';
		}
		if ( $is_component_active[ 'woo-product-deal' ] ) {
			require_once GODECORE_DATA_PATH . 'elements/woo-product-deal/woo-product-deal.php';
		}
		if ( $is_component_active[ 'woo-product-search' ] ) {
			require_once GODECORE_DATA_PATH . 'elements/woo-product-search/woo-product-search.php';
		}
		if ( $is_component_active[ 'woo-product-tab' ] ) {
			require_once GODECORE_DATA_PATH . 'elements/woo-product-tab/woo-product-tab.php';
		}
		if ( $is_component_active[ 'woo-single-column' ] ) {
			require_once GODECORE_DATA_PATH . 'elements/woo-single-column/woo-single-column.php';
		}
	}
}

add_action( 'elementor/widgets/widgets_registered', 'Elementor\add_ved_elements' );

/**
 * Acivate or Deactivate Modules
 *
 * @since 1.0.0
 */
function ved_ajax_select2( $controls_manager ) {
	require_once GODECORE_DATA_PATH . 'includes/controls/select2.php';
	$controls_manager->register_control( 'ajaxselect2', new \Control_Ajax_Select2() );
}

add_action( 'elementor/controls/controls_registered', 'Elementor\ved_ajax_select2' );


