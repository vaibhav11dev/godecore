<?php
/**
 * WooCommerce Product Categories Style One
 */
?>
<div class="cat-item">
	<div class="inner-item">
		<img src="<?php echo GODECORE_DATA_URL ?>assets/images/Categories-pattern-11.png" class="cat-bg-img" alt="cat-bg-img">
		<?php
		if ( $cat_enable_img ) {
			?>
			<div class="cat-img">
				<a class="cat-img" href="<?php echo esc_url( $cat_link ); ?>" title="<?php echo esc_attr( $cat_name ); ?>">
					<img src="<?php echo esc_url( $cat_image[ 'url' ] ); ?>" alt="<?php echo esc_attr( $cat_name ); ?>" />
				</a>
			</div>
		<?php } ?>
		<div class="category-desc">
			<h2 class="categoryName">
				<?php echo esc_html( $cat_name ); ?>
			</h2>
			<div class="cat-shop-btn">
				<a class="cat_btn" href="<?php echo esc_url( $cat_link ); ?>"  title="<?php echo esc_attr( $cat_name ); ?>"><?php esc_html_e( 'Shop Now', 'godecore-data' ) ?></a>
			</div>
		</div>
	</div>
</div>