<?php
/**
 * WooCommerce Product Categories Style One
 */
?>
<div class="cat-item">
	<div class="inner-item">
		<?php
		if ( $cat_enable_img ) {
			?>
			<div class="cat-img">
				<a class="cat-link" href="<?php echo esc_url( $cat_link ); ?>" title="<?php echo esc_attr( $cat_name ); ?>">
					<img src="<?php echo esc_url( $cat_image[ 'url' ] ); ?>" alt="<?php echo esc_attr( $cat_name ); ?>" />
				</a>
			</div>
		<?php } ?>
		<div class="category-desc">
			<h2 class="categoryName">
				<a href="<?php echo esc_url( $cat_link ); ?>"  title="<?php echo esc_attr( $cat_name ); ?>"><?php echo esc_html( $cat_name ); ?></a>
			</h2>
		</div>
	</div>
</div>