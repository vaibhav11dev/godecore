<?php
/**
 * WooCommerce Product Categories Style Six
 */
$cat_tabs = $settings[ 'ved_woo_cats_slider_item' ];
if ( is_array( $cat_tabs ) && count( $cat_tabs ) > 0 ):
	$rand_id = 'ved-tabs-' . mt_rand( 10000, 99999 ) . '-';
	?>
	<ul class="nav nav-tabs ved-nav-tab" role="tablist">
		<?php
		foreach ( $cat_tabs as $key => $cat_item ):
			$active = ($key == 0) ? 'active' : '';
			$cat_slug    = $cat_item[ 'ved_woo_cats_slider_main' ];
			$cat_obj = get_term_by( 'slug', $cat_slug, 'product_cat' );
			if($cat_obj) {
				$cat_name  = get_the_category_by_ID( $cat_obj->term_id );
			} else {
				$cat_name  = '';
			}
			?>
			<li class="nav-item <?php echo esc_attr( $active ) ?>">
				<a class="nav-link"  data-toggle="tab" href="#<?php echo esc_attr($rand_id.$key.'-'.$cat_obj->term_id); ?>" role="tab" ><?php echo esc_html($cat_name); ?></a>
			</li>
		<?php endforeach; ?>
	</ul>
<?php endif; ?>
<div class="tab-content" data-column="<?php echo esc_attr( $columns ) ?>">
<?php 
if ( is_array( $cat_tabs ) && count( $cat_tabs ) > 0 ):
	
	?>
	<?php foreach ( $cat_tabs as $key => $cat_item ):
		$active  = ($key == 0) ? 'active in' : '';
		$cat_image = $cat_item[ 'ved_woo_cats_slider_image' ];
		$cat_slug    = $cat_item[ 'ved_woo_cats_slider_main' ];
		$cat_obj = get_term_by( 'slug', $cat_slug, 'product_cat' );

		if($cat_obj) {
			$cat_name  = get_the_category_by_ID( $cat_obj->term_id );
			$cat_link  = get_category_link( $cat_obj->term_id );
			$cat_desc  = category_description( $cat_obj->term_id );
		} else {
			$cat_name  = '';
			$cat_link  = '';
			$cat_desc  = '';
		}

		?>
		<div class="tab-pane fade <?php echo esc_attr( $active ) ?>" id="<?php echo esc_attr($rand_id.$key.'-'.$cat_obj->term_id); ?>" role="tabpanel">
			<div class="cat-item">
				<div class="inner-item">
					<?php
					if ( $cat_enable_img ) {
						?>
						<div class="cat-img">
							<a class="cate" href="<?php echo esc_url( $cat_link ); ?>" title="<?php echo esc_attr( $cat_name ); ?>">
								<img src="<?php echo esc_url( $cat_image[ 'url' ] ); ?>" alt="<?php echo esc_attr( $cat_name ); ?>" />
							</a>
						</div>
					<?php } ?>
					<div class="category-desc">
						<h2 class="categoryName">
							<?php echo esc_html( $cat_name ); ?>
						</h2>
						<p>
							<?php echo esc_html( strip_tags( $cat_desc ) ); ?>
						</p>
						<div class="cat-shop-btn">
							<a class="cat_btn" href="<?php echo esc_url( $cat_link ); ?>"  title="<?php echo esc_attr( $cat_name ); ?>"><?php esc_html_e( 'Shop Now', 'godecore-data' ) ?></a>
						</div>
					</div>
				</div>
			</div>
        </div>
	<?php endforeach; ?>
<?php endif; ?>

</div>