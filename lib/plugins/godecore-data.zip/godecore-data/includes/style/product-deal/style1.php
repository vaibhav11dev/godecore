<?php
if ( isset( $product_choice ) ) {
	switch ( $product_choice ) {
		case 'random':
			$args[ 'orderby' ]	 = 'rand';
			break;
		case 'recent':
			$args[ 'orderby' ]	 = 'date';
			$args[ 'order' ]	 = 'DESC';
			break;
		case 'specific':
			$args[ 'orderby' ]	 = 'post__in';
			$args[ 'ids' ]		 = $product_id;
			$args[ 'post__in' ]	 = array_map( 'trim', explode( ',', $product_id ) );
			break;
	}
}

$args		 = wp_parse_args( array( 'per_page' => $product_count ), $args );
$args		 = wp_parse_args( $args, $defaults );
$products	 = godecore_sale_products( $args );

//		$style = $args[ 'style' ];
//		$product_count = $args[ 'no_of_product' ];
//		$columns = $args[ 'columns' ];
$found_products	 = $products->post_count;
$cnt			 = 1;

extract( $args );

if ( $products->have_posts() ) {

	while ( $products->have_posts() ) :
		$products->the_post();

		if ( $style == 'style2' && ($found_products >= $columns * 2) && ($product_count >= ($columns * 2)) ) {
			if ( $cnt % 2 != 0 ) {
				echo "<div class='item-inner'>";
			}
		}
		
		global $product;
		?>
		<div class="onsale-products">

			<div class="shop-item-photo">
				<?php 
					do_action( 'vedanta_product_link_open' );
					do_action( 'vedanta_product_thumbnail' );
					do_action( 'vedanta_product_link_close' );
				?>
			</div>
			<div class="shop-item-title">
				<?php 
					do_action( 'vedanta_product_title' );
					do_action( 'vedanta_product_description', $product );
					do_action( 'vedanta_product_price' );
					do_action( 'vedanta_product_rating' );
					do_action( 'vedanta_product_item' );
				?>
			</div>
			<div class="shop-item-timer">
				<?php 
					do_action( 'vedanta_product_countdown_timer', $product );
				?>
			</div>

			<?php if ( $show_savings ) : ?>
			<div class="savings">
				<span class="savings-text">
					<?php
					global $product;
					echo sprintf( '%s %s', $savings_text, godecore_get_savings_on_sale( $product, $savings_in ) );
					?>
				</span>
			</div>
			<?php endif; ?>

		</div>

		<?php
		if ( $style == 'style2' && ($found_products >= $columns * 2) && ($product_count >= ($columns * 2)) ) {
			if ( $cnt % 2 == 0 ) {
				echo '</div>';
			}
		}
		$cnt ++;
	endwhile;

	woocommerce_reset_loop();
	wp_reset_postdata();
}