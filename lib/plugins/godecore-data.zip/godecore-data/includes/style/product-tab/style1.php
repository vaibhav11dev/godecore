<?php
if ( is_array( $product_tab ) && count( $product_tab ) > 0 ):
    foreach ( $product_tab as $key => $tabs_content ):
        $product_filter = $tabs_content[ 'product_content' ];
        $active         = ($key == 0) ? 'active in' : '';
        $tabs_id        = 'ved-tabs-' . $key;
		$args    = array(
			'post_type'      => array( 'product' ),
			'post_status'    => array( 'publish' ),
			'posts_per_page' => $product_count,
		);
		if ( $tabs_content[ 'product_content' ] == 'featured' ) {
			$args[ 'tax_query' ][] = array(
				'taxonomy'         => 'product_visibility',
				'terms'            => 'featured',
				'field'            => 'name',
				'operator'         => 'IN',
				'include_children' => false,
			);
		} elseif ( $tabs_content[ 'product_content' ] == 'best_sell' ) {
			$args[ 'meta_key' ] = 'total_sales';
			$args[ 'orderby' ]  = 'meta_value_num';
		} elseif ( $tabs_content[ 'product_content' ] == 'on_sell' ) {
			$args[ 'meta_query' ] = array(
				array(
					'key'     => '_sale_price',
					'value'   => '',
					'compare' => '!='
				),
			);
		} elseif ( $tabs_content[ 'product_content' ] == 'top_rate' ) {
			$args[ 'meta_key' ]	 = '_wc_average_rating';
			$args[ 'orderby' ]	 = 'meta_value_num';
		}

		$ved_query   = new WP_Query( $args );
		?>
		<div class="tab-pane fade <?php echo esc_attr( $active ) ?>" id="<?php echo esc_attr( $rand_id . $key ); ?>" role="tabpanel">
			<ul class="ved-tab-single-product-slider owl-carousel products grid">
				<?php
				if ( $ved_query->have_posts() ):
					while ($ved_query->have_posts()) : 
						$ved_query->the_post();

						do_action( 'vedanta_woo_before_shop_loop' );

						wc_get_template_part( 'content', 'product' );

					endwhile;
				endif;
				wp_reset_postdata();
				?>
			</ul>
		</div>
        <?php
    endforeach;
endif;