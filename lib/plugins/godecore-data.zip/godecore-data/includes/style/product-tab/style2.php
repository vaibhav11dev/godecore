<?php if ( is_array( $product_tab ) && count( $product_tab ) > 0 ): ?>
    <?php foreach ( $product_tab as $key => $tabs_content ): ?>
        <?php
        $active  = ($key == 0) ? 'active in' : '';
        $tabs_id = 'ved-tabs-' . $key;
        $args    = array(
            'post_type'      => array( 'product' ),
            'post_status'    => array( 'publish' ),
            'posts_per_page' => $product_count,
        );
        if ( $tabs_content[ 'product_content' ] == 'featured' ) {
            $args[ 'tax_query' ][] = array(
                'taxonomy'         => 'product_visibility',
                'terms'            => 'featured',
                'field'            => 'name',
                'operator'         => 'IN',
                'include_children' => false,
            );
        } elseif ( $tabs_content[ 'product_content' ] == 'best_sell' ) {
            $args[ 'meta_key' ] = 'total_sales';
            $args[ 'orderby' ]  = 'meta_value_num';
        } elseif ( $tabs_content[ 'product_content' ] == 'on_sell' ) {
            $args[ 'meta_query' ] = array(
                array(
                    'key'     => '_sale_price',
                    'value'   => '',
                    'compare' => '!='
                ),
            );
        } elseif ( $tabs_content[ 'product_content' ] == 'top_rate' ) {
			$args[ 'meta_key' ]	 = '_wc_average_rating';
			$args[ 'orderby' ]	 = 'meta_value_num';
		}

        $cnt = 1;
        $ved_query   = new WP_Query( $args );
        $found_posts = $ved_query->found_posts;
        ?>
        <div class="tab-pane fade <?php echo esc_attr( $active ) ?>" id="<?php echo esc_attr( $rand_id . $key ); ?>" role="tabpanel">
            <div class="row">
                <ul class="ved-tab-product-slider owl-carousel products grid">
                <?php
                if ( $ved_query->have_posts() ):
                    while ($ved_query->have_posts()) : 
                        $ved_query->the_post();
                        if ( ($found_posts >= $row_columns * 2) && ($product_count >= ($row_columns * 2)) ) {
                            if ( $cnt % 2 != 0 ) {
                                echo "<div class='item-inner'>";
                            }
                        }

						do_action( 'vedanta_woo_before_shop_loop' );

						wc_get_template_part( 'content', 'product' );

                        if ( ($found_posts >= $row_columns * 2) && ($product_count >= ($row_columns * 2)) ) {
                            if ( $cnt % 2 == 0 ) {
                                echo '</div>';
                            }
                        }
                        $cnt ++;
                    endwhile;
                endif;
                wp_reset_postdata();
                ?>
                </ul>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
