<div class="sec-head-style"><h2 class="page-heading text-title"><?php echo esc_html( $head_title ); ?></h2></div>
<?php
    if ( $show_tab && is_array( $product_tab ) && count( $product_tab ) > 0 ):
        $rand_id = 'ved-tabs-' . mt_rand( 10000, 99999 ) . '-';
        ?>
        <ul class="nav nav-tabs ved-nav-tab" role="tablist">
            <?php
            foreach ( $product_tab as $key => $product_tabs ):
				$cat_name = get_term_by( 'slug', $product_tabs, 'product_cat' );
				$active = ($key == 0) ? 'active' : '';
				?>
				<li class="nav-item <?php echo esc_attr( $active ) ?>">
					<a class="nav-link"  data-toggle="tab" href="#<?php echo esc_attr($rand_id.$key.'-'.$cat_name->term_id); ?>" role="tab" ><?php echo esc_html($cat_name->name); ?></a>
				</li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
<div class="tab-content" data-column="<?php echo esc_attr( $columns ) ?>">
<?php 
if ( is_array( $product_tab ) && count( $product_tab ) > 0 ):
	
	?>
	<?php foreach ( $product_tab as $key => $tabs_content ): ?>
		<?php
		$active  = ($key == 0) ? 'active in' : '';
		$cat_name	 = get_term_by( 'slug', $tabs_content, 'product_cat' );
		$args		 = array(
			'post_type'		 => array( 'product' ),
			'post_status'	 => array( 'publish' ),
			'posts_per_page' => $product_count,
			'tax_query'		 => array(
				'relation' => 'AND',
				array(
					'taxonomy'	 => 'product_cat',
					'field'		 => 'slug',
					'terms'		 => $cat_name->slug,
				),
			)
		);
		
		$cnt = 1;
		$ved_query = new WP_Query( $args );
		$found_posts = $ved_query->found_posts;
		?>
		<div class="tab-pane fade <?php echo esc_attr( $active ) ?>" id="<?php echo esc_attr($rand_id.$key.'-'.$cat_name->term_id); ?>" role="tabpanel">
            <div class="row">
                <div class="ved-cat-tab-slider owl-carousel">                
	                <?php
	                if ( $ved_query->have_posts() ):
	                    while ($ved_query->have_posts()) :
	                        $ved_query->the_post();
	                        if ( ($found_posts >= $columns * 2) && ($product_count >= ($columns * 2)) ) {
	                            if ( $cnt % 2 != 0 ) {
	                                echo "<div class='item-inner'>";
	                            }
	                        }

						global $product;
						?>
						<div class="cat-product">
							<div class="shop-item-photo col-xs-6">
								<?php 
									do_action( 'vedanta_product_link_open' );
									do_action( 'vedanta_product_thumbnail' );
									do_action( 'vedanta_product_link_close' );
								?>
							</div>
							<div class="shop-item-title col-xs-6">
								<?php 
									do_action( 'vedanta_product_rating' );
									do_action( 'vedanta_product_title' );								
									do_action( 'vedanta_product_price' );
									//do_action( 'vedanta_product_description', $product );
									do_action( 'vedanta_product_item' );
								?>
							</div>
							<div class="clearfix"></div>
						</div>
						<?php

	                        if ( ($found_posts >= $columns * 2) && ($product_count >= ($columns * 2)) ) {
	                            if ( $cnt % 2 == 0 ) {
	                                echo '</div>';
	                            }
	                        }
	                        $cnt ++;
	                    endwhile;
	                endif;
	                wp_reset_postdata();
	                ?>
                </div>
            </div>
        </div>
	<?php endforeach; ?>
<?php endif; ?>

</div>