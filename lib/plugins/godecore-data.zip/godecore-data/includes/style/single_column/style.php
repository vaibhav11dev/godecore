<?php
        $args    = array(
            'post_type'      => array( 'product' ),
            'post_status'    => array( 'publish' ),
            'posts_per_page' => $single_column_total_count,
        );
        if ( $single_column_filter == 'featured' ) {
            $args[ 'tax_query' ][] = array(
                'taxonomy'         => 'product_visibility',
                'terms'            => 'featured',
                'field'            => 'name',
                'operator'         => 'IN',
                'include_children' => false,
            );
        } elseif ( $single_column_filter == 'related' ) {
            $args[ 'post__in' ] = $product->get_related( 100 );
        } elseif ( $single_column_filter == 'best_sell' ) {
            $args[ 'meta_key' ] = 'total_sales';
            $args[ 'orderby' ]  = 'meta_value_num';
        } elseif ( $single_column_filter == 'on_sell' ) {
            $args[ 'meta_query' ] = array(
                array(
                    'key'     => '_sale_price',
                    'value'   => '',
                    'compare' => '!='
                ),
            );
        }
        $ved_query   = new WP_Query( $args );
		$found_posts = $ved_query->post_count;
		?>

		<div class="product_list_element owl-carousel">
			<ul class="product_list">
				<?php
				$product_sr = 1;
				if ( $ved_query->have_posts() ):
                    while ($ved_query->have_posts()) :
						$ved_query->the_post();
						wc_get_template( 'content-widget-product.php', array( 'show_rating' => true ) );
						if( ($product_sr % $single_column_count) == 0 && $product_sr != $found_posts ){
							?>
							</ul><ul class="product_list">
							<?php
						}
						$product_sr++;
					 endwhile;
                endif;
					wp_reset_postdata();
				?>
			</ul>
		</div>




