<?php
$args = array(
	'post_type'		 => array( 'product' ),
	'post_status'	 => array( 'publish' ),
	'posts_per_page' => $product_count,
);
if ( $product_filter == 'featured' ) {
	$args[ 'tax_query' ][] = array(
		'taxonomy'			 => 'product_visibility',
		'terms'				 => 'featured',
		'field'				 => 'name',
		'operator'			 => 'IN',
		'include_children'	 => false,
	);
} elseif ( $product_filter == 'best_sell' ) {
	$args[ 'meta_key' ]	 = 'total_sales';
	$args[ 'orderby' ]	 = 'meta_value_num';
} elseif ( $product_filter == 'on_sell' ) {
	$args[ 'meta_query' ] = array(
		array(
			'key'		 => '_sale_price',
			'value'		 => '',
			'compare'	 => '!='
		),
	);
} elseif ( $product_filter == 'top_rate' ) {
	$args[ 'meta_key' ]	 = '_wc_average_rating';
	$args[ 'orderby' ]	 = 'meta_value_num';
}
//		elseif ( $tabs_content[ 'product_content' ] == 'related' ) {
//            $args[ 'post__in' ] = $product->get_related( 100 );
//        } 
//		elseif ( $tabs_content[ 'product_content' ] == 'ved_product' ) {
//            if ( ! empty( $tabs_content[ 'product_content' ] ) == 'ved_product' ) {
//                if ( ! empty( $tabs_content[ 'product_ids' ] ) ) {
//                    $args[ 'post__in' ] = $tabs_content[ 'product_ids' ];
//                } else {
//                    $args[ 'post__in' ] = [ 0 ];
//                }
//            }
//        }

$ved_query = new WP_Query( $args );
?>

<ul class="ved-tab-product-slider grid products owl-carousel">
	<?php
	if ( $ved_query->have_posts() ):
		while ( $ved_query->have_posts() ) :
			$ved_query->the_post();

			do_action( 'vedanta_woo_before_shop_loop' );

			wc_get_template_part( 'content', 'product' );

		endwhile;
	endif;
	wp_reset_postdata();
	?>
</ul>