<div id="ved-testimonial-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-testimonial-slider">
            <?php foreach ( $settings[ 'ved_testimonial_slider_item' ] as $item ) : ?>

                <div class="ved-testimonial-item clearfix <?php echo esc_attr( $testimonial_classes ); ?>">
                    <div class="ved-testimonial-content <?php echo esc_attr( $item[ 'ved_testimonial_rating_number' ] ) ?>" <?php if ( $item[ 'ved_testimonial_enable_avatar' ] == '' ) : ?> style="width: 100%;" <?php endif; ?>>
                        <p class="ved-testimonial-text"><?php echo $item[ 'ved_testimonial_description' ]; ?></p>
                        <?php if ( ! empty( $item[ 'ved_testimonial_enable_rating' ] ) ) : ?>
                            <ul class="testimonial-star-rating">
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                            </ul>
                        <?php endif; ?>
                    </div>
                    <div class="ved-testimonial-image">
                        <div class="ved-author-info">
                            <h5 class="ved-testimonial-user" <?php if ( ! empty( $settings[ 'ved_testimonial_user_display_block' ] ) ) : ?> style="display: block; float: none;"<?php endif; ?>><?php echo esc_attr( $item[ 'ved_testimonial_name' ] ); ?></h5>
                            <span class="ved-testimonial-user-company"><?php echo esc_attr( $item[ 'ved_testimonial_company_title' ] ); ?></span>
                        </div>
                        <?php if ( $item[ 'ved_testimonial_enable_avatar' ] == 'yes' ) : ?>
                            <?php
                            $image = $item[ 'ved_testimonial_image' ];
                            ?>
                            <img src="<?php echo esc_url( $image[ 'url' ] ); ?>" alt="<?php echo esc_attr( $item[ 'ved_testimonial_name' ] ); ?>">
                        <?php endif; ?>
                    </div>
                </div>

            <?php endforeach; ?>
        </div>

            <script type="text/javascript">
                jQuery(document).ready(function ($) {
                    var ved_testimonial_sld = $("#ved-testimonial-<?php echo esc_js( $this->get_id() ); ?>");
                     $('.slider-for').slick({
                      slidesToShow: 1,
                      slidesToScroll: 1,
                      arrows: false,
                      fade: true,
                      asNavFor: '.slider-nav'
                    });
                    $('.slider-nav').slick({
                      slidesToShow: 3,
                      slidesToScroll: 1,
                      asNavFor: '.slider-for',
                      dots: true,
                      centerMode: true,
                      focusOnSelect: true
                    });
                });
            </script>