<div class="<?php echo esc_attr( $style ); ?>">
<div id="ved-testimonial-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-testimonial-slider owl-carousel">
            <?php foreach ( $settings[ 'ved_testimonial_slider_item' ] as $item ) : ?>
                <div class="ved-testimonial-item clearfix <?php echo esc_attr( $testimonial_classes ); ?>">

                    <div class="ved-testimonial-image">
                        <?php if ( $item[ 'ved_testimonial_enable_avatar' ] == 'yes' ) : ?>
                            <?php
                            $image = $item[ 'ved_testimonial_image' ];
                            ?>
                            <img src="<?php echo esc_url( $image[ 'url' ] ); ?>" alt="<?php echo esc_attr( $item[ 'ved_testimonial_name' ] ); ?>">
                        <?php endif; ?>

                        <p class="ved-testimonial-text"><?php echo $item[ 'ved_testimonial_description' ]; ?></p>
                        <span class="bor-mdl"></span>
                        <div class="ved-author-info">
                            <h5 class="ved-testimonial-user" <?php if ( ! empty( $settings[ 'ved_testimonial_user_display_block' ] ) ) : ?> style="display: block; float: none;"<?php endif; ?>><?php echo esc_attr( $item[ 'ved_testimonial_name' ] ); ?></h5>
                            <span class="ved-testimonial-user-company"><?php echo esc_attr( $item[ 'ved_testimonial_company_title' ] ); ?></span>
                        </div>
                    </div>

                    <!-- <div class="ved-testimonial-content <?php echo esc_attr( $item[ 'ved_testimonial_rating_number' ] ) ?>" <?php if ( $item[ 'ved_testimonial_enable_avatar' ] == '' ) : ?> style="width: 100%;" <?php endif; ?>>
                        <?php if ( ! empty( $item[ 'ved_testimonial_enable_rating' ] ) ) : ?>
                            <ul class="testimonial-star-rating">
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                <li><i class="fa fa-star" aria-hidden="true"></i></li>
                            </ul>
                        <?php endif; ?>
                    </div> -->
                </div>
            <?php endforeach; ?>
        </div>
    </div>




        <script type="text/javascript">
                jQuery(document).ready(function ($) {
                    setTimeout(function(){
                    var ved_testimonial_sld = $("#ved-testimonial-<?php echo esc_js( $this->get_id() ); ?>");
                    ved_testimonial_sld.owlCarousel({                        
                        autoplay: <?php echo esc_js($autoplay) ? 'true' : 'false'; ?>,
                        rewind:true,
                        nav: <?php echo esc_js($navigation) ? 'true' : 'false'; ?>,
                        dots: <?php echo esc_js($pagination) ? 'true' : 'false'; ?>,
                        items: 1,
                        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
                        responsive:{
                            0:{
                                items:<?php echo esc_js($mob_items); ?>},
                            768:{
                                items:<?php echo esc_js($tab_items); ?>},
                            992:{
                                items:<?php echo esc_js($desk_small_items); ?>},
                            1200:{
                                items:<?php echo esc_js($desk_items); ?>}
                        }                          
                    });
                    });
                });
            </script>