<div id="ved-testimonial-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-testimonial-slider <?php echo esc_attr($style); ?>">
    <div class="testi-slider-for">
    <?php foreach ( $settings[ 'ved_testimonial_slider_item' ] as $item ) : ?>

        <div class="ved-testimonial-item clearfix <?php echo esc_attr( $testimonial_classes ); ?>">
            <div class="testi-sine"></div>
            <div class="ved-testimonial-content <?php echo esc_attr( $item[ 'ved_testimonial_rating_number' ] ) ?>" <?php if ( $item[ 'ved_testimonial_enable_avatar' ] == '' ) : ?> style="width: 100%;" <?php endif; ?>>
                <p class="ved-testimonial-text"><?php echo $item[ 'ved_testimonial_description' ]; ?></p>
            </div>
            <div class="ved-author-info">
                <h5 class="ved-testimonial-user" <?php if ( ! empty( $settings[ 'ved_testimonial_user_display_block' ] ) ) : ?> style="display: block; float: none;"<?php endif; ?>><?php echo esc_attr( $item[ 'ved_testimonial_name' ] ); ?></h5>
                <span>-</span>
                <span class="ved-testimonial-user-company"><?php echo esc_attr( $item[ 'ved_testimonial_company_title' ] ); ?></span>
            </div>
        </div>
    <?php endforeach; ?>
    </div>

    <div class="testi-slider-nav">
    <?php foreach ( $settings[ 'ved_testimonial_slider_item' ] as $item ) : ?>

        <div class="ved-testimonial-item clearfix <?php echo esc_attr( $testimonial_classes ); ?>">
            <div class="ved-testimonial-image">
                <?php if ( $item[ 'ved_testimonial_enable_avatar' ] == 'yes' ) : ?>
                    <?php
                    $image = $item[ 'ved_testimonial_image' ];
                    ?>
                    <img src="<?php echo esc_url( $image[ 'url' ] ); ?>" alt="<?php echo esc_attr( $item[ 'ved_testimonial_name' ] ); ?>">
                <?php endif; ?>
            </div>
        </div>

    <?php endforeach; ?>
    </div>
</div>

<script type="text/javascript">
    jQuery(document).ready(function ($) {
         $('#ved-testimonial-<?php echo esc_js( $this->get_id() ); ?> .testi-slider-for').slick({
          slidesToShow: 1,
          slidesToScroll: 1,
          arrows: false,
          fade: true,
          dots:false,
          asNavFor: '#ved-testimonial-<?php echo esc_js( $this->get_id() ); ?> .testi-slider-nav'
        });
        $('#ved-testimonial-<?php echo esc_js( $this->get_id() ); ?> .testi-slider-nav').slick({
          slidesToShow: 3,
          slidesToScroll: 1,
          asNavFor: '#ved-testimonial-<?php echo esc_js( $this->get_id() ); ?> .testi-slider-for',
          dots: false,
          arrows: false,
          centerMode:true,
          focusOnSelect: true
        }); 
    });
</script>