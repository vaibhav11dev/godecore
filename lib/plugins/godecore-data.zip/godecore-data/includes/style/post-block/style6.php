<div class="<?php echo esc_attr( $post_column_class ); ?>">
    <article class="ved-post-item">
        <?php if ( $settings[ 'ved_show_image' ] == 1 ) { ?>
            <div class="ved-post-preview">
                <?php if ( $thumbnail_exists = has_post_thumbnail() ): ?>
                    <a class="ved-post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true"><img alt src="<?php echo esc_url( wp_get_attachment_image_url( get_post_thumbnail_id(), $settings[ 'image_size' ] ) ) ?>"> </a>
                   <!--  <span class="blogicons">
                        <a href="<?php echo esc_url( get_the_post_thumbnail_url( get_the_ID(), 'full' ) ); ?>" class="icon zoom ti-search"></a> 
                        <a title="Click to view Read More" href="<?php the_permalink(); ?>" class="icon readmore ti-link"></a>
                    </span> -->
                <?php endif; ?>
            </div>
        <?php } ?>

        <div class="ved-post-content">
            <div class="post_date">    
                <?php if ( $settings[ 'ved_post_block_meta_date' ] == 'yes' ) { ?>
                    <p class="meta_date">
                        <span class="day_month"><?php the_time( 'M' ) ?></span>
                        <span class="day_date"><?php the_time( 'j' ) ?> , </span>
                        <span class="day_year"><?php the_time( 'Y' ) ?></span></p>
                <?php } ?>    
            </div>

            <div class="post_info">
                <?php if ( $settings[ 'ved_show_title' ] ) { ?>
                    <h2 class="ved-post-title"><a class="ved-post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true"><?php the_title(); ?></a></h2>
                <?php } ?>

                <?php if ( $settings[ 'ved_show_meta' ] && $settings[ 'ved_post_block_meta_position' ] == 'meta-entry-header' ) { ?>    
                    <ul class="ved-post-meta">
                        <?php godecore_post_metadata( $settings ); ?> 
                    </ul>
                <?php } ?>

                 <div class="ved-post-excerpt">
                    <?php if ( $settings[ 'ved_show_excerpt' ] ) { ?>
                        <p><?php echo godecore_get_excerpt_by_id( get_the_ID(), $settings[ 'ved_excerpt_length' ] ); ?></p>
                    <?php } ?>
                </div>

                <!-- <?php if ( $settings[ 'ved_show_meta' ] && $settings[ 'ved_post_block_meta_position' ] == 'meta-entry-footer' ) { ?>   
                    <ul class="ved-post-meta">
                        <?php godecore_post_metadata( $settings ); ?> 
                    </ul>
                <?php } ?>  -->       
                <div class="ved-post-link">
                    <a href="<?php the_permalink() ?>" class="read-more"><?php esc_html_e( 'Read more', 'godecore-data' ) ?><i class="fa fa-angle-double-right"></i></a>
                </div>
            </div>
        </div>
    </article>
</div>