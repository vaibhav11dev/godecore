<?php
/**
 *
 * Plugin Name: GoDecore Data
 * Plugin URI: http://webheaythemes.co.uk
 * Description: Data functionality of webheaythemes
 * Version: 1.0.0
 * Author: webheaythemes
 * Author URI: http://webheaythemes.co.uk
 *
 */
if ( ! defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly


// Define path to this plugin file
define( 'GODECORE_DATA_URL', plugins_url( '/', __FILE__ ) );
define( 'GODECORE_DATA_PATH', plugin_dir_path( __FILE__ ) );
define( 'GODECORE_DATA_ROOT', __FILE__ );
define( 'GODECORE_SAMPLE_DATA', 'http://webheaythemes.co.uk/yam5' );

require_once GODECORE_DATA_PATH . 'includes/elementor-helper.php';
require_once GODECORE_DATA_PATH . 'includes/manager/controls.php';
require_once GODECORE_DATA_PATH . 'includes/restapi/ajax-select2.php';
require_once GODECORE_DATA_PATH . 'includes/data-functions.php';
require_once GODECORE_DATA_PATH . 'includes/elementor-addons.php';

if ( ! class_exists( 'GoDecore_Data_Plugin' ) ) :

    class GoDecore_Data_Plugin {

        /**
         * Initialize the plugin by setting localization and loading public scripts
         * and styles.
         *
         * @since     1.0.0
         */
        public function __construct() {
            add_action( 'admin_enqueue_scripts', array( $this, 'godecore_data_admin_scripts' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'godecore_data_addons_scripts' ) );
            add_action( 'after_setup_theme', array( $this, 'godecore_data_text_domain' ) );
        }

		/**
         * Enqueue admin scripts and styles.
		 * 
		 * @since 1.0.0 
         */
        public static function godecore_data_admin_scripts( $hook ) {
            if ( $hook == 'toplevel_page_godecore-menu' || $hook == 'godecore_page_godecore_demos' || $hook == 'appearance_page_godecore_options' || $hook == 'godecore_page_godecore-addons' ) {
                wp_enqueue_style( 'ved-admin', GODECORE_DATA_URL . 'admin/assets/css/ved-admin.css', '', '' );
                wp_enqueue_style( 'font-awesomecss', GODECORE_DATA_URL . 'admin/assets/css/font-awesome.min.css', '', '4.7.0' );
            }
            
            if ( isset( $_GET[ 'page' ] ) && ( $_GET[ 'page' ] == 'godecore-addons' ) ) {
                wp_enqueue_style( 'godecore_addons_elementor-admin-css', GODECORE_DATA_URL . 'admin/assets/css/addons-admin.css' );
                wp_enqueue_script( 'godecore_addons_elementor-admin-js', GODECORE_DATA_URL . 'admin/assets/js/godecore-addons.js', array( 'jquery', 'jquery-ui-tabs' ), '1.0', true );
                wp_enqueue_script( 'godecore_addons_core-js', GODECORE_DATA_URL . 'admin/assets/js/core.js', array( 'jquery' ), '1.0', true );
                wp_enqueue_script( 'godecore_addons_sweetalert2-js', GODECORE_DATA_URL . 'admin/assets/js/sweetalert2.min.js', array( 'jquery', 'godecore_addons_core-js' ), '1.0', true );
            }

            wp_enqueue_script( 'ved-oneclick', GODECORE_DATA_URL . 'admin/assets/js/ved-oneclick.js', array( 'jquery' ), '' );
            wp_localize_script( 'ved-oneclick', 'js_strings', array(
                'ajaxurl'            => admin_url( 'admin-ajax.php' ),
                'select_demo_notice' => esc_html__( 'select demo', 'godecore-data' ),
            ) );

            wp_enqueue_script( 'jquery-ui-datepicker', array( 'jquery' ) );
            wp_enqueue_style( 'jquery-ui-datepicker' );
            wp_enqueue_script( 'jquery-ui-dialog' );
        }

        /**
         * Load module's scripts and styles if any module is active.
         *
         * @since 1.0.0
         */
        public static function godecore_data_addons_scripts() {
            $is_component_active = ved_activated_modules();

            wp_enqueue_style( 'godecore_addons_elementor', GODECORE_DATA_URL . 'assets/css/godecore-addons.css' );
            wp_enqueue_script( 'godecore-addons', GODECORE_DATA_URL . 'assets/js/godecore-addons.js', array( 'jquery' ), '1.0', true );
            wp_localize_script( 'godecore-addons', 'godecore_options', array(
                'deal_countdown_text'            => array(
				'days_text'		=> esc_html__( 'Days', 'godecore-data' ),
				'hours_text'	=> esc_html__( 'Hours', 'godecore-data' ),
				'mins_text'		=> esc_html__( 'Mins', 'godecore-data' ),
				'secs_text'		=> esc_html__( 'Secs', 'godecore-data' ),
			),
            ) );

            if ( $is_component_active[ 'modalbox' ] ) {
                wp_enqueue_style( 'godecore_addons_modalbox', GODECORE_DATA_URL . 'assets/css/lity.min.css' );
                wp_enqueue_script( 'godecore_addons_elementor-modalbox-js', GODECORE_DATA_URL . 'assets/js/lity.min.js', array( 'jquery' ), '1.0', true );
            }

            if ( $is_component_active[ 'data-table' ] ) {
                wp_enqueue_script( 'godecore_addons_elementor-data-table-js', GODECORE_DATA_URL . 'assets/js/jquery.tablesorter.min.js', array( 'jquery' ), '1.0', true );
            }
						
			if ( $is_component_active[ 'adv-gallery' ] ) {
                wp_enqueue_script( 'godecore_addons_elementor-adv-gallery-js', GODECORE_DATA_URL . 'assets/js/gallery.min.js', array( 'jquery' ), '1.0', true );
            }
        }

        /**
         * Register the plugin text domain
         *
         * @return void
         */
        public static function godecore_data_text_domain() {
            load_plugin_textdomain( 'godecore-data', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
        }

} // Close GoDecore_Data_Plugin()

	$godecore_data_plugin = new GoDecore_Data_Plugin();
endif;

/**
 * Initialize theme admin dashboard
 */
function godecore_data_admin_bar() {
	if ( current_user_can( 'manage_options' ) ) {
		require_once GODECORE_DATA_PATH . 'admin/godecore-menu-panel.php';
	}
}

add_action( 'plugins_loaded', 'godecore_data_admin_bar' );
