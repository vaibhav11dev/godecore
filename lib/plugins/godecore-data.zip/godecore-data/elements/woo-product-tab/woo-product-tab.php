<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

if ( ! class_exists( 'Widget_Ved_Product_Tab' ) ) :
class Widget_Ved_Product_Tab extends Widget_Base {

    public $base;

    public function get_name() {
        return 'ved-woo-product-tab';
    }

    public function get_title() {
        return esc_html__( 'Ved Product Tab', 'godecore-data' );
    }

    public function get_icon() {
        return 'eicon-woocommerce';
    }

    public function get_categories() {
        return [ 'godecore-addons' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
        'section_tab', [
            'label' => esc_html__( 'Ved Product element', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_head_title', [
            'label'       => esc_html__( 'Heading Title', 'godecore-data' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( 'Featured Product', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_sub_title', [
            'label'       => esc_html__( 'Sub Title', 'godecore-data' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
        ]
        );

        $this->add_control(
        'ved_product_style', [
            'label'   => esc_html__( 'Style', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'style1',
            'options' => [
                'style1' => esc_html__( 'Single Row', 'godecore-data' ),
                'style2' => esc_html__( 'Double Row', 'godecore-data' ),
            ],
        ]
        );

        $this->add_control(
        'ved_product_count', [
            'label'   => esc_html__( 'Products Count', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 1000,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_show_tab', [
            'label'     => esc_html__( 'Show Tab', 'godecore-data' ),
            'type'      => Controls_Manager::SWITCHER,
            'label_on'  => esc_html__( 'Yes', 'godecore-data' ),
            'label_off' => esc_html__( 'No', 'godecore-data' ),
            'default'   => 'yes',
        ]
        );

        $this->add_control(
        'ved_product_rating', [
            'label'     => esc_html__( 'Show Review', 'godecore-data' ),
            'type'      => Controls_Manager::SWITCHER,
            'label_on'  => esc_html__( 'Yes', 'godecore-data' ),
            'label_off' => esc_html__( 'No', 'godecore-data' ),
            'default'   => 'yes',
        ]
        );
		
		$this->add_control(
        'ved_product_banner', [
            'label'     => esc_html__( 'Show Banner', 'godecore-data' ),
            'type'      => Controls_Manager::SWITCHER,
            'label_on'  => esc_html__( 'Yes', 'godecore-data' ),
            'label_off' => esc_html__( 'No', 'godecore-data' ),
            'default'   => 'no',
        ]
        );
		
		$this->add_control(
        'ved_product_banner_pos', [
            'label'   => esc_html__( 'Banner Postion', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'left',
            'options' => [
                'left' => esc_html__( 'Left', 'godecore-data' ),
                'right' => esc_html__( 'Right', 'godecore-data' ),
            ],
			'condition'    => [
                'ved_product_banner' => 'yes',
            ]
        ]
        );
		
		$this->add_control( 
		 'ved_product_banner_img',	[
				'label'     => esc_html__( 'Banner Image', 'godecore-data' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'ved_product_banner' => 'yes',
				],
			]
		);
		
		$this->add_control( 
		 'ved_product_banner_link',	[
                    'label'         => esc_html__( 'Banner Image Link', 'godecore-data' ),
                    'type'          => Controls_Manager::URL,
                    'default'       => [
                        'url'         => '#',
                        'is_external' => '',
                    ],
                    'show_external' => true,
                    'condition'     => [
                        'ved_product_banner' => 'yes'
                    ]
                ]
		);

        $this->add_control(
        'ved_product_tab', [
            'label'     => esc_html__( 'Product Tabs', 'godecore-data' ),
            'type'      => Controls_Manager::REPEATER,
            'separator' => 'before',
            'default'   => [
                [
                    'product_title'   => esc_html__( 'On Sell', 'godecore-data' ),
                    'product_content' => 'recent',
                ],
                [
                    'product_title'   => esc_html__( 'Hot Sell', 'godecore-data' ),
                    'product_content' => 'featured',
                ],
                [
                    'product_title'   => esc_html__( 'Best Sell', 'godecore-data' ),
                    'product_content' => 'best_sell',
                ],
            ],
            'fields'    => [
                [
                    'name'        => 'product_title',
                    'label'       => esc_html__( 'Title', 'godecore-data' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                ],
                [
                    'name'    => 'product_content',
                    'label'   => esc_html__( 'Product Attribute', 'godecore-data' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'recent',
                    'options' => [
                        'recent'    => esc_html__( 'Recent Product', 'godecore-data' ),
                        'featured'  => esc_html__( 'Featured Product', 'godecore-data' ),
                        'best_sell' => esc_html__( 'Popular Product', 'godecore-data' ),
                        'on_sell'   => esc_html__( 'Sale Product', 'godecore-data' ),
                        'top_rate'  => esc_html__( 'Top Rated Products', 'godecore-data' ),
                    ],
                ],
            ],
        ]
        );

        $this->end_controls_section();
        
        $this->start_controls_section(
        'ved_section_product_tab_slider_settings', [
            'label' => esc_html__( 'Product Tab Slider Settings', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_product_tab_desk_items', [
            'label'   => esc_html__( 'Show Desktop Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_product_tab_desk_small_items', [
            'label'   => esc_html__( 'Show Desktop Small Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 3,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );
        
        $this->add_control(
        'ved_product_tab_tab_items', [
            'label'   => esc_html__( 'Show Tab Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 3,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_product_tab_mob_items', [
            'label'   => esc_html__( 'Show Mobile Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 2,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_product_tab_slider_autoplay', [
            'label'        => esc_html__( 'AutoPlay', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_product_tab_slider_navigation', [
            'label'        => esc_html__( 'Navigation', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_product_tab_slider_pagination', [
            'label'        => esc_html__( 'Pagination', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'section_style', [
            'label' => esc_html__( 'Style', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
        );
        $this->add_control(
        'tab_title_color', [
            'label'     => esc_html__( 'Tab Title color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-nav-tab .nav-link' => 'color: {{VALUE}};'
            ],
        ]
        );
        $this->add_control(
        'tab_title_hover_color', [
            'label'     => esc_html__( 'Tab Title Active & Hover color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-nav-tab .nav-link.active, .ved-nav-tab .nav-link:hover' => 'color: {{VALUE}};'
            ],
        ]
        );
        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'tab_title_typography',
            'selector' => '{{WRAPPER}} .ved-nav-tab .nav-item .nav-link',
        ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings        = $this->get_settings();

        // Slider Options
        $desk_items      = $settings[ 'ved_product_tab_desk_items' ];
        $desk_small_items      = $settings[ 'ved_product_tab_desk_small_items' ];
        $tab_items      = $settings[ 'ved_product_tab_tab_items' ];
        $mob_items      = $settings[ 'ved_product_tab_mob_items' ];
        $autoplay   = $settings[ 'ved_product_tab_slider_autoplay' ];
        $navigation = $settings[ 'ved_product_tab_slider_navigation' ];
        $pagination = $settings[ 'ved_product_tab_slider_pagination' ];

        $style     = $settings[ 'ved_product_style' ];
        $product_banner     = $settings[ 'ved_product_banner' ];
        $product_banner_pos     = $settings[ 'ved_product_banner_pos' ];
        $product_banner_img     = $settings[ 'ved_product_banner_img' ];
        $product_tab     = $settings[ 'ved_product_tab' ];
        $head_title      = $settings[ 'ved_head_title' ];
        $sub_title      = $settings[ 'ved_sub_title' ];
        $row_columns         = $settings[ 'ved_product_tab_desk_items' ];
        $product_count   = $settings[ 'ved_product_count' ];
        $show_tab        = $settings[ 'ved_show_tab' ];

        $product_class = ( ($settings[ 'ved_product_rating' ] == 'yes') ? "show_rating" : "hide_rating" );
		$banner_class = '';
		$content_class = 'col-sm-12';
		if($product_banner){
			$banner_class = 'visible-lg col-lg-3 banner-col';
			$content_class = 'col-md-12 col-lg-9';
		}
        ?>
        <div id="ved-woo-product-tab-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-woo-product-tab <?php echo esc_attr( $product_class ); ?>">
            <div class="sec-head-style">
                <h2 class="page-heading text-title"><?php echo esc_html( $head_title ); ?></h2>
                <p class="page-subheading"><?php echo esc_html( $sub_title ); ?></p>
                <?php
                if ( $show_tab && is_array( $product_tab ) && count( $product_tab ) > 0 ):
                    $rand_id = 'ved-tabs-' . mt_rand( 10000, 99999 ) . '-';
                    ?>
                    <ul class="nav nav-tabs ved-nav-tab" role="tablist">
                        <?php
                        foreach ( $product_tab as $key => $product_tabs ):
                            $active = ($key == 0) ? 'active' : '';
                            ?>
                            <li class="nav-item <?php echo esc_attr( $active ) ?>">
                                <a class="nav-link"  data-toggle="tab" href="#<?php echo esc_attr( $rand_id . $key ); ?>" role="tab" ><?php echo esc_html( $product_tabs[ 'product_title' ] ); ?></a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                <div class="clearfix"></div>
            </div>
            <div class="row">
    			<?php if($product_banner && $product_banner_pos == 'left'){ ?>
    				<div class="<?php echo esc_attr($banner_class); ?>">
						<?php
							$ved_banner_link = $settings[ 'ved_product_banner_link' ][ 'url' ]? $settings[ 'ved_product_banner_link' ][ 'url' ] : '#';
							$target         = $settings[ 'ved_product_banner_link' ][ 'is_external' ] ? 'target="_blank"' : '';
							$nofollow       = $settings[ 'ved_product_banner_link' ][ 'nofollow' ] ? 'rel="nofollow"' : '';
						?>
						<a href="<?php echo esc_url( $ved_banner_link ); ?>" <?php echo esc_attr( $target ); ?> <?php echo esc_attr( $nofollow ); ?>>
							<img src="<?php echo esc_url( $product_banner_img[ 'url' ] ); ?>" alt="<?php echo esc_attr($head_title); ?>" />
						</a>
    				</div>
    			<?php } ?>
                <div class="tab-content <?php echo esc_attr($content_class); ?>" data-column="<?php echo esc_attr( $row_columns ) ?>">
                    <?php
                    switch ( $style ) {
                        case 'style1':
                            require GODECORE_DATA_PATH . 'includes/style/product-tab/style1.php';
                            break;

                        case 'style2':
                            require GODECORE_DATA_PATH . 'includes/style/product-tab/style2.php';
                            break;
                    }
                    ?>
                </div>
    			<?php if($product_banner && $product_banner_pos == 'right'){ ?>
    				<div class="<?php echo esc_attr($banner_class); ?>">
						<?php
							$ved_banner_link = $settings[ 'ved_product_banner_link' ][ 'url' ]? $settings[ 'ved_product_banner_link' ][ 'url' ] : '#';
							$target         = $settings[ 'ved_product_banner_link' ][ 'is_external' ] ? 'target="_blank"' : '';
							$nofollow       = $settings[ 'ved_product_banner_link' ][ 'nofollow' ] ? 'rel="nofollow"' : '';
						?>
						<a href="<?php echo esc_url( $ved_banner_link ); ?>" <?php echo esc_attr( $target ); ?> <?php echo esc_attr( $nofollow ); ?>>
							<img src="<?php echo esc_url( $product_banner_img[ 'url' ] ); ?>" alt="<?php echo esc_attr($head_title); ?>" />
						</a>
    				</div>
    			<?php } ?>
            </div>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                setTimeout(function(){ 
                var ved_tab_sld = $("#ved-woo-product-tab-<?php echo esc_js( $this->get_id() ); ?> .ved-tab-single-product-slider, #ved-woo-product-tab-<?php echo esc_js( $this->get_id() ); ?> .ved-tab-product-slider");
                ved_tab_sld.owlCarousel({
                    autoplay: <?php echo esc_js($autoplay) ? 'true' : 'false'; ?>,
                    nav: <?php echo esc_js($navigation) ? 'true' : 'false'; ?>,
                    dots: <?php echo esc_js($pagination) ? 'true' : 'false'; ?>,
                    items: <?php echo esc_js($desk_items); ?>,
                    loop:false,
                    rewind:true,
                    navText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],   
                    responsive:{
                        0:{
                            items:<?php echo esc_js($mob_items); ?>},
                        768:{
                            items:<?php echo esc_js($tab_items); ?>},
                        992:{
                            items:<?php echo esc_js($desk_small_items); ?>},
                        1200:{
                            items:<?php echo esc_js($desk_items); ?>}
                    }            
                });
                });
            });
        </script>
            <?php
            }

            protected function _content_template() {
                
            }

        }

        Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Product_Tab() );
        endif;