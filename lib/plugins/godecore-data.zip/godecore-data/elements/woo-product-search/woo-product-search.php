<?php
namespace Elementor;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

if ( ! class_exists( 'Widget_Ved_Product_Search' ) ) :
class Widget_Ved_Product_Search extends Widget_Base {

    public function get_name() {
        return 'ved-woo-product-search';
    }

    public function get_title() {
        return esc_html__( 'Ved Product Search', 'godecore-data' );
    }

    public function get_icon() {
        return 'eicon-woocommerce';
    }

    public function get_categories() {
        return [ 'godecore-addons' ];
    }

    protected function _register_controls() {

        // Content Controls
        $this->start_controls_section(
        'ved_section_product_search_settings', [
            'label' => esc_html__( 'Product Search Settings', 'godecore-data' )
        ]
        );

        $this->add_control(
        'ved_product_search_title', [
            'label'       => esc_html__( 'Heading Title', 'godecore-data' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
        ]
        );

        $this->add_control(
        'ved_show_allcategory', [
            'label'     => esc_html__( 'Show All Category', 'godecore-data' ),
            'type'      => Controls_Manager::SWITCHER,
            'label_on'  => esc_html__( 'Yes', 'godecore-data' ),
            'label_off' => esc_html__( 'No', 'godecore-data' ),
            'default'   => 'yes',
        ]
        );

		$this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();


        $show_allcategory = ( ($settings[ 'ved_show_allcategory' ] == 'yes') ? "show_category" : "hide_category" );
		
		if ( isset( $settings[ 'ved_product_search_title' ] ) && $settings[ 'ved_product_search_title' ] ) { ?>
            <div class="sec-head-style">
                <h3 class="text-title text-uppercase page-heading"><?php echo esc_html( $settings[ 'ved_product_search_title' ] ); ?></h3>
            </div>
        <?php } ?>

		<div id="ved-woo-product-search-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-woo-product-search <?php echo esc_attr( $show_allcategory ); ?>">
			<?php
				if ( function_exists( 'vedanta_header_search' ) ) :
					vedanta_header_search();
				endif;
			?>
		</div>
		<?php
    }

    protected function content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Product_Search() );
endif;