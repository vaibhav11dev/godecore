<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

if ( ! class_exists( 'Widget_Ved_Modalbox' ) ) :
class Widget_Ved_Modalbox extends Widget_Base {

	public function get_name() {
		return 'ved-modalbox';
	}

	public function get_title() {
		return esc_html__( 'Ved Modalbox', 'godecore-data' );
	}

	public function get_icon() {
		return 'fa fa-eye';
	}

	public function get_categories() {
		return [ 'godecore-addons' ];
	}

	protected function _register_controls() {

		// Content Controls
		$this->start_controls_section(
		'ved_section_modalbox_content', [
			'label' => esc_html__( 'Modalbox Content', 'godecore-data' )
		]
		);

		$this->add_control(
		'ved_modalbox_type', [
			'label'		 => esc_html__( 'Modalbox Type', 'godecore-data' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'modalbox_type_content',
			'options'	 => [
				'modalbox_type_image'	 => esc_html__( 'Image', 'godecore-data' ),
				'modalbox_type_content'	 => esc_html__( 'HTML Content', 'godecore-data' ),
				'modalbox_type_url'	 => esc_html__( 'External URL (Page/Video/Map)', 'godecore-data' ),
			],
		]
		);


		$this->add_control(
		'ved_modalbox_type_image', [
			'label'		 => esc_html__( 'Choose Modalbox Image', 'godecore-data' ),
			'type'		 => Controls_Manager::MEDIA,
			'default'	 => [
				'url' => Utils::get_placeholder_image_src(),
			],
			'condition'	 => [
				'ved_modalbox_type' => 'modalbox_type_image',
			],
		]
		);
		$this->add_control(
		'ved_modalbox_text_type', [
			'label'		 => esc_html__( 'Content Type', 'godecore-data' ),
			'type'		 => Controls_Manager::SELECT,
			'options'	 => [
				'content'	 => esc_html__( 'Content', 'godecore-data' ),
				'template'	 => esc_html__( 'Saved Templates', 'godecore-data' ),
			],
			'default'	 => 'content',
			'condition'	 => [
				'ved_modalbox_type' => 'modalbox_type_content'
			]
		]
		);

		$this->add_control(
		'ved_primary_templates', [
			'label'		 => esc_html__( 'Choose Template', 'godecore-data' ),
			'type'		 => Controls_Manager::SELECT,
			'options'	 => godecore_get_page_templates(),
			'condition'	 => [
				'ved_modalbox_text_type' => 'template',
			],
		]
		);
		$this->add_control(
		'ved_modalbox_type_content', [
			'label'		 => esc_html__( 'Add your content here (HTML/Shortcode)', 'godecore-data' ),
			'type'		 => Controls_Manager::WYSIWYG,
			'default'	 => esc_html__( 'Add your popup content here', 'godecore-data' ),
			'condition'	 => [
				'ved_modalbox_type'	 => 'modalbox_type_content',
				'ved_modalbox_text_type' => 'content',
			],
			'dynamic'	 => [ 'active' => true ]
		]
		);

		$this->add_control(
		'ved_modalbox_type_url', [
			'label'		 => esc_html__( 'Provide Page/Video/Map URL', 'godecore-data' ),
			'type'		 => Controls_Manager::TEXT,
			'label_block'	 => true,
			'default'	 => '',
			'placeholder'	 => esc_html__( 'Place Page/Video/Map URL', 'godecore-data' ),
			'title'		 => esc_html__( 'Place Page/Video/Map URL', 'godecore-data' ),
			'condition'	 => [
				'ved_modalbox_type' => 'modalbox_type_url',
			],
		]
		);


		$this->end_controls_section();


		// Settings Controls
		$this->start_controls_section(
		'ved_section_modalbox_settings', [
			'label' => esc_html__( 'Modalbox Trigger Settings', 'godecore-data' )
		]
		);

		$this->add_control(
		'ved_modalbox_trigger_type', [
			'label'		 => esc_html__( 'Trigger Modalbox on', 'godecore-data' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'ved_modalbox_trigger_button',
			'options'	 => [
				'ved_modalbox_trigger_button'	 => esc_html__( 'Button Click', 'godecore-data' ),
				'ved_modalbox_trigger_external'	 => esc_html__( 'External Element', 'godecore-data' ),
				'ved_modalbox_trigger_pageload'	 => esc_html__( 'Page Load', 'godecore-data' ),
			],
		]
		);


		$this->add_control(
		'ved_modalbox_trigger_external', [
			'label'		 => esc_html__( 'Element Identifier', 'godecore-data' ),
			'type'		 => Controls_Manager::TEXT,
			'label_block'	 => true,
			'default'	 => '#modal-box',
			'placeholder'	 => esc_html__( '#modal-box', 'godecore-data' ),
			'title'		 => esc_html__( '#modal-box', 'godecore-data' ),
			'description'	 => esc_html__( 'You can also use class identifier such as <strong>.modal-box</strong>', 'godecore-data' ),
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_external',
			],
		]
		);

		$this->add_control(
		'ved_modalbox_trigger_pageload', [
			'label'		 => esc_html__( 'Delay (Seconds)', 'godecore-data' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 1,
			],
			'range'		 => [
				'ms' => [
					'min'	 => 1,
					'max'	 => 100,
				],
			],
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_pageload',
			],
		]
		);

		// generate button for modal

		$this->add_control(
		'ved_modalbox_open_btn', [
			'label'		 => esc_html__( 'Button Text', 'godecore-data' ),
			'type'		 => Controls_Manager::TEXT,
			'default'	 => esc_html__( 'Modal Box Here', 'godecore-data' ),
			'description'	 => esc_html__( 'Open modal with this button', 'godecore-data' ),
			'separator'	 => 'before',
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			],
		]
		);

		$this->add_control(
		'ved_modalbox_open_btn_icon', [
			'label'		 => esc_html__( 'Icon', 'godecore-data' ),
			'type'		 => Controls_Manager::ICON,
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			],
		]
		);

		$this->add_control(
		'ved_modalbox_open_btn_icon_align', [
			'label'		 => esc_html__( 'Icon Position', 'godecore-data' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'left',
			'options'	 => [
				'left'	 => esc_html__( 'Before', 'godecore-data' ),
				'right'	 => esc_html__( 'After', 'godecore-data' ),
			],
			'condition'	 => [
				'ved_modalbox_open_btn_icon!'	 => '',
				'ved_modalbox_trigger_type'	 => 'ved_modalbox_trigger_button',
			],
		]
		);

		$this->add_control(
		'ved_modalbox_open_btn_icon_indent', [
			'label'		 => esc_html__( 'Icon Spacing', 'godecore-data' ),
			'type'		 => Controls_Manager::SLIDER,
			'range'		 => [
				'px' => [
					'max' => 50,
				],
			],
			'condition'	 => [
				'ved_modalbox_open_btn_icon!'	 => '',
				'ved_modalbox_trigger_type'	 => 'ved_modalbox_trigger_button',
			],
			'selectors'	 => [
				'{{WRAPPER}} .open-pop-up-button-icon-right'	 => 'margin-left: {{SIZE}}px;',
				'{{WRAPPER}} .open-pop-up-button-icon-left'	 => 'margin-right: {{SIZE}}px;',
			],
		]
		);



		$this->add_responsive_control(
		'ved_modalbox_open_btn_alignment', [
			'label'		 => esc_html__( 'Alignment', 'godecore-data' ),
			'separator'	 => 'before',
			'type'		 => Controls_Manager::CHOOSE,
			'label_block'	 => true,
			'options'	 => [
				'left'	 => [
					'title'	 => esc_html__( 'Left', 'godecore-data' ),
					'icon'	 => 'fa fa-align-left',
				],
				'center' => [
					'title'	 => esc_html__( 'Center', 'godecore-data' ),
					'icon'	 => 'fa fa-align-center',
				],
				'right'	 => [
					'title'	 => esc_html__( 'Right', 'godecore-data' ),
					'icon'	 => 'fa fa-align-right',
				],
			],
			'default'	 => 'center',
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-btn' => 'text-align: {{VALUE}}',
			],
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			],
		]
		);


		$this->add_control(
		'ved_modalbox_open_btn_padding', [
			'label'		 => esc_html__( 'Padding', 'godecore-data' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-open-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			],
		]
		);

		$this->add_control(
		'ved_modalbox_open_btn_border_radius', [
			'label'		 => esc_html__( 'Button Border Radius', 'godecore-data' ),
			'type'		 => Controls_Manager::SLIDER,
			'range'		 => [
				'px' => [
					'min'	 => 0,
					'max'	 => 100,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-open-btn' => 'border-radius: {{SIZE}}{{UNIT}};',
			],
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_modalbox_open_btn_typography',
			'scheme'	 => Scheme_Typography::TYPOGRAPHY_1,
			'selector'	 => '{{WRAPPER}} .ved-modalbox-open-btn',
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			],
		]
		);

		$this->start_controls_tabs( 'ved_modalbox_open_btn_content_tabs' );

		$this->start_controls_tab( 'normal_default_content', [ 'label'		 => esc_html__( 'Normal', 'godecore-data' ), 'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			], ] );

		$this->add_control(
		'ved_modalbox_open_btn_text_color', [
			'label'		 => esc_html__( 'Text Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#ffffff',
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-open-btn' => 'color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			],
		]
		);



		$this->add_control(
		'ved_modalbox_open_btn_background_color', [
			'label'		 => esc_html__( 'Background Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#23b6ac',
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-open-btn' => 'background-color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Border::get_type(), [
			'name'		 => 'ved_modalbox_open_btn_border',
			'selector'	 => '{{WRAPPER}} .ved-modalbox-open-btn',
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			],
		]
		);


		$this->end_controls_tab();

		$this->start_controls_tab( 'ved_modalbox-open_btn_hover', [
			'label'		 => esc_html__( 'Hover', 'godecore-data' ), 'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			],
		]
		);

		$this->add_control(
		'ved_modalbox-open_btn_hover_text_color', [
			'label'		 => esc_html__( 'Text Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#ffffff',
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-open-btn:hover' => 'color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			],
		]
		);

		$this->add_control(
		'ved_modalbox-open_btn_hover_background_color', [
			'label'		 => esc_html__( 'Background Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#23b6ac',
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-open-btn:hover' => 'background-color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			],
		]
		);

		$this->add_control(
		'ved_modalbox-open_btn_hover_border_color', [
			'label'		 => esc_html__( 'Border Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-open-btn:hover' => 'border-color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_modalbox_trigger_type' => 'ved_modalbox_trigger_button',
			],
		]
		);
		// generate button end

		$this->end_controls_section();


		$this->start_controls_section(
		'ved_section_modalbox_styles', [
			'label'	 => esc_html__( 'Modalbox Container Styles', 'godecore-data' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_control(
		'ved_modalbox_container_bg', [
			'label'		 => esc_html__( 'Container Background Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#ffffff',
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-container' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_modalbox_container_width', [
			'label'		 => esc_html__( 'Set max width for the container?', 'godecore-data' ),
			'type'		 => Controls_Manager::SWITCHER,
			'label_on'	 => esc_html__( 'yes', 'godecore-data' ),
			'label_off'	 => esc_html__( 'no', 'godecore-data' ),
			'default'	 => 'yes',
		]
		);

		$this->add_responsive_control(
		'ved_modalbox_container_width_value', [
			'label'		 => esc_html__( 'Modalbox Container max width', 'godecore-data' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size' => 895,
			],
			'range'		 => [
				'px'	 => [
					'min'	 => 0,
					'max'	 => 1000,
					'step'	 => 5,
				],
				'%'	 => [
					'min'	 => 0,
					'max'	 => 100,
				],
			],
			'size_units'	 => [ 'px', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-container' => 'max-width: {{SIZE}}{{UNIT}};',
			],
			'condition'	 => [
				'ved_modalbox_container_width' => 'yes',
			],
		]
		);

		$this->add_control(
		'ved_modalbox_container_padding', [
			'label'		 => esc_html__( 'Modalbox Container Padding', 'godecore-data' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->add_control(
		'ved_modalbox_container_border_radius', [
			'label'		 => esc_html__( 'Border Radius', 'godecore-data' ),
			'type'		 => Controls_Manager::SLIDER,
			'range'		 => [
				'px' => [
					'min'	 => 0,
					'max'	 => 100,
				],
			],
			'default'	 => [
				'size' => 6,
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-img-comp-container' => 'border-radius: {{SIZE}}{{UNIT}};',
			],
		]
		);

		$this->add_control(
		'ved_modalbox_container_overlay', [
			'label'		 => esc_html__( 'Enable dark overlay?', 'godecore-data' ),
			'type'		 => Controls_Manager::SWITCHER,
			'label_on'	 => esc_html__( 'yes', 'godecore-data' ),
			'label_off'	 => esc_html__( 'no', 'godecore-data' ),
			'default'	 => 'yes',
		]
		);

		$this->add_control(
		'ved_modalbox_container_overlay_color', [
			'label'		 => esc_html__( 'Overlay Background Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => 'rgba(248, 248, 248, 0.75)',
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-popup' => 'background-color: {{VALUE}};',
			],
			'condition'	 => [
				'ved_modalbox_container_overlay' => 'yes',
			],
		]
		);

		$this->end_controls_section();


		$this->start_controls_section(
		'ved_section_modalbox_closebtn_styles', [
			'label'	 => esc_html__( 'Close Button Styles', 'godecore-data' ),
			'tab'	 => Controls_Manager::TAB_STYLE
		]
		);

		$this->add_control(
		'ved_modalbox_closebtn_color', [
			'label'		 => esc_html__( 'Close Button Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#a9a9a9',
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-close' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_modalbox_closebtn_bg', [
			'label'		 => esc_html__( 'Close Button Background Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '',
			'selectors'	 => [
				'{{WRAPPER}} .ved-modalbox-close' => 'background-color: {{VALUE}};',
			],
		]
		);


		$this->end_controls_section();
	}

	protected function render() {


		$settings = $this->get_settings_for_display();

		$delay = $this->get_settings( 'ved_modalbox_trigger_pageload' );

		$container_max_width = $this->get_settings( 'ved_modalbox_container_width_value' );

		$container_padding = $this->get_settings( 'ved_modalbox_container_padding' );

		$container_border_radius = $this->get_settings( 'ved_modalbox_container_border_radius' );

		$popup_image = $this->get_settings( 'ved_modalbox_type_image' );

		if ( ($settings[ 'ved_modalbox_container_overlay' ]) == 'yes' ) :

			$enable_overlay = 'enabled';

		else:

			$enable_overlay = 'disabled';

		endif;
		?>

		<?php
		$popup_template = '<div id="popup-' . esc_attr( $this->get_id() ) . '" class="ved-modalbox-popup lity overlay-' . esc_js( $enable_overlay ) . '" role="dialog" aria-label="Dialog Window (Press escape to close)" tabindex="-1"><div class="lity-wrap" data-lity-close role="document"><div class="lity-loader" aria-hidden="true">Loading...</div><div class="lity-container"><div class="lity-content"></div><button class="lity-close ved-modalbox-close" style="background-color: ' . esc_attr( $settings[ 'ved_modalbox_closebtn_bg' ] ) . '; color: ' . esc_attr( $settings[ 'ved_modalbox_closebtn_color' ] ) . '" type="button" aria-label="Close (Press escape to close)" data-lity-close>&times;</button></div></div></div>';
		?>

		<?php if ( ($settings[ 'ved_modalbox_trigger_type' ]) == 'ved_modalbox_trigger_button' ) : ?>
			<div class="ved-modalbox-btn">
				<a href="#" id="btn-ved-modalbox-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-modalbox-open-btn ved-modalbox-open-button">
			<?php if ( ! empty( $settings[ 'ved_modalbox_open_btn_icon' ] ) && $settings[ 'ved_modalbox_open_btn_icon_align' ] == 'left' ) : ?>
						<i class="<?php echo esc_attr( $settings[ 'ved_modalbox_open_btn_icon' ] ); ?> open-pop-up-button-icon-left" aria-hidden="true"></i>
			<?php endif; ?>
			<?php echo esc_attr( $settings[ 'ved_modalbox_open_btn' ] ); ?>
			<?php if ( ! empty( $settings[ 'ved_modalbox_open_btn_icon' ] ) && $settings[ 'ved_modalbox_open_btn_icon_align' ] == 'right' ) : ?>
						<i class="<?php echo esc_attr( $settings[ 'ved_modalbox_open_btn_icon' ] ); ?> open-pop-up-button-icon-right" aria-hidden="true"></i>
			<?php endif; ?>
				</a>
			</div><!-- close .ved-modalbox-btn -->
		<?php endif; ?>

		<?php if ( ($settings[ 'ved_modalbox_type' ]) == 'modalbox_type_image' ) : ?>

			<div id="popup-content-<?php echo esc_attr( $this->get_id() ); ?>" class="lity-hide">
				<div class="ved-modalbox-container" style="background-color: <?php echo esc_attr( $settings[ 'ved_modalbox_container_bg' ] ); ?>; max-width: <?php echo esc_attr($container_max_width[ 'size' ] . $container_max_width[ 'unit' ]); ?>; padding: <?php echo esc_attr($container_padding[ 'top' ] . $container_padding[ 'unit' ] . ' ' . $container_padding[ 'right' ] . $container_padding[ 'unit' ] . ' ' . $container_padding[ 'bottom' ] . $container_padding[ 'unit' ] . ' ' . $container_padding[ 'left' ] . $container_padding[ 'unit' ]); ?>; border-radius: <?php echo esc_attr($container_border_radius[ 'size' ] . $container_border_radius[ 'unit' ]); ?>">
					<div class="ved-modalbox-content">
						<img src="<?php echo esc_url($popup_image[ 'url' ]) ?>">
					</div>
				</div>
			</div>

		<?php elseif ( ($settings[ 'ved_modalbox_type' ]) == 'modalbox_type_content' ) : ?>

			<div id="popup-content-<?php echo esc_attr( $this->get_id() ); ?>" class="lity-hide">
				<div class="ved-modalbox-container" style="background-color: <?php echo esc_attr( $settings[ 'ved_modalbox_container_bg' ] ); ?>; max-width: <?php echo esc_attr($container_max_width[ 'size' ] . $container_max_width[ 'unit' ]) ?>; padding: <?php echo esc_attr($container_padding[ 'top' ] . $container_padding[ 'unit' ] . ' ' . $container_padding[ 'right' ] . $container_padding[ 'unit' ] . ' ' . $container_padding[ 'bottom' ] . $container_padding[ 'unit' ] . ' ' . $container_padding[ 'left' ] . $container_padding[ 'unit' ]); ?>; border-radius: <?php echo esc_attr($container_border_radius[ 'size' ] . $container_border_radius[ 'unit' ]); ?>">
					<div class="ved-modalbox-content">
			<?php if ( 'content' == $settings[ 'ved_modalbox_text_type' ] ) : ?>
				<?php echo $settings[ 'ved_modalbox_type_content' ]; ?>
			<?php elseif ( 'template' == $settings[ 'ved_modalbox_text_type' ] ) : ?>
				<?php
				if ( ! empty( $settings[ 'ved_primary_templates' ] ) ) {
					$ved_template_id = $settings[ 'ved_primary_templates' ];
					$ved_frontend	 = new Frontend;
					echo $ved_frontend->get_builder_content( $ved_template_id, true );
				}
				?>
			<?php endif; ?>
					</div>
				</div>
			</div>

				<?php else: ?>

			<div id="popup-content-<?php echo esc_attr( $this->get_id() ); ?>" class="lity-hide">
				<div class="ved-modalbox-container" style="background-color: <?php echo esc_attr( $settings[ 'ved_modalbox_container_bg' ] ); ?>; max-width: <?php echo esc_attr($container_max_width[ 'size' ] . $container_max_width[ 'unit' ]); ?>; padding: <?php echo esc_attr($container_padding[ 'top' ] . $container_padding[ 'unit' ] . ' ' . $container_padding[ 'right' ] . $container_padding[ 'unit' ] . ' ' . $container_padding[ 'bottom' ] . $container_padding[ 'unit' ] . ' ' . $container_padding[ 'left' ] . $container_padding[ 'unit' ]); ?>; border-radius: <?php echo esc_attr($container_border_radius[ 'size' ] . $container_border_radius[ 'unit' ]); ?>">
					<div class="ved-modalbox-content">
						<div class="ved-iframe-container">
							<iframe allowfullscreen="" src="<?php echo esc_url( $settings[ 'ved_modalbox_type_url' ] ); ?>" frameborder="0"></iframe>
						</div>
					</div>
				</div>
			</div>


		<?php endif; ?>

		<script>
			jQuery(document).ready(function ($) {
				var modalbox = null;

		<?php if ( ($settings[ 'ved_modalbox_trigger_type' ]) == 'ved_modalbox_trigger_button' ) : ?>

			<?php if ( ($settings[ 'ved_modalbox_type' ]) == 'modalbox_type_url' ) : ?>

						$("#btn-ved-modalbox-<?php echo esc_attr( $this->get_id() ); ?>").click(function (e) {
							e.preventDefault();
							modalbox = lity("<?php echo esc_attr( $settings[ 'ved_modalbox_type_url' ] ); ?>", {template: '<?php echo $popup_template; ?>'});
						});

						<?php else: ?>
						$("#btn-ved-modalbox-<?php echo esc_attr( $this->get_id() ); ?>").click(function (e) {
							e.preventDefault();
							modalbox = lity("#popup-content-<?php echo esc_attr( $this->get_id() ); ?>", {template: '<?php echo $popup_template; ?>'});
						});

						<?php endif; ?>

					<?php elseif ( ($settings[ 'ved_modalbox_trigger_type' ]) == 'ved_modalbox_trigger_external' ) : ?>

			<?php if ( ($settings[ 'ved_modalbox_type' ]) == 'modalbox_type_url' ) : ?>

						$("<?php echo esc_attr( $settings[ 'ved_modalbox_trigger_external' ] ); ?>").click(function (e) {
							e.preventDefault();
							modalbox = lity("<?php echo esc_attr( $settings[ 'ved_modalbox_type_url' ] ); ?>", {template: '<?php echo $popup_template; ?>'});
						});

			<?php else: ?>
						$("<?php echo esc_attr( $settings[ 'ved_modalbox_trigger_external' ] ); ?>").click(function (e) {
							e.preventDefault();
							modalbox = lity("#popup-content-<?php echo esc_attr( $this->get_id() ); ?>", {template: '<?php echo $popup_template; ?>'});
						});
			<?php endif; ?>


		<?php else: ?>

			<?php if ( ($settings[ 'ved_modalbox_type' ]) == 'modalbox_type_url' ) : ?>

						setTimeout(function () {
							modalbox = lity("<?php echo esc_attr( $settings[ 'ved_modalbox_type_url' ] ); ?>", {template: '<?php echo $popup_template; ?>'});
						}, <?php echo floatVal( $delay[ 'size' ] ) * 1000; ?>);

			<?php else: ?>

						setTimeout(function () {
							modalbox = lity("#popup-content-<?php echo esc_attr( $this->get_id() ); ?>", {template: '<?php echo $popup_template; ?>'});
						}, <?php echo floatVal( $delay[ 'size' ] ) * 1000; ?>);
			<?php endif; ?>


		<?php endif; ?>

			});
		</script>

		<style type="text/css">

		<?php echo '#popup-' . esc_attr( $this->get_id() ); ?> {
				background-color: <?php echo esc_attr( $settings[ 'ved_modalbox_container_overlay_color' ] ); ?>;
			}
		<?php echo '#popup-' . esc_attr( $this->get_id() ) . '.overlay-disabled'; ?>  {
				background-color: transparent;
			}

		<?php echo '#popup-' . esc_attr( $this->get_id() ); ?>.lity-iframe .lity-container  {
				background-color: <?php echo esc_attr( $settings[ 'ved_modalbox_container_bg' ] ); ?>;
				max-width: <?php echo esc_attr($container_max_width[ 'size' ] . $container_max_width[ 'unit' ]); ?>;
				padding: <?php echo esc_attr($container_padding[ 'top' ] . $container_padding[ 'unit' ] . ' ' . $container_padding[ 'right' ] . $container_padding[ 'unit' ] . ' ' . $container_padding[ 'bottom' ] . $container_padding[ 'unit' ] . ' ' . $container_padding[ 'left' ] . $container_padding[ 'unit' ]); ?>;
				border-radius: <?php echo esc_attr($container_border_radius[ 'size' ] . $container_border_radius[ 'unit' ]); ?>
			}

		</style>


		<?php
	}

	protected function content_template() {
		?>


		<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Modalbox() );
endif;