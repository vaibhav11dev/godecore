<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly

if ( ! class_exists( 'Widget_Ved_Post_Block' ) ) :
class Widget_Ved_Post_Block extends Widget_Base {

    public function get_name() {
        return 'ved-post-block';
    }

    public function get_title() {
        return esc_html__( 'Ved Post Block', 'godecore-data' );
    }

    public function get_icon() {
        return 'eicon-posts-grid';
    }

    public function get_categories() {
        return [ 'godecore-addons' ];
    }

    protected function _register_controls() {
        $this->start_controls_section(
        'ved_section_post_block_filters', [
            'label' => esc_html__( 'Post Settings', 'godecore-data' )
        ]
        );

        $this->add_control(
        'ved_section_post_block_title', [
            'label'       => esc_html__( 'Title', 'godecore-data' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( 'Title Here', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_section_post_block_sub_title', [
            'label'       => esc_html__( 'Sub Title', 'godecore-data' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
        ]
        );

        $this->add_control(
        'ved_post_block_style', [
            'label'   => esc_html__( 'Style', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'style1',
            'options' => [
                'style1' => esc_html__( 'Style One', 'godecore-data' ),
                'style2' => esc_html__( 'Style Two', 'godecore-data' ),
                'style3' => esc_html__( 'Style Three', 'godecore-data' ),
                'style4' => esc_html__( 'Style Four', 'godecore-data' ),
                'style5' => esc_html__( 'Style Five', 'godecore-data' ),
                'style6' => esc_html__( 'Style Six', 'godecore-data' ),
            ],
        ]
        );

        $this->add_control(
        'ved_post_block_slider_row', [
            'label'   => esc_html__( 'Row Layout', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'single_row',
            'options' => [
                'single_row' => esc_html__( 'Single Row', 'godecore-data' ),
                'double_row' => esc_html__( 'Double Row', 'godecore-data' ),
            ],
        ]
        );

        $this->add_control(
        'ved_post_category', [
            'label'       => esc_html__( 'Categories', 'godecore-data' ),
            'type'        => Controls_Manager::SELECT2,
            'label_block' => true,
            'multiple'    => true,
            'options'     => godecore_post_type_categories(),
        ]
        );
        
        $this->add_control(
        'ved_post_type', [
            'label'   => esc_html__( 'Layout Type', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'slider',
            'options' => [
                'grid'   => esc_html__( 'grid', 'godecore-data' ),
                'slider' => esc_html__( 'Slider', 'godecore-data' ),
            ],
        ]
        );

        $this->add_control(
        'ved_post_column', [
            'label'   => esc_html__( 'Number of Column', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'options' => [
                '1' => 'One Column',
                '2' => 'Two Column',
                '3' => 'Three Column',
                '4' => 'Four Column',
            ],
            'default' => '3',
            'condition'   => [
                'ved_post_type' => 'grid',
            ]
        ]
        );

        $this->add_control(
        'ved_posts_count', [
            'label'   => esc_html__( 'Number of Posts', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => '4'
        ]
        );


        $this->add_control(
        'ved_post_offset', [
            'label'   => esc_html__( 'Post Offset', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => '0'
        ]
        );

        $this->add_control(
        'ved_post_orderby', [
            'label'   => esc_html__( 'Order By', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'options' => godecore_get_post_orderby_options(),
            'default' => 'date',
        ]
        );

        $this->add_control(
        'ved_post_order', [
            'label'   => esc_html__( 'Order', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'options' => [
                'asc'  => 'Ascending',
                'desc' => 'Descending'
            ],
            'default' => 'desc',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_post_block_layout', [
            'label' => esc_html__( 'Layout Settings', 'godecore-data' )
        ]
        );

        $this->add_control(
        'ved_post_block_show_read_more', [
            'label'   => esc_html__( 'Show Read More Button', 'godecore-data' ),
            'type'    => Controls_Manager::CHOOSE,
            'options' => [
                '1' => [
                    'title' => esc_html__( 'Yes', 'godecore-data' ),
                    'icon'  => 'fa fa-check',
                ],
                '0' => [
                    'title' => esc_html__( 'No', 'godecore-data' ),
                    'icon'  => 'fa fa-ban',
                ]
            ],
            'default' => '0',
            'condition'   => [
                'ved_post_type' => 'grid',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_show_read_more_text', [
            'label'       => esc_html__( 'Label Text', 'godecore-data' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => false,
            'default'     => esc_html__( 'Read all news', 'godecore-data' ),
            'condition'   => [
                'ved_post_block_show_read_more' => '1',
                'ved_post_type' => 'grid',
            ]
        ]
        );

        $this->add_control(
        'ved_show_image', [
            'label'   => esc_html__( 'Show Image', 'godecore-data' ),
            'type'    => Controls_Manager::CHOOSE,
            'options' => [
                '1' => [
                    'title' => esc_html__( 'Yes', 'godecore-data' ),
                    'icon'  => 'fa fa-check',
                ],
                '0' => [
                    'title' => esc_html__( 'No', 'godecore-data' ),
                    'icon'  => 'fa fa-ban',
                ]
            ],
            'default' => '1'
        ]
        );

        $this->add_group_control(
        Group_Control_Image_Size::get_type(), [
            'name'      => 'image',
            'exclude'   => [ 'custom' ],
            'default'   => 'large',
            'condition' => [
                'ved_show_image' => '1',
            ]
        ]
        );

        $this->add_control(
        'ved_show_title', [
            'label'   => esc_html__( 'Show Title', 'godecore-data' ),
            'type'    => Controls_Manager::CHOOSE,
            'options' => [
                '1' => [
                    'title' => esc_html__( 'Yes', 'godecore-data' ),
                    'icon'  => 'fa fa-check',
                ],
                '0' => [
                    'title' => esc_html__( 'No', 'godecore-data' ),
                    'icon'  => 'fa fa-ban',
                ]
            ],
            'default' => '1'
        ]
        );

        $this->add_control(
        'ved_show_excerpt', [
            'label'   => esc_html__( 'Show excerpt', 'godecore-data' ),
            'type'    => Controls_Manager::CHOOSE,
            'options' => [
                '1' => [
                    'title' => esc_html__( 'Yes', 'godecore-data' ),
                    'icon'  => 'fa fa-check',
                ],
                '0' => [
                    'title' => esc_html__( 'No', 'godecore-data' ),
                    'icon'  => 'fa fa-ban',
                ]
            ],
            'default' => '1'
        ]
        );


        $this->add_control(
        'ved_excerpt_length', [
            'label'     => esc_html__( 'Excerpt Words', 'godecore-data' ),
            'type'      => Controls_Manager::NUMBER,
            'default'   => '30',
            'condition' => [
                'ved_show_excerpt' => '1',
            ]
        ]
        );


        $this->add_control(
        'ved_show_meta', [
            'label'   => esc_html__( 'Show Meta', 'godecore-data' ),
            'type'    => Controls_Manager::CHOOSE,
            'options' => [
                '1' => [
                    'title' => esc_html__( 'Yes', 'godecore-data' ),
                    'icon'  => 'fa fa-check',
                ],
                '0' => [
                    'title' => esc_html__( 'No', 'godecore-data' ),
                    'icon'  => 'fa fa-ban',
                ]
            ],
            'default' => '1'
        ]
        );


        $this->add_control(
        'ved_post_block_meta_position', [
            'label'     => esc_html__( 'Meta Position', 'godecore-data' ),
            'type'      => Controls_Manager::SELECT,
            'default'   => 'meta-entry-header',
            'options'   => [
                'meta-entry-header' => esc_html__( 'Entry Header', 'godecore-data' ),
                'meta-entry-footer' => esc_html__( 'Entry Footer', 'godecore-data' ),
            ],
            'condition' => [
                'ved_show_meta' => '1',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_meta_date', [
            'label'        => esc_html__( 'Display Meta Dates', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'no', 'godecore-data' ),
            'default'      => 'yes',
            'return_value' => 'yes',
            'condition'    => [
                'ved_show_meta' => '1',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_meta_author', [
            'label'        => esc_html__( 'Display Meta Author', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'no', 'godecore-data' ),
            'default'      => 'yes',
            'return_value' => 'yes',
            'condition'    => [
                'ved_show_meta' => '1',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_meta_avtar', [
            'label'        => esc_html__( 'Display Meta Avtar', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'no', 'godecore-data' ),
            'default'      => 'no',
            'return_value' => 'yes',
            'condition'    => [
                'ved_show_meta' => '1',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_meta_tags', [
            'label'        => esc_html__( 'Display Meta Tags', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'no', 'godecore-data' ),
            'default'      => 'no',
            'return_value' => 'yes',
            'condition'    => [
                'ved_show_meta' => '1',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_meta_comments', [
            'label'        => esc_html__( 'Display Meta Comments', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'no', 'godecore-data' ),
            'default'      => 'no',
            'return_value' => 'yes',
            'condition'    => [
                'ved_show_meta' => '1',
            ]
        ]
        );

        $this->end_controls_section();
        
        $this->start_controls_section(
        'ved_section_post_slider_settings', [
            'label' => esc_html__( 'Post Slider Settings', 'godecore-data' ),
            'condition'    => [
                'ved_post_type' => 'slider',
            ]
        ]
        );

        $this->add_control(
        'ved_post_slider_desk_items', [
            'label'   => esc_html__( 'Show Desktop Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 3,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_post_slider_desk_small_items', [
            'label'   => esc_html__( 'Show Desktop Small Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 2,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );
        
        $this->add_control(
        'ved_post_slider_tab_items', [
            'label'   => esc_html__( 'Show Tab Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 3,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_post_slider_mob_items', [
            'label'   => esc_html__( 'Show Mobile Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 2,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_post_slider_autoplay', [
            'label'        => esc_html__( 'AutoPlay', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_post_slider_navigation', [
            'label'        => esc_html__( 'Navigation', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_post_slider_pagination', [
            'label'        => esc_html__( 'Pagination', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_post_block_style', [
            'label' => esc_html__( 'Post Block Style', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

		$this->add_control(
        'ved_post_block_content_position', [
            'label'   => esc_html__( 'Content Position', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'left',
            'options' => [
                'left' => esc_html__( 'Left', 'godecore-data' ),
                'center' => esc_html__( 'Center', 'godecore-data' ),
                'right' => esc_html__( 'Right', 'godecore-data' ),
            ],
            'selectors' => [
                '{{WRAPPER}} .ved-post-content' => 'text-align: {{VALUE}}',
            ],
            'condition'   => [
				'ved_post_block_style' => [ 'style1', 'style5' ]
            ]
        ]
        );
		
		$this->add_control(
        'ved_post_block_date_position', [
            'label'   => esc_html__( 'Date Position', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'top_left',
            'options' => [
                'top_left' => esc_html__( 'Top Left', 'godecore-data' ),
                'top_center' => esc_html__( 'Top Center', 'godecore-data' ),
                'top_right' => esc_html__( 'Top Right', 'godecore-data' ),
                'bottom_left' => esc_html__( 'Bottom Left', 'godecore-data' ),
                'bottom_center' => esc_html__( 'Bottom Center', 'godecore-data' ),
                'bottom_right' => esc_html__( 'Bottom Right', 'godecore-data' ),
            ],
            'condition'   => [
               'ved_post_block_style' => [ 'style1', 'style5' ]
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_button_type', [
            'label'   => esc_html__( 'Read More Style', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'bg_btn',
            'options' => [
                'bg_btn' => esc_html__( 'Default', 'godecore-data' ),
                'text_btn' => esc_html__( 'Text Button', 'godecore-data' ),
            ],
            'condition'   => [
                'ved_post_block_style' => [ 'style1', 'style5' ]
            ]
        ]
        );
		
        $this->add_control(
        'ved_post_block_bg_color', [
            'label'     => esc_html__( 'Post Background Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#f8f8f8',
            'selectors' => [
                '{{WRAPPER}} .ved-post-item' => 'background-color: {{VALUE}}',
            ]
        ]
        );

        $this->add_group_control(
        Group_Control_Border::get_type(), [
            'name'     => 'ved_post_block_border',
            'label'    => esc_html__( 'Border', 'godecore-data' ),
            'selector' => '{{WRAPPER}} .ved-post-item',
        ]
        );

        $this->add_control(
        'ved_post_block_border_radius', [
            'label'     => esc_html__( 'Border Radius', 'godecore-data' ),
            'type'      => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .ved-post-item' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Box_Shadow::get_type(), [
            'name'     => 'ved_post_block_box_shadow',
            'selector' => '{{WRAPPER}} .ved-post-item',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_typography', [
            'label' => esc_html__( 'Color & Typography', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

        $this->add_control(
        'ved_post_block_title_style', [
            'label'     => esc_html__( 'Title Style', 'godecore-data' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
        );

        $this->add_control(
        'ved_post_block_title_color', [
            'label'     => esc_html__( 'Title Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#222222',
            'selectors' => [
                '{{WRAPPER}} .ved-post-title, {{WRAPPER}} .ved-post-title a' => 'color: {{VALUE}};',
            ]
        ]
        );

        $this->add_control(
        'ved_post_block_title_hover_color', [
            'label'     => esc_html__( 'Title Hover Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#3ab54a',
            'selectors' => [
                '{{WRAPPER}} .ved-post-title:hover, {{WRAPPER}} .ved-post-title a:hover' => 'color: {{VALUE}};',
            ]
        ]
        );

        $this->add_responsive_control(
        'ved_post_block_title_alignment', [
            'label'     => esc_html__( 'Title Alignment', 'godecore-data' ),
            'type'      => Controls_Manager::CHOOSE,
            'options'   => [
                'left'   => [
                    'title' => esc_html__( 'Left', 'godecore-data' ),
                    'icon'  => 'fa fa-align-left',
                ],
                'center' => [
                    'title' => esc_html__( 'Center', 'godecore-data' ),
                    'icon'  => 'fa fa-align-center',
                ],
                'right'  => [
                    'title' => esc_html__( 'Right', 'godecore-data' ),
                    'icon'  => 'fa fa-align-right',
                ]
            ],
            'selectors' => [
                '{{WRAPPER}} .ved-post-title' => 'text-align: {{VALUE}};',
            ]
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_post_block_title_typography',
            'label'    => esc_html__( 'Typography', 'godecore-data' ),
            'selector' => '{{WRAPPER}} .ved-post-title',
        ]
        );

        $this->add_control(
        'ved_post_block_excerpt_style', [
            'label'     => esc_html__( 'Excerpt Style', 'godecore-data' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
        );

        $this->add_control(
        'ved_post_block_excerpt_color', [
            'label'     => esc_html__( 'Excerpt Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#777777',
            'selectors' => [
                '{{WRAPPER}} .ved-post-excerpt p' => 'color: {{VALUE}};',
            ]
        ]
        );

        $this->add_responsive_control(
        'ved_post_block_excerpt_alignment', [
            'label'     => esc_html__( 'Excerpt Alignment', 'godecore-data' ),
            'type'      => Controls_Manager::CHOOSE,
            'options'   => [
                'left'    => [
                    'title' => esc_html__( 'Left', 'godecore-data' ),
                    'icon'  => 'fa fa-align-left',
                ],
                'center'  => [
                    'title' => esc_html__( 'Center', 'godecore-data' ),
                    'icon'  => 'fa fa-align-center',
                ],
                'right'   => [
                    'title' => esc_html__( 'Right', 'godecore-data' ),
                    'icon'  => 'fa fa-align-right',
                ],
                'justify' => [
                    'title' => esc_html__( 'Justified', 'godecore-data' ),
                    'icon'  => 'fa fa-align-justify',
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ved-post-excerpt p' => 'text-align: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_post_block_excerpt_typography',
            'label'    => esc_html__( 'excerpt Typography', 'godecore-data' ),
            'selector' => '{{WRAPPER}} .ved-post-excerpt p',
        ]
        );


        $this->add_control(
        'ved_post_block_meta_style', [
            'label'     => esc_html__( 'Meta Style', 'godecore-data' ),
            'type'      => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
        );

        $this->add_control(
        'ved_post_block_meta_color', [
            'label'     => esc_html__( 'Meta Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#999',
            'selectors' => [
                '{{WRAPPER}} .ved-post-meta > li' => 'color: {{VALUE}};',
            ]
        ]
        );

        $this->add_responsive_control(
        'ved_post_block_meta_alignment', [
            'label'     => esc_html__( 'Meta Alignment', 'godecore-data' ),
            'type'      => Controls_Manager::CHOOSE,
            'options'   => [
                'left'    => [
                    'title' => esc_html__( 'Left', 'godecore-data' ),
                    'icon'  => 'fa fa-align-left',
                ],
                'center'  => [
                    'title' => esc_html__( 'Center', 'godecore-data' ),
                    'icon'  => 'fa fa-align-center',
                ],
                'right'   => [
                    'title' => esc_html__( 'Right', 'godecore-data' ),
                    'icon'  => 'fa fa-align-right',
                ],
                'justify' => [
                    'title' => esc_html__( 'Justified', 'godecore-data' ),
                    'icon'  => 'fa fa-align-justify',
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ved-post-meta' => 'text-align: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_post_block_meta_typography',
            'label'    => esc_html__( 'Excerpt Typography', 'godecore-data' ),
            'selector' => '{{WRAPPER}} .ved-post-meta ul li a',
        ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_read_more_btn', [
            'label'     => esc_html__( 'Load More Button Style', 'godecore-data' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [
                'ved_post_block_show_read_more' => '1'
            ]
        ]
        );

        $this->add_responsive_control(
        'ved_post_block_read_more_btn_padding', [
            'label'      => esc_html__( 'Padding', 'godecore-data' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-read-more-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );

        $this->add_responsive_control(
        'ved_post_block_read_more_btn_margin', [
            'label'      => esc_html__( 'Margin', 'godecore-data' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-read-more-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );
        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_post_block_read_more_btn_typography',
            'selector' => '{{WRAPPER}} .ved-read-more-button',
        ]
        );

        $this->add_responsive_control(
        'ved_post_block_read_more_btn_alignment', [
            'label'     => esc_html__( 'Button Alignment', 'godecore-data' ),
            'type'      => Controls_Manager::CHOOSE,
            'options'   => [
                'left'   => [
                    'title' => esc_html__( 'Left', 'godecore-data' ),
                    'icon'  => 'fa fa-align-left',
                ],
                'center' => [
                    'title' => esc_html__( 'Center', 'godecore-data' ),
                    'icon'  => 'fa fa-align-center',
                ],
                'right'  => [
                    'title' => esc_html__( 'Right', 'godecore-data' ),
                    'icon'  => 'fa fa-align-right',
                ]
            ],
            'default'   => 'center',
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button-wrap' => 'text-align: {{VALUE}};',
            ]
        ]
        );

        $this->start_controls_tabs( 'ved_post_block_read_more_btn_tabs' );

        // Normal State Tab
        $this->start_controls_tab( 'ved_post_block_read_more_btn_normal', [ 'label' => esc_html__( 'Normal', 'godecore-data' ) ] );

        $this->add_control(
        'ved_post_block_read_more_btn_normal_text_color', [
            'label'     => esc_html__( 'Text Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#fff',
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_control(
        'ved_cta_btn_normal_bg_color', [
            'label'     => esc_html__( 'Background Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#3ab54a',
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button' => 'background: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Border::get_type(), [
            'name'     => 'ved_post_block_read_more_btn_normal_border',
            'label'    => esc_html__( 'Border', 'godecore-data' ),
            'selector' => '{{WRAPPER}} .ved-read-more-button',
        ]
        );

        $this->add_control(
        'ved_post_block_read_more_btn_border_radius', [
            'label'     => esc_html__( 'Border Radius', 'godecore-data' ),
            'type'      => Controls_Manager::SLIDER,
            'range'     => [
                'px' => [
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button' => 'border-radius: {{SIZE}}px;',
            ],
        ]
        );
        $this->add_group_control(
        Group_Control_Box_Shadow::get_type(), [
            'name'      => 'ved_post_block_read_more_btn_shadow',
            'selector'  => '{{WRAPPER}} .ved-read-more-button',
            'separator' => 'before'
        ]
        );
        $this->end_controls_tab();

        // Hover State Tab
        $this->start_controls_tab( 'ved_post_block_read_more_btn_hover', [ 'label' => esc_html__( 'Hover', 'godecore-data' ) ] );

        $this->add_control(
        'ved_post_block_read_more_btn_hover_text_color', [
            'label'     => esc_html__( 'Text Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#fff',
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button:hover' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_control(
        'ved_post_block_read_more_btn_hover_bg_color', [
            'label'     => esc_html__( 'Background Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#3ab54a',
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button:hover' => 'background: {{VALUE}};',
            ],
        ]
        );

        $this->add_control(
        'ved_post_block_read_more_btn_hover_border_color', [
            'label'     => esc_html__( 'Border Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '',
            'selectors' => [
                '{{WRAPPER}} .ved-read-more-button:hover' => 'border-color: {{VALUE}};',
            ],
        ]
        );
        $this->add_group_control(
        Group_Control_Box_Shadow::get_type(), [
            'name'      => 'ved_post_block_read_more_btn_hover_shadow',
            'selector'  => '{{WRAPPER}} .ved-read-more-button:hover',
            'separator' => 'before'
        ]
        );
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();

        $post_block_title      = $settings[ 'ved_section_post_block_title' ];
        $post_block_sub_title      = $settings[ 'ved_section_post_block_sub_title' ];
        $post_style      = $settings[ 'ved_post_block_style' ];
        $post_type = $settings[ 'ved_post_type' ];
        $ved_post_block_row = $settings[ 'ved_post_block_slider_row' ];
        $cnt = 1;
        // Slider Options        
        $desk_items      = $settings[ 'ved_post_slider_desk_items' ];
        $desk_small_items      = $settings[ 'ved_post_slider_desk_small_items' ];
        $tab_items      = $settings[ 'ved_post_slider_tab_items' ];
        $mob_items      = $settings[ 'ved_post_slider_mob_items' ];
        $autoplay   = $settings[ 'ved_post_slider_autoplay' ];
        $navigation = $settings[ 'ved_post_slider_navigation' ];
        $pagination = $settings[ 'ved_post_slider_pagination' ];
        $date_position = $settings[ 'ved_post_block_date_position' ];
        $button_type = $settings[ 'ved_post_block_button_type' ];
        if($button_type == 'bg_btn'){
            $button_type_class = 'btn btn-base btn-hovered';
        }

        $post_args = godecore_get_post_settings( $settings );
        $posts = godecore_get_post_data( $post_args );
        if($post_type == 'grid'){            
            $post_column       = (12 / $settings[ 'ved_post_column' ]);
            $post_column_class = 'col-sm-' . $post_column . ' col-md-' . $post_column . ' col-lg-' . $post_column . '';
        }else{
            $post_column_class = 'col-sm-12';
        }
        
        $post_layout  = ( ($settings[ 'ved_post_type' ] == 'slider') ? "ved-post-slider owl-carousel" : "ved-post-grid" );

        /* Get Post Categories */
        $post_categories = $this->get_settings( 'ved_post_category' );
        if ( ! empty( $post_categories ) ) {
            foreach ( $post_categories as $key => $value ) {
                $categories[] = $value;
            }
            $categories_id_string = implode( ',', $categories );

            /* Get All Post Count */
            $total_post = 0;
            foreach ( $categories as $cat ) {
                $category   = get_category( $cat );
                $total_post = $total_post + $category->category_count;
            }
        } else {
            $categories_id_string = '';
            $total_post           = wp_count_posts( 'post' )->publish;
        }
        ?>

        <?php if ( isset( $post_block_title ) && $post_block_title ) {
            ?>
            <div class="sec-head-style">
                <h2 class="text-title page-heading"><?php echo esc_html( $post_block_title ); ?></h2>
				<?php if ( isset( $post_block_sub_title ) && $post_block_sub_title ) { ?>
					<p class="page-subheading"><?php echo esc_html( $post_block_sub_title ); ?></p>
				<?php } ?>
            </div>
        <?php }
        ?>

        <div class="row">
            <div id="ved-post-block-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-post-block ved-post-columns multi-columns-row <?php echo esc_attr( $post_layout ); ?> <?php echo esc_attr($post_style); ?>">
                <?php
                if ( count( $posts ) ) {
                    global $post;
                    ?>
                    <?php
                    foreach ( $posts as $post ) {
                        setup_postdata( $post );
                        if ( $ved_post_block_row == 'double_row' && $cnt % 2 != 0 ) {
                            echo "<div class='blog-item'>";
                        }
                        switch ( $post_style ) {
                            case 'style1':
                                require GODECORE_DATA_PATH . 'includes/style/post-block/style1.php';
                                break;

                            case 'style2':
                                require GODECORE_DATA_PATH . 'includes/style/post-block/style2.php';
                                break;

                            case 'style3':
                                require GODECORE_DATA_PATH . 'includes/style/post-block/style3.php';
                                break;

                            case 'style4':
                                require GODECORE_DATA_PATH . 'includes/style/post-block/style4.php';
                                break;

                            case 'style5':
                                require GODECORE_DATA_PATH . 'includes/style/post-block/style5.php';
                                break;

                            case 'style6':
                                require GODECORE_DATA_PATH . 'includes/style/post-block/style6.php';
                                break;    
                        }
                        if ( $ved_post_block_row == 'double_row' && $cnt % 2 == 0 ) {
                            echo '</div>';
                        } 
                        $cnt ++;
                    }
                    wp_reset_postdata();
                    ?>
                    <?php
                }
                ?>
            </div>
        </div>

        <?php
        if ( $settings[ 'ved_post_type' ] == 'grid' && $settings[ 'ved_post_block_show_read_more' ] == 1 ) :
            $read_more_button = get_option( 'page_for_posts' );
            if ( $read_more_button ) {
                $read_more_button = get_permalink( get_option( 'page_for_posts' ) );
            } else {
                $read_more_button = home_url();
            }
            ?>
            <!-- Read More Button -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="ved-read-more-button-wrap">
                        <a href="<?php echo esc_url( $read_more_button ); ?>" class="ved-read-more-button"><?php echo esc_html__( $settings[ 'ved_post_block_show_read_more_text' ], 'godecore-data' ); ?></a>
                    </div>
                </div>
            </div>
        <?php 
        endif; 
        if ( $settings[ 'ved_post_type' ] == 'slider' ) :
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                var ved_post_sld = $("#ved-post-block-<?php echo esc_js( $this->get_id() ); ?>.ved-post-slider");
                ved_post_sld.owlCarousel({
                    autoplay: <?php echo esc_js($autoplay) ? 'true' : 'false'; ?>,
                    nav: <?php echo esc_js($navigation) ? 'true' : 'false'; ?>,
                    dots: <?php echo esc_js($pagination) ? 'true' : 'false'; ?>,
                    loop:false,
                    autoplay:false,
                    rewind:true,
                    navText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],    
                    responsive:{
                        0:{
                            items:<?php echo esc_js($mob_items); ?>},
                        650:{
                            items:<?php echo esc_js($tab_items); ?>},
                        992:{
                            items:<?php echo esc_js($desk_small_items); ?>},
                        1200:{
                            items:<?php echo esc_js($desk_items); ?>}
                    }     
                });
            });
        </script>
        <?php
        endif; 
    }

    protected function content_template() {
        ?>

        <?php
    }

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Post_Block() );
endif;