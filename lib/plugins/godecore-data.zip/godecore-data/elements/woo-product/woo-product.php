<?php
namespace Elementor;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

if ( ! class_exists( 'Widget_Ved_Product' ) ) :
class Widget_Ved_Product extends Widget_Base {

    public function get_name() {
        return 'ved-woo-product';
    }

    public function get_title() {
        return esc_html__( 'Ved Product', 'godecore-data' );
    }

    public function get_icon() {
        return 'eicon-woocommerce';
    }

    public function get_categories() {
        return [ 'godecore-addons' ];
    }

    protected function _register_controls() {

        // Content Controls
        $this->start_controls_section(
        'ved_section_product_grid_settings', [
            'label' => esc_html__( 'Product Settings', 'godecore-data' )
        ]
        );

        $this->add_control(
        'ved_product_title', [
            'label'       => esc_html__( 'Heading Title', 'godecore-data' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( 'Recent Product', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_product_sub_title', [
            'label'       => esc_html__( 'Sub Heading Title', 'godecore-data' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => '',
        ]
        );
		
		$this->add_control(
        'ved_product_style', [
            'label'   => esc_html__( 'Style', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'style1',
            'options' => [
                'style1' => esc_html__( 'Style One', 'godecore-data' ),
                'style2' => esc_html__( 'Style Two', 'godecore-data' ),
            ],
        ]
        );

        $this->add_control(
        'ved_product_type', [
            'label'   => esc_html__( 'Layout Type', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'slider',
            'options' => [
                'grid'   => esc_html__( 'grid', 'godecore-data' ),
                'slider' => esc_html__( 'Slider', 'godecore-data' ),
            ],
        ]
        );

        $this->add_control(
        'ved_product_filter', [
            'label'   => esc_html__( 'Filter By', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'recent',
            'options' => [
                'recent'       => esc_html__( 'Recent Product', 'godecore-data' ),
                'featured'     => esc_html__( 'Featured Product', 'godecore-data' ),
                'best_sell' => esc_html__( 'Popular Product', 'godecore-data' ),
                'on_sell'         => esc_html__( 'Sale Product', 'godecore-data' ),
                'top_rate'          => esc_html__( 'Top Rated Products', 'godecore-data' ),
            ],
        ]
        );

        $this->add_control(
        'ved_product_column', [
            'label'   => esc_html__( 'Columns', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => '4',
            'options' => [
                '2' => esc_html__( '2', 'godecore-data' ),
                '3' => esc_html__( '3', 'godecore-data' ),
                '4' => esc_html__( '4', 'godecore-data' ),
            ],
            'condition'    => [
                'ved_product_type' => 'grid',
            ]
        ]
        );

        $this->add_control(
        'ved_product_count', [
            'label'   => esc_html__( 'Products Count', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 1000,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_product_rating', [
            'label'        => esc_html__( 'Show Product Rating?', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => 'yes',
        ]
        );

        $this->end_controls_section();
        
        $this->start_controls_section(
        'ved_section_product_slider_settings', [
            'label' => esc_html__( 'Product Slider Settings', 'godecore-data' ),
            'condition'    => [
                'ved_product_type' => 'slider',
            ]
        ]
        );

        $this->add_control(
        'ved_product_desk_items', [
            'label'   => esc_html__( 'Show Desktop Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_product_desk_small_items', [
            'label'   => esc_html__( 'Show Desktop Small Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 2,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );
        
        $this->add_control(
        'ved_product_tab_items', [
            'label'   => esc_html__( 'Show Tab Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 3,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_product_mob_items', [
            'label'   => esc_html__( 'Show Mobile Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 2,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );
		
		$this->add_control(
        'ved_product_slider_autoplay', [
            'label'        => esc_html__( 'AutoPlay', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_product_slider_navigation', [
            'label'        => esc_html__( 'Navigation', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_product_slider_pagination', [
            'label'        => esc_html__( 'Pagination', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_product_grid_typography', [
            'label' => esc_html__( 'Color &amp; Typography', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

        $this->add_control(
        'ved_product_title_heading', [
            'label' => esc_html__( 'Product Title', 'godecore-data' ),
            'type'  => Controls_Manager::HEADING,
        ]
        );

        $this->add_control(
        'ved_product_title_color', [
            'label'     => esc_html__( 'Product Title Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#222222',
            'selectors' => [
                '{{WRAPPER}} .ved-woo-product .woocommerce .woocommerce-loop-product__title .woocommerce-loop-product__link' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_product_title_typography',
            'selector' => '{{WRAPPER}} .ved-woo-product .woocommerce .woocommerce-loop-product__title .woocommerce-loop-product__link',
        ]
        );

        $this->add_control(
        'ved_product_price_heading', [
            'label' => esc_html__( 'Product Price', 'godecore-data' ),
            'type'  => Controls_Manager::HEADING,
        ]
        );


        $this->add_control(
        'ved_product_price_color', [
            'label'     => esc_html__( 'Product Price Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#222222',
            'selectors' => [
                '{{WRAPPER}} .ved-woo-product .woocommerce .price' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_product_price_typography',
            'selector' => '{{WRAPPER}} .ved-woo-product .woocommerce .price',
        ]
        );

        $this->end_controls_section();
    }

    protected function render() {

        $settings = $this->get_settings();
        
        // Slider Options
        $desk_items      = $settings[ 'ved_product_desk_items' ];
        $desk_small_items      = $settings[ 'ved_product_desk_small_items' ];
        $tab_items      = $settings[ 'ved_product_tab_items' ];
        $mob_items      = $settings[ 'ved_product_mob_items' ];
        $autoplay   = $settings[ 'ved_product_slider_autoplay' ];
        $navigation = $settings[ 'ved_product_slider_navigation' ];
        $pagination = $settings[ 'ved_product_slider_pagination' ];

		//General Options
		$style     = $settings[ 'ved_product_style' ];
        $product_filter  = $settings[ 'ved_product_filter' ];
        $product_count   = $settings[ 'ved_product_count' ];
        $columns         = $settings[ 'ved_product_column' ];
        $row_columns         = $settings[ 'ved_product_desk_items' ];
        $product_classes = ( ($settings[ 'ved_product_rating' ] == 'yes') ? "show_rating" : "hide_rating" );
        $product_layout  = ( ($settings[ 'ved_product_type' ] == 'slider') ? "ved-woo-product-slider" : "ved-woo-product-grid" );
        ?>

        <?php if ( isset( $settings[ 'ved_product_title' ] ) && $settings[ 'ved_product_title' ] ) { ?>
            <div class="sec-head-style">
                <h2 class="text-title page-heading"><?php echo esc_html( $settings[ 'ved_product_title' ] ); ?></h2>
                    <?php if ( isset( $settings[ 'ved_product_sub_title' ] ) && $settings[ 'ved_product_sub_title' ] ) { ?>
                        <p class="page-subheading"><?php echo esc_html( $settings[ 'ved_product_sub_title' ] ); ?></p>
                    <?php } ?>
            </div>
        <?php } ?>

        <div id="ved-woo-product-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-woo-product row <?php echo esc_attr( $product_layout ); ?> <?php echo esc_attr( $product_classes ); ?>">

			<?php
				switch ( $style ) {
					case 'style1':
						require GODECORE_DATA_PATH . 'includes/style/product/style1.php';
						break;

					case 'style2':
						require GODECORE_DATA_PATH . 'includes/style/product/style2.php';
						break;
				}
			?>

            <div class="clearfix"></div>
        </div>
        <?php
        if ( $settings[ 'ved_product_type' ] == 'slider' ) :
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                setTimeout(function(){ 
                    var wooproduct_sld = $("#ved-woo-product-<?php echo esc_js( $this->get_id() ); ?> .products");
                    wooproduct_sld.owlCarousel({
                        autoplay: <?php echo esc_js($autoplay) ? 'true' : 'false'; ?>,
                        autoplayHoverPause:true,
                        nav: <?php echo esc_js($navigation) ? 'true' : 'false'; ?>,
                        dots: <?php echo esc_js($pagination) ? 'true' : 'false'; ?>,
                        loop:false,
                        rewind:true,
                        navText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
                        responsive:{
                            0:{
                                items:<?php echo esc_js($mob_items); ?>},
                            768:{
                                items:<?php echo esc_js($tab_items); ?>},
                            992:{
                                items:<?php echo esc_js($desk_small_items); ?>},
                            1200:{
                                items:<?php echo esc_js($desk_items); ?>}
                        }           
                    });
                }, 300);
            });
        </script>
        <?php
        endif;
    }

    protected function content_template() {
        ?>


        <?php
    }

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Product() );
endif;