<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

if ( ! class_exists( 'Widget_Ved_Advance_Gallery' ) ) :
class Widget_Ved_Advance_Gallery extends Widget_Base {

	public function get_name() {
		return 'ved-adv-gallery';
	}

	public function get_title() {
		return esc_html__( 'Ved Advance Gallery', 'godecore-data' );
	}

	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	public function get_categories() {
		return [ 'godecore-addons' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
		'ved_section_adv-gallery', [
			'label' => esc_html__( 'Advance Gallery', 'godecore-data' ),
		]
		);

		$this->add_control(
			'ved_gallery',
			[
				'label' => __( 'Add Images', 'elementor' ),
				'type' => Controls_Manager::GALLERY,
				'show_label' => false,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();
		$gallery_id = wp_list_pluck( $settings['ved_gallery'], 'id' );
		
		?>
		<div class="ved-adv-gallery carousel-container theta-carousel">
			<div class="theta-carousel-inner-container">
		<?php
		foreach ( $gallery_id as $key => $value ) {
			?>
			<div class="ex-item theta-carousel-element">
			<?php
			$gallery_img = wp_get_attachment_image_src($value);
			echo '<img src="'.$gallery_img[0].'" alt="gallery-image">';
			?>
			</div>
			<?php
		}
		?>
		</div>
	</div>
		<?php
	}

	protected function content_template() {
		?>


		<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Advance_Gallery() );
endif;