<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

if ( ! class_exists( 'Widget_Ved_Adv_Progressbar' ) ) :
class Widget_Ved_Adv_Progressbar extends Widget_Base {

	public function get_name() {
		return 'ved-adv-progressbar';
	}

	public function get_title() {
		return esc_html__( 'Ved Advanced Progressbar', 'godecore-data' );
	}

	public function get_icon() {
		return 'eicon-skill-bar';
	}

	public function get_categories() {
		return [ 'godecore-addons' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
		'ved_section_progress', [
			'label' => esc_html__( 'Advance Progress Bar', 'godecore-data' ),
		]
		);

		$this->add_control(
		'ved_title', [
			'label'		 => esc_html__( 'Title', 'godecore-data' ),
			'type'		 => Controls_Manager::TEXT,
			'dynamic'	 => [
				'active' => true,
			],
			'placeholder'	 => esc_html__( 'Enter your title', 'godecore-data' ),
			'default'	 => esc_html__( 'Branding', 'godecore-data' ),
			'label_block'	 => true,
		]
		);

		$this->add_control(
		'ved_percent', [
			'label'		 => esc_html__( 'Percentage', 'godecore-data' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size'	 => 50,
				'unit'	 => '%',
			],
			'label_block'	 => true,
		]
		);

		$this->add_control(
		'ved_display_percentage', [
			'label'		 => esc_html__( 'Display Percentage', 'godecore-data' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'show',
			'options'	 => [
				'show'	 => esc_html__( 'Show', 'godecore-data' ),
				'hide'	 => esc_html__( 'Hide', 'godecore-data' ),
			],
		]
		);

		$this->add_control(
		'ved_display_striped', [
			'label'		 => esc_html__( 'Display Striped', 'godecore-data' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'hide',
			'options'	 => [
				'show'	 => esc_html__( 'Show', 'godecore-data' ),
				'hide'	 => esc_html__( 'Hide', 'godecore-data' ),
			],
		]
		);

		$this->add_control(
		'ved_striped_active', [
			'label'		 => esc_html__( 'Active Striped', 'godecore-data' ),
			'type'		 => Controls_Manager::SELECT,
			'default'	 => 'show',
			'options'	 => [
				'show'	 => esc_html__( 'On', 'godecore-data' ),
				'hide'	 => esc_html__( 'Off', 'godecore-data' ),
			],
			'condition'	 => [
				'ved_display_striped' => 'show'
			]
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_section_progressbar_styling', [
			'label'	 => esc_html__( 'Progress Bar', 'godecore-data' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_progressbar_color', [
			'label'		 => esc_html__( 'Progress Bar Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-progressbar .progress-bar' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_progressbar_bg_color', [
			'label'		 => esc_html__( 'Progress Bar Background Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-progressbar .progress' => 'background-color: {{VALUE}};',
			],
		]
		);

		$this->add_control(
		'ved_progressbar_height', [
			'label'		 => esc_html__( 'Progress Bar Height', 'godecore-data' ),
			'type'		 => Controls_Manager::SLIDER,
			'size_units'	 => [ 'px' ],
			'default'	 => [
				'size' => 10,
			],
			'range'		 => [
				'px' => [
					'min'	 => 1,
					'max'	 => 96,
				],
			],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-progressbar .progress' => 'height: {{SIZE}}{{UNIT}};',
			],
		]
		);

		$this->add_control(
		'ved_progressbar_border_radius', [
			'label'		 => esc_html__( 'Progress Bar Border Radius', 'godecore-data' ),
			'type'		 => Controls_Manager::DIMENSIONS,
			'size_units'	 => [ 'px', '%' ],
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-progressbar .progress' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_section_progresstitle', [
			'label'	 => esc_html__( 'Progress Title', 'godecore-data' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_progresstitle_color', [
			'label'		 => esc_html__( 'Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-progressbar .progress-title' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_progresstitle_typography',
			'selector'	 => '{{WRAPPER}} .ved-adv-progressbar .progress-title',
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_section_progresspercentage', [
			'label'	 => esc_html__( 'Progress Percentage', 'godecore-data' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_progresspercentage_color', [
			'label'		 => esc_html__( 'Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'selectors'	 => [
				'{{WRAPPER}} .ved-adv-progressbar .progress-title span' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_progresspercentage_typography',
			'selector'	 => '{{WRAPPER}} .ved-adv-progressbar .progress-title span',
		]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings		 = $this->get_settings();
		$progress_bar_class	 = '';
		if ( $settings[ 'ved_display_striped' ] == 'show' ) {
			$progress_bar_class .= 'progress-bar-striped';
		}
		if ( $settings[ 'ved_striped_active' ] == 'show' ) {
			$progress_bar_class .= ' active';
		}
		?>
		<div class="ved-adv-progressbar">
			<h6 class="progress-title">
				<?php echo esc_html($settings[ 'ved_title' ]); ?> 
				<?php if ( 'hide' !== $settings[ 'ved_display_percentage' ] ) { ?>
					<span class="pull-right"><span></span>%</span>
				<?php } ?>
			</h6>
			<div class="progress">
				<div class="progress-bar <?php echo esc_attr($progress_bar_class); ?>" aria-valuenow="<?php echo esc_attr($settings[ 'ved_percent' ][ 'size' ]); ?>" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
			</div>
		</div>
		<?php
	}

	protected function content_template() {
		?>


		<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Adv_Progressbar() );
endif;