<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

if ( ! class_exists( 'Widget_Ved_Cat_Slider' ) ) :
class Widget_Ved_Cat_Slider extends Widget_Base {

    public $base;

    public function get_name() {
        return 'ved-woo-cats-slider';
    }

    public function get_title() {
        return esc_html__( 'Ved Category Slider', 'godecore-data' );
    }

    public function get_icon() {
        return 'eicon-woocommerce';
    }

    public function get_categories() {
        return [ 'godecore-addons' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
        'section_tab', [
            'label' => esc_html__( 'Select Categories', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_title', [
            'label'       => esc_html__( 'Heading Title', 'godecore-data' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( 'Categories Title Here', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_sub_title', [
            'label'       => esc_html__( 'Sub Heading Title', 'godecore-data' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => '',
        ]
        );
		
		$this->add_control(
        'ved_woo_cats_slider_style', [
            'label'   => esc_html__( 'Style', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'style1',
            'options' => [
                'style1' => esc_html__( 'Style One', 'godecore-data' ),
                'style2' => esc_html__( 'Style Two', 'godecore-data' ),
                'style3' => esc_html__( 'Style Three', 'godecore-data' ),
                'style4' => esc_html__( 'Style Four', 'godecore-data' ),
                'style5' => esc_html__( 'Style Five', 'godecore-data' ),
                'style6' => esc_html__( 'Style Six', 'godecore-data' ),
            ],
        ]
        );
		
		$this->add_control(
        'ved_woo_cats_slider_row', [
            'label'   => esc_html__( 'Row Layout', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'single_row',
            'options' => [
                'single_row' => esc_html__( 'Single Row', 'godecore-data' ),
                'double_row' => esc_html__( 'Double Row', 'godecore-data' ),
            ],
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_enable_img', [
            'label'   => esc_html__( 'Display Category Image?', 'godecore-data' ),
            'type'    => Controls_Manager::SWITCHER,
            'default' => 'yes',
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_item', [
            'type'        => Controls_Manager::REPEATER,
            'fields'      => [
                [
                    'name'    => 'ved_woo_cats_slider_image',
                    'label'   => esc_html__( 'Choose Category Image', 'godecore-data' ),
                    'type'    => Controls_Manager::MEDIA,
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ],
                [
                    'name'        => 'ved_woo_cats_slider_main',
                    'label'       => esc_html__( 'Main Category', 'godecore-data' ),
                    'type'        => Controls_Manager::SELECT2,
                    'label_block' => false,
                    'multiple'    => false,
                    'options'     => godecore_woocommerce_product_categories(),
					'default'	 => 'uncategorized',
                ],
            ],
            'title_field' => 'Category Item',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_woo_cat_selector_settings', [
            'label' => esc_html__( 'Category Slider Settings', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_custom_nav', [
            'label'        => esc_html__( 'Custom Nav Container', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_custom_nav_id', [
            'label'   => esc_html__( 'Element ID', 'godecore-data' ),
            'type'    => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( '#abc', 'godecore-data' ),
            'condition'   => [
                'ved_woo_cats_slider_custom_nav' => 'true'
            ]
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_desk_items', [
            'label'   => esc_html__( 'Show Desktop Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_desk_small_items', [
            'label'   => esc_html__( 'Show Desktop Small Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 2,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );
        
        $this->add_control(
        'ved_woo_cats_slider_tab_items', [
            'label'   => esc_html__( 'Show Tab Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 3,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_mob_items', [
            'label'   => esc_html__( 'Show Mobile Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 2,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_autoplay', [
            'label'        => esc_html__( 'AutoPlay', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
			'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_center', [
            'label'        => esc_html__( 'Center', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
			'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_navigation', [
            'label'        => esc_html__( 'Navigation', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_woo_cats_slider_pagination', [
            'label'        => esc_html__( 'Pagination', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();

        // Category Item Options
        $cat_title      = $settings[ 'ved_woo_cats_slider_title' ];
        $cat_sub_title      = $settings[ 'ved_woo_cats_slider_sub_title' ];
        $cat_style      = $settings[ 'ved_woo_cats_slider_style' ];
        $cat_enable_img = $settings[ 'ved_woo_cats_slider_enable_img' ];
		$cat_row = $settings[ 'ved_woo_cats_slider_row' ];
		$cnt = 1;

        // Slider Options
		$desk_items      = $settings[ 'ved_woo_cats_slider_desk_items' ];
        $desk_small_items      = $settings[ 'ved_woo_cats_slider_desk_small_items' ];
        $tab_items      = $settings[ 'ved_woo_cats_slider_tab_items' ];
        $mob_items      = $settings[ 'ved_woo_cats_slider_mob_items' ];
        $autoplay   = $settings[ 'ved_woo_cats_slider_autoplay' ];
        $center   = $settings[ 'ved_woo_cats_slider_center' ];
        $navigation = $settings[ 'ved_woo_cats_slider_navigation' ];
        $pagination = $settings[ 'ved_woo_cats_slider_pagination' ];

        if ( isset( $cat_title ) && $cat_title ) {
            ?>
            <div class="sec-head-style">
                <h3 class="text-title text-uppercase page-heading"><?php echo esc_html( $cat_title ); ?></h3>
                <?php if ( isset( $cat_sub_title ) && $cat_sub_title ) { ?>
                    <p class="page-subheading"><?php echo esc_html( $cat_sub_title ); ?></p>
                <?php } ?>
            </div>
        <?php }
		if ($cat_style != 'style6') {
        ?>
			<div id="ved-woo-cats-slider-<?php echo esc_attr( $this->get_id() ); ?>" class="row">
				<div class="ved-woo-cats-slider owl-carousel <?php echo esc_attr($cat_style); ?>">
					<?php
					foreach ( $settings[ 'ved_woo_cats_slider_item' ] as $cat_item ) :
						$cat_image = $cat_item[ 'ved_woo_cats_slider_image' ];
						$cat_slug    = $cat_item[ 'ved_woo_cats_slider_main' ];
						$cat_obj = get_term_by( 'slug', $cat_slug, 'product_cat' );

						if($cat_obj) {
							$cat_name  = get_the_category_by_ID( $cat_obj->term_id );
							$cat_link  = get_category_link( $cat_obj->term_id );
							$cat_desc  = category_description( $cat_obj->term_id );
						} else {
							$cat_name  = '';
							$cat_link  = '';
							$cat_desc  = '';
						}		

						if ( $cat_row == 'double_row' && $cnt % 2 != 0 ) {
							echo "<div class='item-inner'>";
						}

						switch ( $cat_style ) {
							case 'style1':
								require GODECORE_DATA_PATH . 'includes/style/cat-slider/style1.php';
								break;

							case 'style2':
								require GODECORE_DATA_PATH . 'includes/style/cat-slider/style2.php';
								break;

							case 'style3':
								require GODECORE_DATA_PATH . 'includes/style/cat-slider/style3.php';
								break;

							case 'style4':
								require GODECORE_DATA_PATH . 'includes/style/cat-slider/style4.php';
								break;

							case 'style5':
								require GODECORE_DATA_PATH . 'includes/style/cat-slider/style5.php';
								break;      
						}

						if ( $cat_row == 'double_row' && $cnt % 2 == 0 ) {
							echo '</div>';
						}

						$cnt ++;
					endforeach; ?>
				</div>
			</div>
        <?php 
		} else {
			require GODECORE_DATA_PATH . 'includes/style/cat-slider/style6.php';
		}
		$custom_nav_id = '';
		if($settings[ 'ved_woo_cats_slider_custom_nav' ]) { 
                $custom_nav_id = $settings[ 'ved_woo_cats_slider_custom_nav_id' ];
		}
		if ($cat_style != 'style6') {
		?>
        <script type="text/javascript">
            jQuery(window).ready(function ($) {
                setTimeout(function(){ 
                    var category_sld = $("#ved-woo-cats-slider-<?php echo esc_js( $this->get_id() ); ?> .ved-woo-cats-slider");
                    category_sld.owlCarousel({
                        autoplay: <?php echo ($autoplay == 'true') ? 'true' : 'false'; ?>,
                        center: <?php echo ($center == 'true') ? 'true' : 'false'; ?>,
                        autoplayHoverPause:true,
                        nav: <?php echo ($navigation == 'true') ? 'true' : 'false'; ?>,
                        dots: <?php echo ($pagination == 'true') ? 'true' : 'false'; ?>,
                        items: <?php echo esc_js($desk_items); ?>,
                        loop: <?php echo ($center == 'true') ? 'true' : 'false'; ?>,
                        navContainer: '<?php echo esc_js($custom_nav_id); ?>',
                        rewind:true,
                        navText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
                        responsive:{
                            0:{
                                items:<?php echo esc_js($mob_items); ?>},
                            768:{
                                items:<?php echo esc_js($tab_items); ?>},
                            992:{
                                items:<?php echo esc_js($desk_small_items); ?>},
                            1200:{
                                items:<?php echo esc_js($desk_items); ?>}
                        }  
                    });
                }, 300);
            });
        </script>
        <?php
		}
    }

    protected function _content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Cat_Slider() );
endif;