<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
	exit; // If this file is called directly, abort.

if ( ! class_exists( 'Widget_Ved_Piechart' ) ) :
class Widget_Ved_Piechart extends Widget_Base {

	public function get_name() {
		return 'ved-piechart';
	}

	public function get_title() {
		return esc_html__( 'Ved Piechart', 'godecore-data' );
	}

	public function get_icon() {
		return 'eicon-counter-circle';
	}

	public function get_categories() {
		return [ 'godecore-addons' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
		'ved_section_piechart', [
			'label' => esc_html__( 'Piechart', 'godecore-data' ),
		]
		);

		$this->add_control(
		'ved_piechart_title', [
			'label'		 => esc_html__( 'Title', 'godecore-data' ),
			'type'		 => Controls_Manager::TEXT,
			'dynamic'	 => [
				'active' => true,
			],
			'placeholder'	 => esc_html__( 'Enter your title', 'godecore-data' ),
			'default'	 => esc_html__( 'Branding', 'godecore-data' ),
			'label_block'	 => true,
		]
		);

		$this->add_control(
		'ved_piechart_content', [
			'label'		 => esc_html__( 'Content', 'elementor' ),
			'type'		 => Controls_Manager::TEXTAREA,
			'dynamic'	 => [
				'active' => true,
			],
			'rows'		 => '10',
			'default'	 => 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
		]
		);

		$this->add_control(
		'ved_piechart_percent', [
			'label'		 => esc_html__( 'Percentage', 'godecore-data' ),
			'type'		 => Controls_Manager::SLIDER,
			'default'	 => [
				'size'	 => 50,
				'unit'	 => '%',
			],
			'label_block'	 => true,
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_piechart_section_styling', [
			'label'	 => esc_html__( 'Piechart Styling', 'godecore-data' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_piechart_bar_color', [
			'label'		 => esc_html__( 'Bar color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'default'	 => '#3ab54a',
		]
		);

//        $this->add_control(
//            'ved_piechart_track_color',
//            [
//                'label' => esc_html__('Track color', 'godecore-data'),
//                'type' => Controls_Manager::COLOR,
//                'default' => '#dddddd',
//            ]
//        );

		$this->end_controls_section();


		$this->start_controls_section(
		'ved_piechart_section_title', [
			'label'	 => esc_html__( 'Piechart Title', 'godecore-data' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_piechart_title_color', [
			'label'		 => esc_html__( 'Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'selectors'	 => [
				'{{WRAPPER}} .ved-piechart .chart-title h4' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_piechart_title_typography',
			'selector'	 => '{{WRAPPER}} .ved-piechart .chart-title h4',
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_piechart_section_content', [
			'label'	 => esc_html__( 'Piechart Content', 'godecore-data' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_piechart_content_color', [
			'label'		 => esc_html__( 'Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'selectors'	 => [
				'{{WRAPPER}} .ved-piechart .chart-title p' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_piechart_content_typography',
			'selector'	 => '{{WRAPPER}} .ved-piechart .chart-title p',
		]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		'ved_piechart_section_percentage', [
			'label'	 => esc_html__( 'Piechart Percentage', 'godecore-data' ),
			'tab'	 => Controls_Manager::TAB_STYLE,
		]
		);

		$this->add_control(
		'ved_piechart_percentage_color', [
			'label'		 => esc_html__( 'Color', 'godecore-data' ),
			'type'		 => Controls_Manager::COLOR,
			'selectors'	 => [
				'{{WRAPPER}} .ved-piechart .chart-text' => 'color: {{VALUE}};',
			],
		]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(), [
			'name'		 => 'ved_piechart_percentage_typography',
			'selector'	 => '{{WRAPPER}} .ved-piechart .chart-text',
		]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();
		?>
		<div class="ved-piechart">
			<div class="pie-chart">
				<div class="chart" data-percent="<?php echo esc_attr($settings[ 'ved_piechart_percent' ][ 'size' ]); ?>" data-chart-options='{"barColor":"<?php echo esc_attr($settings[ 'ved_piechart_bar_color' ]); ?>"}'>
					<div class="chart-text"><?php echo esc_attr($settings[ 'ved_piechart_percent' ][ 'size' ]); ?>%</div>
				</div>
				<div class="chart-title">
					<h4><?php echo esc_html($settings[ 'ved_piechart_title' ]); ?></h4>
					<p><?php echo $settings[ 'ved_piechart_content' ]; ?></p>
				</div>
			</div>
		</div>
		<?php
	}

	protected function content_template() {
		?>


		<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Piechart() );
endif;