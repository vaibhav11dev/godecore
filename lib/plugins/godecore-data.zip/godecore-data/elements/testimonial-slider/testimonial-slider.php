<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

if ( ! class_exists( 'Widget_Ved_Testimonial_Slider' ) ) :
class Widget_Ved_Testimonial_Slider extends Widget_Base {

    public function get_name() {
        return 'ved-testimonial-slider';
    }

    public function get_title() {
        return esc_html__( 'Ved Testimonial Slider', 'godecore-data' );
    }

    public function get_icon() {
        return 'fa fa-comments-o';
    }

    public function get_categories() {
        return [ 'godecore-addons' ];
    }

    protected function _register_controls() {


        $this->start_controls_section(
        'ved_section_testimonial_content', [
            'label' => esc_html__( 'Testimonial Content', 'godecore-data' )
        ]
        );

        $this->add_control(
        'ved_testimonial_slider_title', [
            'label'       => esc_html__( 'Title', 'godecore-data' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( 'Testimonial Title Here', 'godecore-data' ),
        ]
        );




        $this->add_control(
        'ved_testimonial_style', [
            'label'   => esc_html__( 'Style', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'style1',
            'options' => [
                'style1' => esc_html__( 'Style 1', 'godecore-data' ),
                'style2' => esc_html__( 'Style 2', 'godecore-data' ),
                'style3' => esc_html__( 'Style 3', 'godecore-data' ),
            ],
        ]
        );





        $this->add_control(
        'ved_testimonial_slider_item', [
            'type'        => Controls_Manager::REPEATER,
            'default'     => [
                [
                    'ved_testimonial_name' => 'John Doe',
                ],
                [
                    'ved_testimonial_name' => 'Jane Doe',
                ],
            ],
            'fields'      => [
                [
                    'name'    => 'ved_testimonial_enable_avatar',
                    'label'   => esc_html__( 'Display Avatar?', 'godecore-data' ),
                    'type'    => Controls_Manager::SWITCHER,
                    'default' => 'yes',
                ],
                [
                    'name'      => 'ved_testimonial_image',
                    'label'     => esc_html__( 'Testimonial Avatar', 'godecore-data' ),
                    'type'      => Controls_Manager::MEDIA,
                    'default'   => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                    'condition' => [
                        'ved_testimonial_enable_avatar' => 'yes',
                    ],
                ],
                [
                    'name'    => 'ved_testimonial_name',
                    'label'   => esc_html__( 'User Name', 'godecore-data' ),
                    'type'    => Controls_Manager::TEXT,
                    'default' => esc_html__( 'John Doe', 'godecore-data' ),
                    'dynamic' => [ 'active' => true ]
                ],
                [
                    'name'    => 'ved_testimonial_company_title',
                    'label'   => esc_html__( 'Company Name', 'godecore-data' ),
                    'type'    => Controls_Manager::TEXT,
                    'default' => esc_html__( 'webheaythemes', 'godecore-data' ),
                    'dynamic' => [ 'active' => true ]
                ],
                [
                    'name'    => 'ved_testimonial_description',
                    'label'   => esc_html__( 'Testimonial Description', 'godecore-data' ),
                    'type'    => Controls_Manager::TEXTAREA,
                    'default' => esc_html__( 'Add testimonial description here. Edit and place your own text.', 'godecore-data' ),
                ],
                [
                    'name'    => 'ved_testimonial_enable_rating',
                    'label'   => esc_html__( 'Display Rating?', 'godecore-data' ),
                    'type'    => Controls_Manager::SWITCHER,
                    'default' => 'yes',
                ],
                [
                    'name'      => 'ved_testimonial_rating_number',
                    'label'     => esc_html__( 'Rating Number', 'your-plugin' ),
                    'type'      => Controls_Manager::SELECT,
                    'default'   => 'rating-five',
                    'options'   => [
                        'rating-one'   => esc_html__( '1', 'godecore-data' ),
                        'rating-two'   => esc_html__( '2', 'godecore-data' ),
                        'rating-three' => esc_html__( '3', 'godecore-data' ),
                        'rating-four'  => esc_html__( '4', 'godecore-data' ),
                        'rating-five'  => esc_html__( '5', 'godecore-data' ),
                    ],
                    'condition' => [
                        'ved_testimonial_enable_rating' => 'yes',
                    ],
                ],
            ],
            'title_field' => 'Testimonial Item',
        ]
        );



        $this->end_controls_section();



        $this->start_controls_section(
        'ved_section_testimonial_slider_settings', [
            'label' => esc_html__( 'Testimonial Slider Settings', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_testimonial_slider_desk_items', [
            'label'   => esc_html__( 'Show Desktop Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 1,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_testimonial_slider_desk_small_items', [
            'label'   => esc_html__( 'Show Desktop Small Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 1,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );
        
        $this->add_control(
        'ved_testimonial_slider_tab_items', [
            'label'   => esc_html__( 'Show Tab Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 1,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_testimonial_slider_mob_items', [
            'label'   => esc_html__( 'Show Mobile Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 1,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_testimonial_slider_autoplay', [
            'label'        => esc_html__( 'AutoPlay', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_testimonial_slider_navigation', [
            'label'        => esc_html__( 'Navigation', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_testimonial_slider_pagination', [
            'label'        => esc_html__( 'Pagination', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
        'ved_section_testimonial_styles_general', [
            'label' => esc_html__( 'Testimonial Styles', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

        $this->add_control(
        'ved_testimonial_background', [
            'label'     => esc_html__( 'Testimonial Background Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '',
            'selectors' => [
                '{{WRAPPER}} .ved-testimonial-item' => 'background-color: {{VALUE}};',
            ],
        ]
        );

        $this->add_control(
        'ved_testimonial_alignment', [
            'label'       => esc_html__( 'Set Alignment', 'godecore-data' ),
            'type'        => Controls_Manager::CHOOSE,
            'label_block' => true,
            'options'     => [
                'ved-testimonial-align-left'     => [
                    'title' => esc_html__( 'Left', 'godecore-data' ),
                    'icon'  => 'fa fa-align-left',
                ],
                'ved-testimonial-align-centered' => [
                    'title' => esc_html__( 'Center', 'godecore-data' ),
                    'icon'  => 'fa fa-align-center',
                ],
                'ved-testimonial-align-right'    => [
                    'title' => esc_html__( 'Right', 'godecore-data' ),
                    'icon'  => 'fa fa-align-right',
                ],
            ],
            'default'     => 'ved-testimonial-align-centered',
        ]
        );

        $this->add_responsive_control(
        'ved_testimonial_margin', [
            'label'       => esc_html__( 'Margin', 'godecore-data' ),
            'description' => 'Need to refresh the page to see the change properly',
            'type'        => Controls_Manager::DIMENSIONS,
            'size_units'  => [ 'px', '%', 'em' ],
            'selectors'   => [
                '{{WRAPPER}} .ved-testimonial-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );

        $this->add_responsive_control(
        'ved_testimonial_padding', [
            'label'      => esc_html__( 'Padding', 'godecore-data' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-testimonial-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Border::get_type(), [
            'name'     => 'ved_testimonial_border',
            'label'    => esc_html__( 'Border', 'godecore-data' ),
            'selector' => '{{WRAPPER}} .ved-testimonial-item',
        ]
        );

        $this->add_control(
        'ved_testimonial_border_radius', [
            'label'     => esc_html__( 'Border Radius', 'godecore-data' ),
            'type'      => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .ved-testimonial-item' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
            ],
        ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
        'ved_section_testimonial_image_styles', [
            'label' => esc_html__( 'Testimonial Image Style', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

        $this->add_responsive_control(
        'ved_testimonial_image_width', [
            'label'      => esc_html__( 'Image Width', 'godecore-data' ),
            'type'       => Controls_Manager::SLIDER,
            'default'    => [
                'size' => 150,
                'unit' => 'px',
            ],
            'range'      => [
                '%'  => [
                    'min' => 0,
                    'max' => 100,
                ],
                'px' => [
                    'min' => 0,
                    'max' => 1000,
                ],
            ],
            'size_units' => [ '%', 'px' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-testimonial-image img' => 'width:{{SIZE}}{{UNIT}};',
            ],
        ]
        );


        $this->add_responsive_control(
        'ved_testimonial_image_margin', [
            'label'      => esc_html__( 'Margin', 'godecore-data' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-testimonial-image img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );

        $this->add_responsive_control(
        'ved_testimonial_image_padding', [
            'label'      => esc_html__( 'Padding', 'godecore-data' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-testimonial-image img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
        );


        $this->add_group_control(
        Group_Control_Border::get_type(), [
            'name'     => 'ved_testimonial_image_border',
            'label'    => esc_html__( 'Border', 'godecore-data' ),
            'selector' => '{{WRAPPER}} .ved-testimonial-image img',
        ]
        );

        $this->add_control(
        'ved_testimonial_image_rounded', [
            'label'        => esc_html__( 'Rounded Avatar?', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'testimonial-avatar-rounded',
            'default'      => '',
        ]
        );


        $this->add_control(
        'ved_testimonial_image_border_radius', [
            'label'     => esc_html__( 'Border Radius', 'godecore-data' ),
            'type'      => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .ved-testimonial-image img' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
            ],
            'condition' => [
                'ved_testimonial_image_rounded!' => 'testimonial-avatar-rounded',
            ],
        ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
        'ved_section_testimonial_typography', [
            'label' => esc_html__( 'Color &amp; Typography', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

        $this->add_control(
        'ved_testimonial_name_heading', [
            'label' => esc_html__( 'User Name', 'godecore-data' ),
            'type'  => Controls_Manager::HEADING,
        ]
        );

        $this->add_control(
        'ved_testimonial_name_color', [
            'label'     => esc_html__( 'User Name Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '',
            'selectors' => [
                '{{WRAPPER}} .ved-author-info .ved-testimonial-user' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_testimonial_name_typography',
            'selector' => '{{WRAPPER}} .ved-author-info .ved-testimonial-user',
        ]
        );

        $this->add_control(
        'ved_testimonial_company_heading', [
            'label' => esc_html__( 'Company Name', 'godecore-data' ),
            'type'  => Controls_Manager::HEADING,
        ]
        );


        $this->add_control(
        'ved_testimonial_company_color', [
            'label'     => esc_html__( 'Company Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '',
            'selectors' => [
                '{{WRAPPER}} .ved-author-info .ved-testimonial-user-company' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_testimonial_position_typography',
            'selector' => '{{WRAPPER}} .ved-author-info .ved-testimonial-user-company',
        ]
        );

        $this->add_control(
        'ved_testimonial_description_heading', [
            'label' => esc_html__( 'Testimonial Text', 'godecore-data' ),
            'type'  => Controls_Manager::HEADING,
        ]
        );

        $this->add_control(
        'ved_testimonial_description_color', [
            'label'     => esc_html__( 'Testimonial Text Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '',
            'selectors' => [
                '{{WRAPPER}} .ved-testimonial-text' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_testimonial_description_typography',
            'selector' => '{{WRAPPER}} .ved-testimonial-text',
        ]
        );

        $this->end_controls_section();        
    }

    protected function render() {

        $settings            = $this->get_settings_for_display();
        $testimonial_title      = $settings[ 'ved_testimonial_slider_title' ];
        $testimonial_classes = $this->get_settings( 'ved_testimonial_image_rounded' ) . " " . $this->get_settings( 'ved_testimonial_alignment' );
        $navigation_type     = $this->get_settings( 'ved_testimonial_slider_navigation' );


        $style     = $settings[ 'ved_testimonial_style' ];

        // Slider Options        
        $desk_items      = $settings[ 'ved_testimonial_slider_desk_items' ];
        $desk_small_items      = $settings[ 'ved_testimonial_slider_desk_small_items' ];
        $tab_items      = $settings[ 'ved_testimonial_slider_tab_items' ];
        $mob_items      = $settings[ 'ved_testimonial_slider_mob_items' ];
        $autoplay   = $settings[ 'ved_testimonial_slider_autoplay' ];
        $navigation = $settings[ 'ved_testimonial_slider_navigation' ];
        $pagination = $settings[ 'ved_testimonial_slider_pagination' ];

        if ( isset( $testimonial_title ) && $testimonial_title ) {
            ?>
            <div class="sec-head-style">
                <h3 class="text-title text-uppercase page-heading"><?php echo esc_html( $testimonial_title ); ?></h3>
            </div>
        <?php }
        ?>
        
            <?php
                switch ( $style ) {
                    case 'style1':
                        require GODECORE_DATA_PATH . 'includes/style/testimonial-slider/style1.php';
                        break;

                    case 'style2':
                        require GODECORE_DATA_PATH . 'includes/style/testimonial-slider/style2.php';
                        break;

                    case 'style3':
                        require GODECORE_DATA_PATH . 'includes/style/testimonial-slider/style3.php';
                        break;
                }
            ?>

        <?php
    }

    protected function content_template() {
        ?>


        <?php
    }

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Testimonial_Slider() );
endif;