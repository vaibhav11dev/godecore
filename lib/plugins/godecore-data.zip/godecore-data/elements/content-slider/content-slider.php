<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

if ( ! class_exists( 'Widget_Ved_Content_Slider' ) ) :
class Widget_Ved_Content_Slider extends Widget_Base {

    public function get_name() {
        return 'ved-content-slider';
    }

    public function get_title() {
        return esc_html__( 'Ved Content Slider', 'godecore-data' );
    }

    public function get_icon() {
        return 'eicon-slider-push';
    }

    public function get_categories() {
        return [ 'godecore-addons' ];
    }

    protected function _register_controls() {
        $this->start_controls_section(
        'section_tab', [
            'label' => esc_html__( 'Ved Content Slider', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_slider_fullheight', [
            'label'        => esc_html__( 'Show Slide Full Height', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'sliders', [
            'label'       => esc_html__( 'Slide Item', 'godecore-data' ),
            'type'        => Controls_Manager::REPEATER,
            'separator'   => 'before',
            'default'     => [
                [
                    'title'         => esc_html__( 'Add Title', 'godecore-data' ),
                    'sub_title'     => esc_html__( 'Add Sub Title', 'godecore-data' ),
                    'btn_label_one' => esc_html__( 'Learn More', 'godecore-data' ),
                    'btn_label_two' => esc_html__( 'Learn More', 'godecore-data' ),
                ],
                [
                    'title'         => esc_html__( 'Add Title', 'godecore-data' ),
                    'sub_title'     => esc_html__( 'Add Sub Title', 'godecore-data' ),
                    'btn_label_one' => esc_html__( 'Learn More', 'godecore-data' ),
                    'btn_label_two' => esc_html__( 'Learn More', 'godecore-data' ),
                ],
                [
                    'title'         => esc_html__( 'Add Title', 'godecore-data' ),
                    'sub_title'     => esc_html__( 'Add Sub Title', 'godecore-data' ),
                    'btn_label_one' => esc_html__( 'Learn More', 'godecore-data' ),
                    'btn_label_two' => esc_html__( 'Learn More', 'godecore-data' ),
                ],
            ],
            'fields'      => [
                [
                    'name'        => 'image',
                    'label'       => esc_html__( 'Background Image', 'godecore-data' ),
                    'type'        => Controls_Manager::MEDIA,
                    'default'     => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                    'label_block' => true,
                ],
                [
                    'name'  => 'title',
                    'label' => esc_html__( 'Title', 'godecore-data' ),
                    'type'  => Controls_Manager::TEXT,
                ],
                [
                    'name'  => 'sub_title',
                    'label' => esc_html__( 'Sub Title', 'godecore-data' ),
                    'type'  => Controls_Manager::TEXTAREA,
                ],
                [
                    'name'        => 'btn_label_one',
                    'label'       => esc_html__( 'Button Label', 'godecore-data' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'default'     => esc_html__( 'LEARN MORE', 'godecore-data' ),
                ],
                [
                    'name'        => 'btn_link_one',
                    'label'       => esc_html__( 'Link', 'godecore-data' ),
                    'type'        => Controls_Manager::URL,
                    'placeholder' => esc_html__( 'http://your-link.com', 'godecore-data' ),
                    'default'     => [
                        'url' => '',
                    ],
                ],
                [
                    'name'        => 'btn_label_two',
                    'label'       => esc_html__( 'Button Label', 'godecore-data' ),
                    'type'        => Controls_Manager::TEXT,
                    'label_block' => true,
                    'default'     => esc_html__( 'LEARN MORE', 'godecore-data' ),
                ],
                [
                    'name'        => 'btn_link_two',
                    'label'       => esc_html__( 'Link', 'godecore-data' ),
                    'type'        => Controls_Manager::URL,
                    'placeholder' => esc_html__( 'http://your-link.com', 'godecore-data' ),
                    'default'     => [
                        'url' => '',
                    ],
                ],
                [
                    'name'    => 'align',
                    'label'   => esc_html__( 'Content Alignment', 'godecore-data' ),
                    'type'    => Controls_Manager::SELECT,
                    'default' => 'center',
                    'options' => [
                        'left'   => esc_html__( 'Left', 'godecore-data' ),
                        'center' => esc_html__( 'Center', 'godecore-data' ),
                        'right'  => esc_html__( 'Right', 'godecore-data' ),
                    ],
                ],
            ],
            'title_field' => '{{{ title }}}',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'ved_section_slider_settings', [
            'label' => esc_html__( 'Image Slider Settings', 'godecore-data' )
        ]
        );

        $this->add_control(
        'ved_slider_type', [
            'label'       => esc_html__( 'Slider Type', 'godecore-data' ),
            'type'        => Controls_Manager::SELECT,
            'default'     => 'default',
            'label_block' => false,
            'options'     => [
                'default'   => esc_html__( 'Default', 'godecore-data' ),
                'fade'      => esc_html__( 'Fade', 'godecore-data' ),
                'backSlide' => esc_html__( 'BackSlide', 'godecore-data' ),
                'goDown'    => esc_html__( 'GoDown', 'godecore-data' ),
                'fadeUp'    => esc_html__( 'FadeUp', 'godecore-data' ),
            ],
        ]
        );

        $this->add_control(
        'ved_slider_autoplay', [
            'label'        => esc_html__( 'AutoPlay', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_slider_navigation', [
            'label'        => esc_html__( 'Navigation', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_slider_pagination', [
            'label'        => esc_html__( 'Pagination', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();

        //Background Overlay
        $this->start_controls_section(
        'slider_bg_overlay', [
            'label' => esc_html__( 'Background Overlay', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
        );

        $this->add_control(
        'slider_bg_img_overlay', [
            'label'     => esc_html__( 'Background Overlay', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-banner-item' => 'background-color: {{VALUE}};'
            ],
        ]
        );

        $this->end_controls_section();


        //Title Style
        $this->start_controls_section(
        'slider_title_style', [
            'label' => esc_html__( 'Title', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
        );

        $this->add_control(
        'slider_title_color', [
            'label'     => esc_html__( 'Title color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-banner-content .ved-banner-title' => 'color: {{VALUE}};'
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'label'    => esc_html__( 'Typography', 'godecore-data' ),
            'selector' => '{{WRAPPER}} .ved-banner-content .ved-banner-title',
        ]
        );

        $this->add_control(
        'slider_title_margin', [
            'label'      => esc_html__( 'Margin', 'godecore-data' ),
            'type'       => Controls_Manager::SLIDER,
            'default'    => [
                'size' => '',
            ],
            'range'      => [
                'px' => [
                    'min' => 0,
                    'max' => 100,
                ],
            ],
            'size_units' => [ 'px' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-banner-content .ved-banner-title' => 'margin-bottom: {{SIZE}}px;',
            ],
        ]
        );
        $this->end_controls_section();


        //Subtitle Style
        $this->start_controls_section(
        'slider_subtitle_style', [
            'label' => esc_html__( 'Subtitle', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
        );

        $this->add_control(
        'slider_subtitle_color', [
            'label'     => esc_html__( 'Subtitle color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-banner-content .ved-banner-sub-title' => 'color: {{VALUE}};'
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'subtitle_typography',
            'label'    => esc_html__( 'Typography', 'godecore-data' ),
            'selector' => '{{WRAPPER}} .ved-banner-content .ved-banner-sub-title',
        ]
        );

        $this->add_control(
        'slider_subtitle_margin', [
            'label'      => esc_html__( 'Margin', 'godecore-data' ),
            'type'       => Controls_Manager::SLIDER,
            'default'    => [
                'size' => '',
            ],
            'range'      => [
                'px' => [
                    'min' => 0,
                    'max' => 100,
                ],
            ],
            'size_units' => [ 'px' ],
            'selectors'  => [
                '{{WRAPPER}} .ved-banner-content .ved-banner-sub-title' => 'margin-bottom: {{SIZE}}px;',
            ],
        ]
        );
        $this->end_controls_section();

        //Button Style 1
        $this->start_controls_section(
        'slider_button_style', [
            'label' => esc_html__( 'Button Styles 1', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
        );

        $this->add_control(
        'slider_btn_text_color', [
            'label'     => esc_html__( 'Text color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-banner-content .btn.btn-outline-primary' => 'color: {{VALUE}};'
            ],
        ]
        );

        $this->add_control(
        'slider_btn_text_hover_color', [
            'label'     => esc_html__( 'Text Hover color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-banner-content .btn.btn-outline-primary:hover' => 'color: {{VALUE}};'
            ],
        ]
        );

        $this->add_control(
        'slider_btn_bg_color', [
            'label'     => esc_html__( 'Button Background', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-banner-content .btn.btn-outline-primary' => 'background-color: {{VALUE}};'
            ],
        ]
        );

        $this->add_control(
        'slider_btn_bg_hover_color', [
            'label'     => esc_html__( 'Button Background Hover', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-banner-content .btn.btn-outline-primary:hover:before' => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .ved-banner-content .btn.btn-outline-primary:hover'        => 'border-color: {{VALUE}};background-color: {{VALUE}};'
            ],
        ]
        );

        $this->add_control(
        'slider_btn_border_color', [
            'label'     => esc_html__( 'Border color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-banner-content .btn.btn-outline-primary' => 'border-color: {{VALUE}};'
            ],
        ]
        );

        $this->end_controls_section();

        //Button Style 2
        $this->start_controls_section(
        'slider_button_style_two', [
            'label' => esc_html__( 'Button Styles 2', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
        );

        $this->add_control(
        'slider_btn_text_color_two', [
            'label'     => esc_html__( 'Text color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-banner-content .btn.btn-outline-primary.btn2' => 'color: {{VALUE}};'
            ],
        ]
        );

        $this->add_control(
        'slider_btn_text_hover_color_two', [
            'label'     => esc_html__( 'Text Hover color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-banner-content .btn.btn-outline-primary.btn2:hover' => 'color: {{VALUE}};'
            ],
        ]
        );

        $this->add_control(
        'slider_btn_bg_color_two', [
            'label'     => esc_html__( 'Button Background', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-banner-content .btn.btn-outline-primary.btn2' => 'background-color: {{VALUE}};'
            ],
        ]
        );

        $this->add_control(
        'slider_btn_bg_hover_color_two', [
            'label'     => esc_html__( 'Button Background Hover', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-banner-content .btn.btn-outline-primary.btn2:hover:before' => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .ved-banner-content .btn.btn-outline-primary.btn2:hover'        => 'border-color: {{VALUE}};'
            ],
        ]
        );

        $this->add_control(
        'slider_btn_border_color_two', [
            'label'     => esc_html__( 'Border color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-banner-content .btn.btn-outline-primary.btn2' => 'border-color: {{VALUE}};'
            ],
        ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();

        // Slider Options
        $type       = $settings[ 'ved_slider_type' ];
        $autoplay   = $settings[ 'ved_slider_autoplay' ];
        $navigation = $settings[ 'ved_slider_navigation' ];
        $pagination = $settings[ 'ved_slider_pagination' ];

        $sliders    = $settings[ 'sliders' ];
        $fullheight = $settings[ 'ved_slider_fullheight' ];

        $height_class = '';
        if ( $fullheight ) {
            $height_class = 'fullheight';
        }

        if ( $type != 'default' ) {
            ?>
            <div class="godecore-slider color-white <?php echo esc_attr( $height_class ); ?>" data-carousel-options='{"transitionStyle": "<?php echo esc_attr( $type ); ?>"}'>
                <?php
            } else {
                ?>
                <div class="godecore-slider color-white <?php echo esc_attr( $height_class ); ?>">
                    <?php
                }
                ?>
                <ul id="ved-slider-<?php echo esc_attr( $this->get_id() ); ?>" class="slides">
                    <?php
                    foreach ( $sliders as $item ) :
                        $background_type = 'style="background-image: url(' . esc_url( $item[ 'image' ][ 'url' ] ) . ')"';
                        ?>

                        <!-- SLIDE -->
                        <li class="bg-black-alfa-40" <?php echo $background_type; ?>>
                            <!-- HERO TEXT -->
                            <div class="hero-caption">
                                <div class="hero-text">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-sm-12 text-<?php echo esc_attr( $item[ 'align' ] ); ?>">

                                                <?php
                                                if ( isset( $item[ 'title' ] ) && $item[ 'title' ] ) {
                                                    ?>
                                                    <h1 class="text-title text-uppercase m-b-50 m-t-70"><?php echo esc_attr( $item[ 'title' ] ); ?></h1>
                                                    <?php
                                                }
                                                if ( isset( $item[ 'sub_title' ] ) && $item[ 'sub_title' ] ) {
                                                    ?>
                                                    <p><?php echo esc_attr( $item[ 'sub_title' ] ); ?></p>
                                                    <?php
                                                }
                                                if ( (isset( $item[ 'btn_link_one' ][ 'url' ] ) && $item[ 'btn_link_one' ][ 'url' ]) || (isset( $item[ 'btn_link_two' ][ 'url' ] ) && $item[ 'btn_link_two' ][ 'url' ]) ) {
                                                    ?>
                                                    <div class="m-t-50">
                                                        <?php
                                                        if ( isset( $item[ 'btn_label_one' ] ) && $item[ 'btn_label_one' ] ) {
                                                            ?>
                                                            <a href="<?php echo esc_url( $item[ 'btn_link_one' ][ 'url' ] ); ?>" class="btn btn-circle btn-white btn-lg"><?php echo esc_attr( $item[ 'btn_label_one' ] ); ?></a>
                                                            <?php
                                                        }
                                                        if ( isset( $item[ 'btn_label_two' ] ) && $item[ 'btn_label_two' ] ) {
                                                            ?>
                                                            <a href="<?php echo esc_url( $item[ 'btn_link_two' ][ 'url' ] ); ?>" class="btn btn-circle btn-white btn-lg"><?php echo esc_attr( $item[ 'btn_label_two' ] ); ?></a>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!-- END HERO TEXT -->
                        </li>
                        <!-- END SLIDE -->

                    <?php endforeach; ?>
                </ul>
            </div>
            <script type="text/javascript">
                jQuery(document).ready(function ($) {
                    $("#ved-slider-<?php echo esc_js( $this->get_id() ); ?>").each(function () {
                        $(this).owlCarousel($.extend({
                            autoplay: <?php echo esc_js($autoplay) ? 'true' : 'false'; ?>,
                            nav: <?php echo esc_js($navigation) ? 'true' : 'false'; ?>,
                            dots: <?php esc_js( $pagination) ? 'true' : 'false'; ?>,
                            singleItem: true,
                            items: 1,
                            navigationText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>']
                        }, $(this).data("carousel-options")));
                    });
                });
            </script>
            <?php
        }

        protected function _content_template() {
            
        }

    }

    Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Content_Slider() );
  endif;  