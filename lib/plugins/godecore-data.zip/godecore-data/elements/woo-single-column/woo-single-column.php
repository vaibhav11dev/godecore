<?php
namespace Elementor;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

if ( ! class_exists( 'Widget_Ved_Single_Column' ) ) :
class Widget_Ved_Single_Column extends Widget_Base {

    public function get_name() {
        return 'ved-woo-single-column';
    }

    public function get_title() {
        return esc_html__( 'Ved Single Column', 'godecore-data' );
    }

    public function get_icon() {
        return 'eicon-woocommerce';
    }

    public function get_categories() {
        return [ 'godecore-addons' ];
    }

    protected function _register_controls() {

        // Content Controls
        $this->start_controls_section(
        'ved_section_single_column_settings', [
            'label' => esc_html__( 'Product Settings', 'godecore-data' )
        ]
        );

        $this->add_control(
        'ved_single_column_title', [
            'label'       => esc_html__( 'Heading Title', 'godecore-data' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( 'Feature Product', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_single_column_filter', [
            'label'   => esc_html__( 'Filter By', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'featured',
            'options' => [
				'featured'     => esc_html__( 'Featured Product', 'godecore-data' ),
                'recent'       => esc_html__( 'Recent Product', 'godecore-data' ),
                'best_sell' => esc_html__( 'Popular Product', 'godecore-data' ),
                'on_sell'         => esc_html__( 'Sale Product', 'godecore-data' ),
                'top_rate'          => esc_html__( 'Top Rated Products', 'godecore-data' ),
            ],
        ]
        );

        $this->add_control(
        'ved_single_column_total_count', [
            'label'   => esc_html__( 'Total Number Of Products To Show', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 6,
            'min'     => 1,
            'max'     => 1000,
            'step'    => 1,
        ]
        );
		
		$this->add_control(
        'ved_single_column_count', [
            'label'   => esc_html__( 'Number Of Products To Show', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 10,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_single_column_rating', [
            'label'        => esc_html__( 'Show Product Rating?', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => 'yes',
        ]
        );

        $this->end_controls_section();
		
		$this->start_controls_section(
        'ved_section_single_column_slider_settings', [
            'label' => esc_html__( 'Single Column Slider Settings', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_single_column_desk_items', [
            'label'   => esc_html__( 'Show Desktop Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 1,
        ]
        );

        $this->add_control(
        'ved_single_column_desk_small_items', [
            'label'   => esc_html__( 'Show Desktop Small Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 1,
        ]
        );
        
        $this->add_control(
        'ved_single_column_tab_items', [
            'label'   => esc_html__( 'Show Tab Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 1,
        ]
        );

        $this->add_control(
        'ved_single_column_mob_items', [
            'label'   => esc_html__( 'Show Mobile Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 1,
        ]
        );

        $this->add_control(
        'ved_single_column_slider_autoplay', [
            'label'        => esc_html__( 'AutoPlay', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_single_column_slider_navigation', [
            'label'        => esc_html__( 'Navigation', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_single_column_slider_pagination', [
            'label'        => esc_html__( 'Pagination', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();
        
        $this->start_controls_section(
        'ved_section_single_column_grid_typography', [
            'label' => esc_html__( 'Color &amp; Typography', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE
        ]
        );

        $this->add_control(
        'ved_single_column_title_heading', [
            'label' => esc_html__( 'Product Title', 'godecore-data' ),
            'type'  => Controls_Manager::HEADING,
        ]
        );

        $this->add_control(
        'ved_single_column_title_color', [
            'label'     => esc_html__( 'Product Title Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#222222',
            'selectors' => [
                '{{WRAPPER}} .ved-woo-product .woocommerce .woocommerce-loop-single_column__title .woocommerce-loop-single_column__link' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_single_column_title_typography',
            'selector' => '{{WRAPPER}} .ved-woo-product .woocommerce .woocommerce-loop-single_column__title .woocommerce-loop-single_column__link',
        ]
        );

        $this->add_control(
        'ved_single_column_price_heading', [
            'label' => esc_html__( 'Product Price', 'godecore-data' ),
            'type'  => Controls_Manager::HEADING,
        ]
        );


        $this->add_control(
        'ved_single_column_price_color', [
            'label'     => esc_html__( 'Product Price Color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#222222',
            'selectors' => [
                '{{WRAPPER}} .ved-woo-product .woocommerce .price' => 'color: {{VALUE}};',
            ],
        ]
        );

        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'ved_single_column_price_typography',
            'selector' => '{{WRAPPER}} .ved-woo-product .woocommerce .price',
        ]
        );

        $this->end_controls_section();
    }

    protected function render() {

        $settings = $this->get_settings();

        // Slider Options
        $desk_items      = $settings[ 'ved_single_column_desk_items' ];
        $desk_small_items      = $settings[ 'ved_single_column_desk_small_items' ];
        $tab_items      = $settings[ 'ved_single_column_tab_items' ];
        $mob_items      = $settings[ 'ved_single_column_mob_items' ];
        $autoplay   = $settings[ 'ved_single_column_slider_autoplay' ];
        $navigation = $settings[ 'ved_single_column_slider_navigation' ];
        $pagination = $settings[ 'ved_single_column_slider_pagination' ];

        $single_column_filter  = $settings[ 'ved_single_column_filter' ];
        $single_column_total_count   = $settings[ 'ved_single_column_total_count' ];
        $single_column_count   = $settings[ 'ved_single_column_count' ];
        $single_column_classes = ( ($settings[ 'ved_single_column_rating' ] == 'yes') ? "show_rating" : "hide_rating" );
        ?>

        <?php if ( isset( $settings[ 'ved_single_column_title' ] ) && $settings[ 'ved_single_column_title' ] ) { ?>
            <div class="sec-head-style">
                <h3 class="text-title text-uppercase page-heading"><?php echo esc_html( $settings[ 'ved_single_column_title' ] ); ?></h3>
            </div>
        <?php } ?>

		<div id="ved-woo-single-column-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-woo-single-column <?php echo esc_attr( $single_column_classes ); ?>">
			<?php
			require GODECORE_DATA_PATH . 'includes/style/single_column/style.php';
			?>
		</div>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                setTimeout(function(){ 
                    var wooproduct_sld = $(".ved-woo-single-column .product_list_element");
                    wooproduct_sld.owlCarousel({
                        autoplay: <?php echo esc_js($autoplay) ? 'true' : 'false'; ?>,
                        autoplayHoverPause:true,
                        nav: <?php echo esc_js($navigation) ? 'true' : 'false'; ?>,
                        dots: <?php echo esc_js($pagination) ? 'true' : 'false'; ?>,
                        loop:false,
                        rewind:true,
                        navText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
                        responsive:{
                            0:{
                                items:<?php echo esc_js($mob_items); ?>},
                            768:{
                                items:<?php echo esc_js($tab_items); ?>},
                            992:{
                                items:<?php echo esc_js($desk_small_items); ?>},
                            1200:{
                                items:<?php echo esc_js($desk_items); ?>}
                        }           
                    });
                }, 300);
            });
        </script>
        <?php
    }

    protected function content_template() {
        ?>


        <?php
    }

}

Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Single_Column() );
endif;