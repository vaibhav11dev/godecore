<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) )
    exit; // If this file is called directly, abort.

if ( ! class_exists( 'Widget_Ved_Cat_Tab' ) ) :
class Widget_Ved_Cat_Tab extends Widget_Base {

    public $base;

    public function get_name() {
        return 'ved-woo-cat-tab';
    }

    public function get_title() {
        return esc_html__( 'Ved Category Tab', 'godecore-data' );
    }

    public function get_icon() {
        return 'eicon-woocommerce';
    }

    public function get_categories() {
        return [ 'godecore-addons' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
        'section_tab', [
            'label' => esc_html__( 'Ved Category Tab', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_cat_tab_head_title', [
            'label'       => esc_html__( 'Heading Title', 'godecore-data' ),
            'type'        => Controls_Manager::TEXT,
            'label_block' => true,
            'default'     => esc_html__( 'Title Here', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_cat_tab_style', [
            'label'   => esc_html__( 'Style', 'godecore-data' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'style1',
            'options' => [
                'style1' => esc_html__( 'Style One', 'godecore-data' ),
                'style2' => esc_html__( 'Style Two', 'godecore-data' ),
            ],
        ]
        );

        $this->add_control(
        'ved_cat_tab_count', [
            'label'   => esc_html__( 'Products Count', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 8,
            'min'     => 1,
            'max'     => 1000,
            'step'    => 1,
        ]
        );
		
		$this->add_control(
        'ved_cat_tab_categories', [
            'label'       => esc_html__( 'Product Categories', 'godecore-data' ),
            'type'        => Controls_Manager::SELECT2,
            'label_block' => true,
            'multiple'    => true,
            'options'     => godecore_woocommerce_product_categories(),
        ]
        );

        $this->add_control(
        'ved_show_cat_tab', [
            'label'     => esc_html__( 'Show Tab', 'godecore-data' ),
            'type'      => Controls_Manager::SWITCHER,
            'label_on'  => esc_html__( 'Yes', 'godecore-data' ),
            'label_off' => esc_html__( 'No', 'godecore-data' ),
            'default'   => 'yes',
        ]
        );

        $this->add_control(
        'ved_cat_tab_rating', [
            'label'     => esc_html__( 'Show Review', 'godecore-data' ),
            'type'      => Controls_Manager::SWITCHER,
            'label_on'  => esc_html__( 'Yes', 'godecore-data' ),
            'label_off' => esc_html__( 'No', 'godecore-data' ),
            'default'   => 'yes',
        ]
        );
		
        $this->end_controls_section();
        
        $this->start_controls_section(
        'ved_section_cat_tab_slider_settings', [
            'label' => esc_html__( 'Product Tab Slider Settings', 'godecore-data' ),
        ]
        );

        $this->add_control(
        'ved_cat_tab_slider_desk_items', [
            'label'   => esc_html__( 'Show Desktop Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 4,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_cat_tab_slider_desk_small_items', [
            'label'   => esc_html__( 'Show Desktop Small Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 3,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );
        
        $this->add_control(
        'ved_cat_tab_slider_tab_items', [
            'label'   => esc_html__( 'Show Tab Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 3,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_cat_tab_slider_mob_items', [
            'label'   => esc_html__( 'Show Mobile Items', 'godecore-data' ),
            'type'    => Controls_Manager::NUMBER,
            'default' => 2,
            'min'     => 1,
            'max'     => 6,
            'step'    => 1,
        ]
        );

        $this->add_control(
        'ved_cat_tab_slider_autoplay', [
            'label'        => esc_html__( 'AutoPlay', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'false',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_cat_tab_slider_navigation', [
            'label'        => esc_html__( 'Navigation', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->add_control(
        'ved_cat_tab_slider_pagination', [
            'label'        => esc_html__( 'Pagination', 'godecore-data' ),
            'type'         => Controls_Manager::SWITCHER,
            'default'      => 'true',
            'label_on'     => esc_html__( 'Yes', 'godecore-data' ),
            'label_off'    => esc_html__( 'No', 'godecore-data' ),
            'return_value' => 'true',
        ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
        'section_style', [
            'label' => esc_html__( 'Style', 'godecore-data' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
        );
        $this->add_control(
        'tab_title_color', [
            'label'     => esc_html__( 'Tab Title color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-nav-tab .nav-link' => 'color: {{VALUE}};'
            ],
        ]
        );
        $this->add_control(
        'tab_title_hover_color', [
            'label'     => esc_html__( 'Tab Title Active & Hover color', 'godecore-data' ),
            'type'      => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .ved-nav-tab .nav-link.active, .ved-nav-tab .nav-link:hover' => 'color: {{VALUE}};'
            ],
        ]
        );
        $this->add_group_control(
        Group_Control_Typography::get_type(), [
            'name'     => 'tab_title_typography',
            'selector' => '{{WRAPPER}} .ved-nav-tab .nav-item .nav-link',
        ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings        = $this->get_settings();

        // Slider Options
		$desk_items      = $settings[ 'ved_cat_tab_slider_desk_items' ];
		$desk_small_items      = $settings[ 'ved_cat_tab_slider_desk_small_items' ];
		$tab_items      = $settings[ 'ved_cat_tab_slider_tab_items' ];
		$mob_items      = $settings[ 'ved_cat_tab_slider_mob_items' ];
        $autoplay   = $settings[ 'ved_cat_tab_slider_autoplay' ];
        $navigation = $settings[ 'ved_cat_tab_slider_navigation' ];
        $pagination = $settings[ 'ved_cat_tab_slider_pagination' ];

        $style     = $settings[ 'ved_cat_tab_style' ];
        $product_tab     = $settings[ 'ved_cat_tab_categories' ];
        $head_title      = $settings[ 'ved_cat_tab_head_title' ];
        $columns         = $settings[ 'ved_cat_tab_slider_desk_items' ];
        $product_count   = $settings[ 'ved_cat_tab_count' ];
        $show_tab        = $settings[ 'ved_show_cat_tab' ];
        $product_classes = ( ($settings[ 'ved_cat_tab_rating' ] == 'yes') ? "show_rating" : "hide_rating" );
		
        ?>
        <div id="ved-woo-cat-tab-<?php echo esc_attr( $this->get_id() ); ?>" class="ved-woo-cat-tab <?php echo esc_attr( $product_classes ); ?> <?php echo esc_attr( $style ); ?>">
            
                <?php
                switch ( $style ) {
                    case 'style1':
                        require GODECORE_DATA_PATH . 'includes/style/cat_tab/style1.php';
                        break;

                    case 'style2':
                        require GODECORE_DATA_PATH . 'includes/style/cat_tab/style2.php';
                        break;
                }
                ?>
            
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                var ved_tab_sld = $("#ved-woo-cat-tab-<?php echo esc_js( $this->get_id() ); ?> .ved-cat-tab-slider");
                ved_tab_sld.owlCarousel({
                    autoplay: <?php echo esc_js($autoplay) ? 'true' : 'false'; ?>,
                    autoplayHoverPause:true,
                    nav: <?php echo esc_js($navigation) ? 'true' : 'false'; ?>,
                    dots: <?php echo esc_js($pagination) ? 'true' : 'false'; ?>,
                    loop:false,
                    navText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],  
                    responsive:{
                        0:{
                            items:<?php echo esc_js($mob_items); ?>},
                        768:{
                            items:<?php echo esc_js($tab_items); ?>},
                        992:{
                            items:<?php echo esc_js($desk_small_items); ?>},
                        1200:{
                            items:<?php echo esc_js($desk_items); ?>}
                    }            
                });
            });
        </script>
            <?php
            }

            protected function _content_template() {
                
            }

        }

        Plugin::instance()->widgets_manager->register_widget_type( new Widget_Ved_Cat_Tab() );
        endif;